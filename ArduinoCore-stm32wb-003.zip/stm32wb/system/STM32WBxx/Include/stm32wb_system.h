/*
 * Copyright (c) 2016-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#if !defined(_STM32WB_SYSTEM_H)
#define _STM32WB_SYSTEM_H

#include "armv7m.h"

#ifdef __cplusplus
extern "C" {
#endif

enum {
    STM32WB_SYSTEM_PERIPH_ADC,
    STM32WB_SYSTEM_PERIPH_USB,
    STM32WB_SYSTEM_PERIPH_USART1,
    STM32WB_SYSTEM_PERIPH_LPUART1,
    STM32WB_SYSTEM_PERIPH_I2C1,
    STM32WB_SYSTEM_PERIPH_I2C3,
    STM32WB_SYSTEM_PERIPH_SPI1,
    STM32WB_SYSTEM_PERIPH_SPI2,
    STM32WB_SYSTEM_PERIPH_QSPI,
    STM32WB_SYSTEM_PERIPH_SAI1,
    STM32WB_SYSTEM_PERIPH_TIM1,
    STM32WB_SYSTEM_PERIPH_TIM2,
    STM32WB_SYSTEM_PERIPH_TIM16,
    STM32WB_SYSTEM_PERIPH_TIM17,
    STM32WB_SYSTEM_PERIPH_LPTIM1,
    STM32WB_SYSTEM_PERIPH_LPTIM2,
    STM32WB_SYSTEM_PERIPH_TSC,
    STM32WB_SYSTEM_PERIPH_LCD,
    STM32WB_SYSTEM_PERIPH_HSEM,
    STM32WB_SYSTEM_PERIPH_IPCC,
    STM32WB_SYSTEM_PERIPH_CRC,
    STM32WB_SYSTEM_PERIPH_RNG,
    STM32WB_SYSTEM_PERIPH_AES1,
    STM32WB_SYSTEM_PERIPH_AES2,
    STM32WB_SYSTEM_PERIPH_PKA,
    STM32WB_SYSTEM_PERIPH_COUNT
};

#define STM32WB_SYSTEM_OPTION_LSE_BYPASS            0x00000001
#define STM32WB_SYSTEM_OPTION_HSE_BYPASS            0x00000002
#define STM32WB_SYSTEM_OPTION_HSE_SYSCLK            0x00000004
#define STM32WB_SYSTEM_OPTION_VBAT_CHARGING         0x00000008
#define STM32WB_SYSTEM_OPTION_SMPS_INDUCTOR_MASK    0x00000030
#define STM32WB_SYSTEM_OPTION_SMPS_INDUCTOR_SHIFT   4
#define STM32WB_SYSTEM_OPTION_SMPS_INDUCTOR_10uH    0x00000010
#define STM32WB_SYSTEM_OPTION_SMPS_INDUCTOR_2_2uH   0x00000020
#define STM32WB_SYSTEM_OPTION_SMPS_CURRENT_MASK     0x000001c0
#define STM32WB_SYSTEM_OPTION_SMPS_CURRENT_SHIFT    6
#define STM32WB_SYSTEM_OPTION_SMPS_CURRENT_80mA     0x00000000
#define STM32WB_SYSTEM_OPTION_SMPS_CURRENT_100mA    0x00000040
#define STM32WB_SYSTEM_OPTION_SMPS_CURRENT_120mA    0x00000080
#define STM32WB_SYSTEM_OPTION_SMPS_CURRENT_140mA    0x000000c0
#define STM32WB_SYSTEM_OPTION_SMPS_CURRENT_160mA    0x00000100
#define STM32WB_SYSTEM_OPTION_SMPS_CURRENT_180mA    0x00000140
#define STM32WB_SYSTEM_OPTION_SMPS_CURRENT_200mA    0x00000180
#define STM32WB_SYSTEM_OPTION_SMPS_CURRENT_220mA    0x000001c0

#define STM32WB_SYSTEM_LOCK_CLOCKS                  0
#define STM32WB_SYSTEM_LOCK_RUN                     1
#define STM32WB_SYSTEM_LOCK_SLEEP                   2
#define STM32WB_SYSTEM_LOCK_STOP_0                  3
#define STM32WB_SYSTEM_LOCK_STOP_1                  4
#define STM32WB_SYSTEM_LOCK_STOP_2                  5
#define STM32WB_SYSTEM_LOCK_COUNT                   6

#define STM32WB_SYSTEM_FREQUENCY_LPRUN              2000000
#define STM32WB_SYSTEM_FREQUENCY_RANGE_2            16000000
#define STM32WB_SYSTEM_FREQUENCY_RANGE_1            64000000
  
#define STM32WB_SYSTEM_REFERENCE_HSI48              0x00000001 /* RANGE 1 */
#define STM32WB_SYSTEM_REFERENCE_CPU2               0x00000002 /* RANGE 1 */
#define STM32WB_SYSTEM_REFERENCE_USB                0x00000004 /* RANGE 1, PCLK1 >= 16MHz */
#define STM32WB_SYSTEM_REFERENCE_RNG                0x00000008 /* RANGE 1 */
#define STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_1     0x00000010 /* RANGE 1 */ 
#define STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_2     0x00000020 /* RANGE 2 */
#define STM32WB_SYSTEM_REFERENCE_SAICLK_RANGE_1     0x00000040 /* RANGE 1 */
#define STM32WB_SYSTEM_REFERENCE_SAICLK_RANGE_2     0x00000080 /* RANGE 2 */
#define STM32WB_SYSTEM_REFERENCE_SWD                0x80000000

#define STM32WB_SYSTEM_NOTIFY_CLOCKS                0x00000001
#define STM32WB_SYSTEM_NOTIFY_SLEEP                 0x00000002
#define STM32WB_SYSTEM_NOTIFY_STOP_ENTER            0x00000004
#define STM32WB_SYSTEM_NOTIFY_STOP_LEAVE            0x00000008
#define STM32WB_SYSTEM_NOTIFY_STANDBY               0x00000010
#define STM32WB_SYSTEM_NOTIFY_SHUTDOWN              0x00000020
#define STM32WB_SYSTEM_NOTIFY_RESET                 0x00000040
#define STM32WB_SYSTEM_NOTIFY_DFU                   0x00000080

typedef void (*stm32wb_system_fatal_callback_t)(void);

typedef void (*stm32wb_system_callback_t)(void *context, uint32_t notify);

typedef struct _stm32wb_system_notify_t {
    struct _stm32wb_system_notify_t *next;
    stm32wb_system_callback_t       callback;
    void                            *context;
    uint32_t                        mask;
} stm32wb_system_notify_t;

#define STM32WB_SYSTEM_SAICLK_NONE               0
#define STM32WB_SYSTEM_SAICLK_11289600           11289600 /*  44100 * 256 */
#define STM32WB_SYSTEM_SAICLK_24576000           24576000 /*  96000 * 256 */
#define STM32WB_SYSTEM_SAICLK_49152000           49152000 /* 192000 * 256 */
  
#define STM32WB_SYSTEM_MCO_SOURCE_MASK           0x0000000f
#define STM32WB_SYSTEM_MCO_SOURCE_SHIFT          0
#define STM32WB_SYSTEM_MCO_SOURCE_NONE           0x00000000
#define STM32WB_SYSTEM_MCO_SOURCE_SYSCLK         0x00000001
#define STM32WB_SYSTEM_MCO_SOURCE_MSI            0x00000002
#define STM32WB_SYSTEM_MCO_SOURCE_HSI16          0x00000003
#define STM32WB_SYSTEM_MCO_SOURCE_HSE            0x00000004
#define STM32WB_SYSTEM_MCO_SOURCE_PLL            0x00000005
#define STM32WB_SYSTEM_MCO_SOURCE_LSI            0x00000006
#define STM32WB_SYSTEM_MCO_SOURCE_LSE            0x00000008
#define STM32WB_SYSTEM_MCO_SOURCE_HSI48          0x00000009

#define STM32WB_SYSTEM_MCO_DIVIDE_MASK           0x00000070
#define STM32WB_SYSTEM_MCO_DIVIDE_SHIFT          4
#define STM32WB_SYSTEM_MCO_DIVIDE_BY_1           0x00000000
#define STM32WB_SYSTEM_MCO_DIVIDE_BY_2           0x00000010
#define STM32WB_SYSTEM_MCO_DIVIDE_BY_4           0x00000020
#define STM32WB_SYSTEM_MCO_DIVIDE_BY_8           0x00000030
#define STM32WB_SYSTEM_MCO_DIVIDE_BY_16          0x00000040

#define STM32WB_SYSTEM_LSCO_SOURCE_MASK          0x00000003
#define STM32WB_SYSTEM_LSCO_SOURCE_SHIFT         0
#define STM32WB_SYSTEM_LSCO_SOURCE_NONE          0x00000000
#define STM32WB_SYSTEM_LSCO_SOURCE_LSI           0x00000001 /* LSI1/LSI2 */
#define STM32WB_SYSTEM_LSCO_SOURCE_LSE           0x00000002

#define STM32WB_SYSTEM_RESET_POWERON             0
#define STM32WB_SYSTEM_RESET_EXTERNAL            1
#define STM32WB_SYSTEM_RESET_INTERNAL            2
#define STM32WB_SYSTEM_RESET_SOFTWARE            3
#define STM32WB_SYSTEM_RESET_FIREWALL            4
#define STM32WB_SYSTEM_RESET_WATCHDOG            5
#define STM32WB_SYSTEM_RESET_CRASH               6
#define STM32WB_SYSTEM_RESET_STANDBY             7

#define STM32WB_SYSTEM_WAKEUP_NONE               0x00000000
#define STM32WB_SYSTEM_WAKEUP_PIN_1              0x00000001
#define STM32WB_SYSTEM_WAKEUP_PIN_2              0x00000002
#define STM32WB_SYSTEM_WAKEUP_PIN_3              0x00000004
#define STM32WB_SYSTEM_WAKEUP_PIN_4              0000000008
#define STM32WB_SYSTEM_WAKEUP_PIN_5              0x00000010
#define STM32WB_SYSTEM_WAKEUP_TIMEOUT            0x00000100
#define STM32WB_SYSTEM_WAKEUP_ALARM              0x00000200
#define STM32WB_SYSTEM_WAKEUP_TAMP_1             0x00000400
#define STM32WB_SYSTEM_WAKEUP_TAMP_2             0x00000800
#define STM32WB_SYSTEM_WAKEUP_TAMP_3             0x00001000
#define STM32WB_SYSTEM_WAKEUP_WATCHDOG           0x00002000
#define STM32WB_SYSTEM_WAKEUP_RESET              0x00004000

#define STM32WB_SYSTEM_EVENT_APPLICATION         0x00000001
#define STM32WB_SYSTEM_EVENT_TIMEOUT             0x00000002

#define STM32WB_SYSTEM_TIMEOUT_NONE              0x00000000
#define STM32WB_SYSTEM_TIMEOUT_FOREVER           0xffffffff

#define STM32WB_SYSTEM_POLICY_RUN                0
#define STM32WB_SYSTEM_POLICY_SLEEP              1
#define STM32WB_SYSTEM_POLICY_STOP               2
  
#define STM32WB_SYSTEM_DEEPSLEEP_PIN_1_RISING    0x00000001
#define STM32WB_SYSTEM_DEEPSLEEP_PIN_2_RISING    0x00000002
#define STM32WB_SYSTEM_DEEPSLEEP_PIN_3_RISING    0x00000004
#define STM32WB_SYSTEM_DEEPSLEEP_PIN_4_RISING    0x00000008
#define STM32WB_SYSTEM_DEEPSLEEP_PIN_5_RISING    0x00000010
#define STM32WB_SYSTEM_DEEPSLEEP_PIN_1_FALLING   0x00000100
#define STM32WB_SYSTEM_DEEPSLEEP_PIN_2_FALLING   0x00000200
#define STM32WB_SYSTEM_DEEPSLEEP_PIN_3_FALLING   0x00000400
#define STM32WB_SYSTEM_DEEPSLEEP_PIN_4_FALLING   0x00000800
#define STM32WB_SYSTEM_DEEPSLEEP_PIN_5_FALLING   0x00001000
#define STM32WB_SYSTEM_DEEPSLEEP_ALARM           0x00010000
#define STM32WB_SYSTEM_DEEPSLEEP_TAMP_1          0x00020000
#define STM32WB_SYSTEM_DEEPSLEEP_TAMP_2          0x00040000
#define STM32WB_SYSTEM_DEEPSLEEP_TAMP_3          0x00080000
#define STM32WB_SYSTEM_DEEPSLEEP_STANDBY         0x00100000
#define STM32WB_SYSTEM_DEEPSLEEP_SHUTDOWN        0x00200000
  
extern void     stm32wb_system_initialize(uint32_t hclk, uint32_t pclk1, uint32_t pclk2, uint32_t lseclk, uint32_t hseclk, uint32_t option);
extern bool     stm32wb_system_sysclk_configure(uint32_t hclk, uint32_t pclk1, uint32_t pclk2);
extern bool     stm32wb_system_saiclk_configure(uint32_t saiclk);
extern void     stm32wb_system_mco_configure(uint32_t mco);
extern void     stm32wb_system_lsco_configure(uint32_t lsco);
extern void     stm32wb_system_lsi_enable(void);
extern void     stm32wb_system_lsi_disable(void);
extern void     stm32wb_system_hsi16_enable(void);
extern void     stm32wb_system_hsi16_disable(void);
extern void     stm32wb_system_hsi48_enable(uint32_t reference);
extern void     stm32wb_system_hsi48_disable(uint32_t reference);
extern uint32_t stm32wb_system_reset_cause(void);
extern uint32_t stm32wb_system_wakeup_reason(void);
extern uint32_t stm32wb_system_lseclk(void);
extern uint32_t stm32wb_system_hseclk(void);
extern uint32_t stm32wb_system_sysclk(void);
extern uint32_t stm32wb_system_hclk(void);
extern uint32_t stm32wb_system_pclk1(void);
extern uint32_t stm32wb_system_pclk2(void);
extern uint32_t stm32wb_system_saiclk(void);
extern uint64_t stm32wb_system_serial(void);
extern void     stm32wb_system_uid(uint32_t *uid);
extern void     stm32wb_system_periph_reset(uint32_t periph);
extern void     stm32wb_system_periph_enable(uint32_t periph);
extern void     stm32wb_system_periph_disable(uint32_t periph);
extern void     stm32wb_system_swd_enable(void);
extern void     stm32wb_system_swd_disable(void);
extern void     stm32wb_system_register(stm32wb_system_notify_t *notify, stm32wb_system_callback_t callback, void *context, uint32_t mask); 
extern void     stm32wb_system_unregister(stm32wb_system_notify_t *notify);
extern void     stm32wb_system_notify(uint32_t notify); 
extern void     stm32wb_system_lock(uint32_t lock); 
extern void     stm32wb_system_unlock(uint32_t lock);
extern void     stm32wb_system_reference(uint32_t reference); 
extern void     stm32wb_system_unreference(uint32_t reference); 
extern void     stm32wb_system_sleep(uint32_t policy, uint32_t events, uint32_t timeout);
extern void     stm32wb_system_wakeup(uint32_t events);
extern void     stm32wb_system_deepsleep(uint32_t config, uint32_t timeout);
extern void     stm32wb_system_hook(stm32wb_system_fatal_callback_t callback);
extern void     stm32wb_system_fatal(void) __attribute__((noreturn));
extern void     stm32wb_system_reset(void) __attribute__((noreturn));
extern void     stm32wb_system_dfu(void) __attribute__((noreturn));
  
extern void WWDG_IRQHandler(void);
extern void PVD_PVM_IRQHandler(void);
extern void TAMP_STAMP_LSECSS_IRQHandler(void);
extern void RTC_WKUP_IRQHandler(void);
extern void FLASH_IRQHandler(void);
extern void RCC_IRQHandler(void);
extern void EXTI0_IRQHandler(void);
extern void EXTI1_IRQHandler(void);
extern void EXTI2_IRQHandler(void);
extern void EXTI3_IRQHandler(void);
extern void EXTI4_IRQHandler(void);
extern void DMA1_Channel1_IRQHandler(void);
extern void DMA1_Channel2_IRQHandler(void);
extern void DMA1_Channel3_IRQHandler(void);
extern void DMA1_Channel4_IRQHandler(void);
extern void DMA1_Channel5_IRQHandler(void);
extern void DMA1_Channel6_IRQHandler(void);
extern void DMA1_Channel7_IRQHandler(void);
extern void ADC1_IRQHandler(void);
extern void USB_HP_IRQHandler(void);
extern void USB_LP_IRQHandler(void);
extern void C2SEV_PWR_C2H_IRQHandler(void);
extern void COMP_IRQHandler(void);
extern void EXTI9_5_IRQHandler(void);
extern void TIM1_BRK_IRQHandler(void);
extern void TIM1_UP_TIM16_IRQHandler(void);
extern void TIM1_TRG_COM_TIM17_IRQHandler(void);
extern void TIM1_CC_IRQHandler(void);
extern void TIM2_IRQHandler(void);
extern void PKA_IRQHandler(void);
extern void I2C1_EV_IRQHandler(void);
extern void I2C1_ER_IRQHandler(void);
extern void I2C3_EV_IRQHandler(void);
extern void I2C3_ER_IRQHandler(void);
extern void SPI1_IRQHandler(void);
extern void SPI2_IRQHandler(void);
extern void USART1_IRQHandler(void);
extern void LPUART1_IRQHandler(void);
extern void SAI1_IRQHandler(void);
extern void TSC_IRQHandler(void);
extern void EXTI15_10_IRQHandler(void);
extern void RTC_Alarm_IRQHandler(void);
extern void CRS_IRQHandler(void);
extern void PWR_SOTF_BLEACT_802ACT_RFPHASE_IRQHandler(void);
extern void IPCC_C1_RX_IRQHandler(void);
extern void IPCC_C1_TX_IRQHandler(void);
extern void HSEM_IRQHandler(void);
extern void LPTIM1_IRQHandler(void);
extern void LPTIM2_IRQHandler(void);
extern void LCD_IRQHandler(void);
extern void QUADSPI_IRQHandler(void);
extern void AES1_IRQHandler(void);
extern void AES2_IRQHandler(void);
extern void RNG_IRQHandler(void);
extern void FPU_IRQHandler(void);
extern void DMA2_Channel1_IRQHandler(void);
extern void DMA2_Channel2_IRQHandler(void);
extern void DMA2_Channel3_IRQHandler(void);
extern void DMA2_Channel4_IRQHandler(void);
extern void DMA2_Channel5_IRQHandler(void);
extern void DMA2_Channel6_IRQHandler(void);
extern void DMA2_Channel7_IRQHandler(void);
extern void DMAMUX1_OVR_IRQHandler(void);
  
#ifdef __cplusplus
}
#endif

#endif /* _STM32WB_SYSTEM_H */
