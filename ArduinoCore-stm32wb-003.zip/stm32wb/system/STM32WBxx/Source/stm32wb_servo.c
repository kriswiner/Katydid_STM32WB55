/*
 * Copyright (c) 2016-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include <stdio.h>

#include "stm32wbxx.h"

#include "armv7m.h"

#include "stm32wb_gpio.h"
#include "stm32wb_servo.h"
#include "stm32wb_system.h"

static void stm32wb_servo_tim_callback(void *context, uint32_t events)
{
    stm32wb_servo_t *servo = (stm32wb_servo_t*)context;
    stm32wb_servo_schedule_t *self, *next;
    unsigned int index;

    if (events & STM32WB_TIM_EVENT_CHANNEL_1)
    {
	index = servo->index;
	self = servo->self;
	next = servo->next;

	if (index != self->entries)
	{
	    self->slot[index].GPIO->BRR = self->slot[index].mask;
	    index++;

	    if (index != self->entries)
	    {
		self->slot[index].GPIO->BSRR = self->slot[index].mask;

		servo->compare += self->slot[index].width;
	    }
	    else
	    {
		servo->compare += self->sync;
	    }

	    stm32wb_tim_compare(&servo->tim, STM32WB_TIM_CHANNEL_1, servo->compare -1);

	    servo->index = index;
	}
	else
	{
	    servo->index = 0;

	    if (self == next)
	    {
		self->slot[0].GPIO->BSRR = self->slot[0].mask;

		servo->compare = self->slot[0].width;

		stm32wb_tim_compare(&servo->tim, STM32WB_TIM_CHANNEL_1, servo->compare -1);
	    }
	    else
	    {
		if (next->entries)
		{
		    servo->self = next;

		    next->slot[0].GPIO->BSRR = next->slot[0].mask;

		    servo->compare = self->slot[0].width;

		    stm32wb_tim_compare(&servo->tim, STM32WB_TIM_CHANNEL_1, servo->compare -1);
		}
		else
		{
		    stm32wb_tim_stop(&servo->tim);

		    servo->state = STM32WB_SERVO_STATE_READY;

		    servo->self = NULL;
		    servo->next = NULL;
		}
	    }

	    if (servo->callback)
	    {
		(*servo->callback)(servo->context, STM32WB_SERVO_EVENT_SYNC);
	    }
	}
    }
}

bool stm32wb_servo_create(stm32wb_servo_t *servo, unsigned int instance, unsigned int priority)
{
    if (!stm32wb_tim_create(&servo->tim, instance, priority))
    {
	return false;
    }

    servo->state = STM32WB_SERVO_STATE_INIT;

    return true;
}

bool stm32wb_servo_destroy(stm32wb_servo_t *servo)
{
    if (servo->state != STM32WB_SERVO_STATE_INIT)
    {
	return false;
    }

    if (!stm32wb_tim_destroy(&servo->tim))
    {
	return false;
    }

    servo->state = STM32WB_SERVO_STATE_NONE;

    return true;
}

bool stm32wb_servo_enable(stm32wb_servo_t *servo, const stm32wb_servo_table_t *table, stm32wb_servo_callback_t callback, void *context)
{
    if (servo->state != STM32WB_SERVO_STATE_INIT)
    {
	return false;
    }

    servo->state = STM32WB_SERVO_STATE_NOT_READY;
    
    servo->callback = callback;
    servo->context = context;

    servo->self = NULL;
    servo->next = NULL;

    if (!stm32wb_tim_enable(&servo->tim, 0, stm32wb_servo_tim_callback, servo))
    {
	servo->state = STM32WB_SERVO_STATE_INIT;

	return false;
    }

    if (!stm32wb_servo_configure(servo, table))
    {
	stm32wb_tim_disable(&servo->tim);

	servo->state = STM32WB_SERVO_STATE_INIT;

	return false;
    }

    servo->state = STM32WB_SERVO_STATE_READY;

    return true;
}

bool stm32wb_servo_disable(stm32wb_servo_t *servo)
{
    if (servo->state != STM32WB_SERVO_STATE_READY)
    {
	return false;
    }

    stm32wb_tim_disable(&servo->tim);

    servo->state = STM32WB_SERVO_STATE_INIT;

    return true;
}

bool stm32wb_servo_configure(stm32wb_servo_t *servo, const stm32wb_servo_table_t *table)
{
    stm32wb_servo_schedule_t *next;
    unsigned int entry, index, width;

    if (servo->state < STM32WB_SERVO_STATE_NOT_READY)
    {
	return false;
    }

    if (servo->self && (servo->self != servo->next))
    {
	return false;
    }
	
    next = ((servo->self == &servo->schedule[0]) ? &servo->schedule[1] : &servo->schedule[0]);
    
    for (width = 0, entry = 0, index = 0; entry < table->entries; entry++)
    {
	if ((table->slot[entry].pin != STM32WB_GPIO_PIN_NONE) && (table->slot[index].width >= STM32WB_SERVO_PULSE_WIDTH_MIN) && (table->slot[index].width <= STM32WB_SERVO_PULSE_WIDTH_MAX))
	{
	    next->slot[index].GPIO = (GPIO_TypeDef *)(GPIOA_BASE + (GPIOB_BASE - GPIOA_BASE) * ((table->slot[entry].pin & STM32WB_GPIO_PIN_GROUP_MASK) >> STM32WB_GPIO_PIN_GROUP_SHIFT));
	    next->slot[index].mask = (1ul << ((table->slot[entry].pin & STM32WB_GPIO_PIN_INDEX_MASK) >> STM32WB_GPIO_PIN_INDEX_SHIFT));
	    next->slot[index].width = table->slot[entry].width;

	    width += table->slot[entry].width;
	    index++;
	}
    }

    if (width == 0)
    {
	next->entries = 0;
	next->sync = 0;
    }
    else
    {
	next->entries = index;
	next->sync = STM32WB_SERVO_FRAME_WIDTH - width;
    }

    if (servo->self == NULL)
    {
	if (next->entries)
	{
	    servo->state = STM32WB_SERVO_STATE_ACTIVE;
	    servo->index = 0;
	    servo->compare = next->slot[0].width;
	    servo->self = next;
	    servo->next = next;
	    
	    next->slot[0].GPIO->BSRR = next->slot[0].mask;
	    
	    stm32wb_tim_channel(&servo->tim, STM32WB_TIM_CHANNEL_1, servo->compare -1, STM32WB_TIM_CONTROL_COMPARE);
	    stm32wb_tim_start(&servo->tim, (stm32wb_tim_clock(&servo->tim) / 1000000), STM32WB_SERVO_FRAME_WIDTH -1);
	}
	else
	{
	    servo->next = NULL;
	}
    }
    else
    {
	servo->next = next;
    }

    return true;
}

bool stm32wb_servo_active(stm32wb_servo_t *servo)
{
    return (servo->state == STM32WB_SERVO_STATE_ACTIVE);
}
