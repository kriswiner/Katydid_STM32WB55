/*
 * Copyright (c) 2016-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include "armv7m.h"
#include "stm32wb_flash.h"

/* THIS SHOULD BE DONE IN A SWI. WHEN A LOCK BECOMES FREE, THE SWI HANDLES IT AND REQUESTS THE NEXT LOCK OR DOES ERASE/PROGRAM */

typedef struct _stm32wb_flash_device_t {
    volatile bool blocked;
} stm32wb_flash_device_t;

static stm32wb_flash_device_t stm32wb_flash_device;

void stm32wb_flash_block(void)
{
    /* BLOCK_FLASH_REQ_BY_CPU1 LOCK (SEM6) */

    stm32wb_flash_device.blocked = true;
}

void stm32wb_flash_unblock(void)
{
    stm32wb_flash_device.blocked = false;

    /* BLOCK_FLASH_REQ_BY_CPU1 UNLOCK (SEM6) */
}

bool stm32wb_flash_erase(uint32_t address, uint32_t count)
{
    uint32_t primask;
    bool success = true;

    /* FLASH LOCK (SEM2) */

    FLASH->ACR &= ~(FLASH_ACR_ICEN | FLASH_ACR_DCEN);

    FLASH->KEYR = 0x45670123;
    FLASH->KEYR = 0xcdef89ab;

    /* SHCI_C2_FLASH_EraseActivity(ON); */
    
    do
    {
	primask = __get_PRIMASK();

	__disable_irq();

	if (stm32wb_flash_device.blocked)
	{
	    success = false;
	}
	else
	{
	    /* BLOCK_FLASH_REQ_BY_CPU2 LOCK (SEM7) */

	    FLASH->CR = FLASH_CR_PER | ((((address - FLASH_BASE) / 4096) << 3) & FLASH_CR_PNB) | FLASH_CR_STRT;
	
	    while (FLASH->SR & FLASH_SR_BSY)
	    {
	    }

	    FLASH->CR = 0;

	    /* BLOCK_FLASH_REQ_BY_CPU2 UNLOCK (SEM7) */

	    if (FLASH->SR & (FLASH_SR_PROGERR | FLASH_SR_SIZERR | FLASH_SR_PGAERR | FLASH_SR_PGSERR | FLASH_SR_WRPERR | FLASH_SR_MISERR | FLASH_SR_FASTERR | FLASH_SR_RDERR))
	    {
		FLASH->SR = (FLASH_SR_PROGERR | FLASH_SR_SIZERR | FLASH_SR_PGAERR | FLASH_SR_PGSERR | FLASH_SR_WRPERR | FLASH_SR_MISERR | FLASH_SR_FASTERR | FLASH_SR_RDERR);

		success = false;
	    }
	}
	
	__set_PRIMASK(primask);

	address += 4096;
	count   -= 4096;
    }
    while (success && count);

    /* SHCI_C2_FLASH_EraseActivity(OFF); */

    FLASH->CR = FLASH_CR_LOCK;
	
    FLASH->ACR = (FLASH->ACR & ~(FLASH_ACR_ICEN | FLASH_ACR_DCEN)) | (FLASH_ACR_ICRST | FLASH_ACR_DCRST);
    FLASH->ACR = (FLASH->ACR & ~(FLASH_ACR_ICRST | FLASH_ACR_DCRST)) | (FLASH_ACR_ICEN | FLASH_ACR_DCEN);

    /* FLASH UNLOCK (SEM2) */
    
    return success;
}

bool stm32wb_flash_program(uint32_t address, const uint8_t *data, uint32_t count)
{
    uint32_t primask;
    bool success = true;

    /* FLASH LOCK (SEM2) */

    FLASH->ACR &= ~(FLASH_ACR_ICEN | FLASH_ACR_DCEN);

    FLASH->KEYR = 0x45670123;
    FLASH->KEYR = 0xcdef89ab;

    do
    {
	primask = __get_PRIMASK();

	__disable_irq();

	if (stm32wb_flash_device.blocked)
	{
	    success = false;
	}
	else
	{
	    /* BLOCK_FLASH_REQ_BY_CPU2 LOCK (SEM7) */

	    FLASH->CR = FLASH_CR_PG;

	    ((volatile uint32_t *)address)[0] = ((const uint32_t*)((const void*)data))[0];
	    ((volatile uint32_t *)address)[1] = ((const uint32_t*)((const void*)data))[1];
	    __DMB();
	
	    while (FLASH->SR & FLASH_SR_BSY)
	    {
	    }
    
	    FLASH->CR = 0;

	    /* BLOCK_FLASH_REQ_BY_CPU2 UNLOCK (SEM7) */
	    
	    if (FLASH->SR & (FLASH_SR_PROGERR | FLASH_SR_SIZERR | FLASH_SR_PGAERR | FLASH_SR_PGSERR | FLASH_SR_WRPERR | FLASH_SR_MISERR | FLASH_SR_FASTERR | FLASH_SR_RDERR))
	    {
		FLASH->SR = (FLASH_SR_PROGERR | FLASH_SR_SIZERR | FLASH_SR_PGAERR | FLASH_SR_PGSERR | FLASH_SR_WRPERR | FLASH_SR_MISERR | FLASH_SR_FASTERR | FLASH_SR_RDERR);

		success = false;
	    }
	}
	
	__set_PRIMASK(primask);
	
	data    += 8;
	address += 8;
	count   -= 8;
    }
    while (success && count);

    FLASH->CR = FLASH_CR_LOCK;

    FLASH->ACR = (FLASH->ACR & ~(FLASH_ACR_ICEN | FLASH_ACR_DCEN)) | (FLASH_ACR_ICRST | FLASH_ACR_DCRST);
    FLASH->ACR = (FLASH->ACR & ~(FLASH_ACR_ICRST | FLASH_ACR_DCRST)) | (FLASH_ACR_ICEN | FLASH_ACR_DCEN);

    /* FLASH UNLOCK (SEM2) */

    return success;
}

