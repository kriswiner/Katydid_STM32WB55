/*
 * Copyright (c) 2016-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include <stdlib.h>

#include "armv7m.h"

#include "stm32wb_system.h"
#include "stm32wb_gpio.h"
#include "stm32wb_exti.h"
#include "stm32wb_dma.h"
#include "stm32wb_rtc.h"
#include "stm32wb_lptim.h"

#define PWR_CR1_VOS_RANGE_1        (1 << PWR_CR1_VOS_Pos)
#define PWR_CR1_VOS_RANGE_2        (2 << PWR_CR1_VOS_Pos)

#define PWR_CR1_LPMS_STOP0         (0 << PWR_CR1_LPMS_Pos)
#define PWR_CR1_LPMS_STOP1         (1 << PWR_CR1_LPMS_Pos)
#define PWR_CR1_LPMS_STOP2         (2 << PWR_CR1_LPMS_Pos)
#define PWR_CR1_LPMS_STANDBY       (3 << PWR_CR1_LPMS_Pos)
#define PWR_CR1_LPMS_SHUTDOWN      (4 << PWR_CR1_LPMS_Pos)

#define PWR_C2CR1_LPMS_STOP0       (0 << PWR_C2CR1_LPMS_Pos)
#define PWR_C2CR1_LPMS_STOP1       (1 << PWR_C2CR1_LPMS_Pos)
#define PWR_C2CR1_LPMS_STOP2       (2 << PWR_C2CR1_LPMS_Pos)
#define PWR_C2CR1_LPMS_STANDBY     (3 << PWR_C2CR1_LPMS_Pos)
#define PWR_C2CR1_LPMS_SHUTDOWN    (4 << PWR_C2CR1_LPMS_Pos)

#define RCC_CFGR_SW_MSI            (0 << RCC_CFGR_SW_Pos)
#define RCC_CFGR_SW_HSI            (1 << RCC_CFGR_SW_Pos)
#define RCC_CFGR_SW_HSE            (2 << RCC_CFGR_SW_Pos)
#define RCC_CFGR_SW_PLL            (3 << RCC_CFGR_SW_Pos)

#define RCC_CFGR_SWS_MSI           (0 << RCC_CFGR_SWS_Pos)
#define RCC_CFGR_SWS_HSI           (1 << RCC_CFGR_SWS_Pos)
#define RCC_CFGR_SWS_HSE           (2 << RCC_CFGR_SWS_Pos)
#define RCC_CFGR_SWS_PLL           (3 << RCC_CFGR_SWS_Pos)

#define RCC_CFGR_HPRE_DIV1         ( 0 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV3         ( 1 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV5         ( 2 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV6         ( 5 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV10        ( 6 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV32        ( 7 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV2         ( 8 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV4         ( 9 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV8         (10 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV16        (11 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV64        (12 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV128       (13 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV256       (14 << RCC_CFGR_HPRE_Pos)
#define RCC_CFGR_HPRE_DIV512       (15 << RCC_CFGR_HPRE_Pos)

#define RCC_CFGR_PPRE1_DIV1        ( 0 << RCC_CFGR_PPRE1_Pos)
#define RCC_CFGR_PPRE1_DIV2        ( 4 << RCC_CFGR_PPRE1_Pos)
#define RCC_CFGR_PPRE1_DIV4        ( 5 << RCC_CFGR_PPRE1_Pos)
#define RCC_CFGR_PPRE1_DIV8        ( 6 << RCC_CFGR_PPRE1_Pos)
#define RCC_CFGR_PPRE1_DIV16       ( 7 << RCC_CFGR_PPRE1_Pos)

#define RCC_CFGR_PPRE2_DIV1        ( 0 << RCC_CFGR_PPRE2_Pos)
#define RCC_CFGR_PPRE2_DIV2        ( 4 << RCC_CFGR_PPRE2_Pos)
#define RCC_CFGR_PPRE2_DIV4        ( 5 << RCC_CFGR_PPRE2_Pos)
#define RCC_CFGR_PPRE2_DIV8        ( 6 << RCC_CFGR_PPRE2_Pos)
#define RCC_CFGR_PPRE2_DIV16       ( 7 << RCC_CFGR_PPRE2_Pos)

#define RCC_PLLCFGR_PLLSRC_NONE    (0 << RCC_PLLCFGR_PLLSRC_Pos)
#define RCC_PLLCFGR_PLLSRC_MSI     (1 << RCC_PLLCFGR_PLLSRC_Pos)
#define RCC_PLLCFGR_PLLSRC_HSI     (2 << RCC_PLLCFGR_PLLSRC_Pos)
#define RCC_PLLCFGR_PLLSRC_HSE     (3 << RCC_PLLCFGR_PLLSRC_Pos)

#define RCC_EXTCFGR_SHDHPRE_DIV1   ( 0 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV3   ( 1 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV5   ( 2 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV6   ( 5 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV10  ( 6 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV32  ( 7 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV2   ( 8 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV4   ( 9 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV8   (10 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV16  (11 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV64  (12 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV128 (13 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV256 (14 << RCC_EXTCFGR_SHDHPRE_Pos)
#define RCC_EXTCFGR_SHDHPRE_DIV512 (15 << RCC_EXTCFGR_SHDHPRE_Pos)

#define RCC_EXTCFGR_C2HPRE_DIV1    ( 0 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV3    ( 1 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV5    ( 2 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV6    ( 5 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV10   ( 6 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV32   ( 7 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV2    ( 8 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV4    ( 9 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV8    (10 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV16   (11 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV64   (12 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV128  (13 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV256  (14 << RCC_EXTCFGR_C2HPRE_Pos)
#define RCC_EXTCFGR_C2HPRE_DIV512  (15 << RCC_EXTCFGR_C2HPRE_Pos)

#define RCC_SMPSCR_SMPSSEL_HSI     (0 << RCC_SMPSCR_SMPSSEL_Pos)
#define RCC_SMPSCR_SMPSSEL_MSI     (1 << RCC_SMPSCR_SMPSSEL_Pos)
#define RCC_SMPSCR_SMPSSEL_HSE     (2 << RCC_SMPSCR_SMPSSEL_Pos)
#define RCC_SMPSCR_SMPSSEL_NONE    (3 << RCC_SMPSCR_SMPSSEL_Pos)

#define RCC_SMPSCR_SMPSSWS_HSI     (0 << RCC_SMPSCR_SMPSSWS_Pos)
#define RCC_SMPSCR_SMPSSWS_MSI     (1 << RCC_SMPSCR_SMPSSWS_Pos)
#define RCC_SMPSCR_SMPSSWS_HSE     (2 << RCC_SMPSCR_SMPSSWS_Pos)
#define RCC_SMPSCR_SMPSSWS_NONE    (3 << RCC_SMPSCR_SMPSSWS_Pos)

/* CPU2 reserves the first 16 bytes of SRAM2A for Hardfault
   and security attack magic values. AN5289 4.8.2
*/

#define STM32WB_CRASH_SIGNATURE_DATA    0xfeeb6667
#define STM32WB_CRASH_SIGNATURE_ADDRESS 0x10000010

#define STM32WB_SYSTEM_REFERENCE_RANGE_1_2	\
    (STM32WB_SYSTEM_REFERENCE_HSI48 |		\
     STM32WB_SYSTEM_REFERENCE_CPU2 |		\
     STM32WB_SYSTEM_REFERENCE_USB |		\
     STM32WB_SYSTEM_REFERENCE_RNG |		\
     STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_1 |	\
     STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_2 |	\
     STM32WB_SYSTEM_REFERENCE_SAICLK_RANGE_1 |  \
     STM32WB_SYSTEM_REFERENCE_SAICLK_RANGE_2)

#define STM32WB_SYSTEM_REFERENCE_RANGE_1	\
    (STM32WB_SYSTEM_REFERENCE_HSI48 |		\
     STM32WB_SYSTEM_REFERENCE_CPU2 |		\
     STM32WB_SYSTEM_REFERENCE_USB |		\
     STM32WB_SYSTEM_REFERENCE_RNG |		\
     STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_1 |	\
     STM32WB_SYSTEM_REFERENCE_SAICLK_RANGE_1)

extern uint8_t __Vectors[];
extern uint8_t __StackTop[];

extern uint8_t __text2a_start__[];
extern uint8_t __rodata2a_end__[];
extern uint8_t __text2b_start__[];
extern uint8_t __rodata2b_end__[];
extern uint8_t __data2a_start__[];
extern uint8_t __data2a_end__[];
extern uint8_t __data2a_flash__[];
extern uint8_t __bss2a_start__[];
extern uint8_t __bss2a_end__[];

__attribute__((section(".noinit"))) uint32_t SystemCoreClock;

typedef struct _stm32wb_system_device_t {
    uint32_t                  options;
    uint16_t                  reset;
    uint16_t                  wakeup;
    uint32_t                  lseclk;
    uint32_t                  hseclk;
    uint32_t                  sysclk;
    uint32_t                  hclk;
    uint32_t                  pclk1;
    uint32_t                  pclk2;
    uint32_t                  saiclk; 
    uint8_t                   mco;
    uint8_t                   lsco;
    uint8_t                   hse;
    uint8_t                   lsi;
    uint8_t                   msi;
    uint8_t                   hsi16;
    uint8_t                   hsi48;
    uint8_t                   pllsys;
    uint8_t                   smps;
    uint8_t                   palevel;
    uint32_t                  c1spre[2];
    uint32_t                  c2hpre;
    stm32wb_system_notify_t   *notify;
    volatile uint8_t          lock[STM32WB_SYSTEM_LOCK_COUNT];
    volatile uint32_t         reference;
    volatile uint32_t         events;
    stm32wb_rtc_timer_t       timeout;
    stm32wb_system_fatal_callback_t callback;
} stm32wb_system_device_t;

static stm32wb_system_device_t stm32wb_system_device;

static volatile uint32_t * const stm32wb_system_xlate_RSTR[STM32WB_SYSTEM_PERIPH_COUNT] = {
    &RCC->AHB2RSTR,           /* STM32WB_SYSTEM_PERIPH_ADC */
    &RCC->APB1RSTR1,          /* STM32WB_SYSTEM_PERIPH_USB */
    &RCC->APB2RSTR,           /* STM32WB_SYSTEM_PERIPH_USART1 */
    &RCC->APB1RSTR2,          /* STM32WB_SYSTEM_PERIPH_LPUART1 */
    &RCC->APB1RSTR1,          /* STM32WB_SYSTEM_PERIPH_I2C1 */
    &RCC->APB1RSTR1,          /* STM32WB_SYSTEM_PERIPH_I2C3 */
    &RCC->APB2RSTR,           /* STM32WB_SYSTEM_PERIPH_SPI1 */
    &RCC->APB1RSTR1,          /* STM32WB_SYSTEM_PERIPH_SPI2 */
    &RCC->AHB3RSTR,           /* STM32WB_SYSTEM_PERIPH_QSPI */
    &RCC->APB2RSTR,           /* STM32WB_SYSTEM_PERIPH_SAI1 */
    &RCC->APB2RSTR,           /* STM32WB_SYSTEM_PERIPH_TIM1 */
    &RCC->APB1RSTR1,          /* STM32WB_SYSTEM_PERIPH_TIM2 */
    &RCC->APB2RSTR,           /* STM32WB_SYSTEM_PERIPH_TIM16 */
    &RCC->APB2RSTR,           /* STM32WB_SYSTEM_PERIPH_TIM17 */
    &RCC->APB1RSTR1,          /* STM32WB_SYSTEM_PERIPH_LPTIM1 */
    &RCC->APB1RSTR2,          /* STM32WB_SYSTEM_PERIPH_LPTIM2 */
    &RCC->AHB1RSTR,           /* STM32WB_SYSTEM_PERIPH_TSC */
    &RCC->APB1RSTR1,          /* STM32WB_SYSTEM_PERIPH_LCD */
    &RCC->AHB3RSTR,           /* STM32WB_SYSTEM_PERIPH_HSEM */
    &RCC->AHB3RSTR,           /* STM32WB_SYSTEM_PERIPH_IPCC */
    &RCC->AHB1RSTR,           /* STM32WB_SYSTEM_PERIPH_CRC */
    &RCC->AHB3RSTR,           /* STM32WB_SYSTEM_PERIPH_RNG */
    &RCC->AHB2RSTR,           /* STM32WB_SYSTEM_PERIPH_AES1 */
    &RCC->AHB3RSTR,           /* STM32WB_SYSTEM_PERIPH_AES2 */
    &RCC->AHB3RSTR,           /* STM32WB_SYSTEM_PERIPH_PKA */
};

static uint32_t const stm32wb_system_xlate_RSTMSK[STM32WB_SYSTEM_PERIPH_COUNT] = {
    RCC_AHB2RSTR_ADCRST,      /* STM32WB_SYSTEM_PERIPH_ADC */
    RCC_APB1RSTR1_USBRST,     /* STM32WB_SYSTEM_PERIPH_USB */
    RCC_APB2RSTR_USART1RST,   /* STM32WB_SYSTEM_PERIPH_USART1 */
    RCC_APB1RSTR2_LPUART1RST, /* STM32WB_SYSTEM_PERIPH_LPUART1 */
    RCC_APB1RSTR1_I2C1RST,    /* STM32WB_SYSTEM_PERIPH_I2C1 */
    RCC_APB1RSTR1_I2C3RST,    /* STM32WB_SYSTEM_PERIPH_I2C3 */
    RCC_APB2RSTR_SPI1RST,     /* STM32WB_SYSTEM_PERIPH_SPI1 */
    RCC_APB1RSTR1_SPI2RST,    /* STM32WB_SYSTEM_PERIPH_SPI2 */
    RCC_AHB3RSTR_QUADSPIRST,  /* STM32WB_SYSTEM_PERIPH_QSPI */
    RCC_APB2RSTR_SAI1RST,     /* STM32WB_SYSTEM_PERIPH_SAI1 */
    RCC_APB2RSTR_TIM1RST,     /* STM32WB_SYSTEM_PERIPH_TIM1 */
    RCC_APB1RSTR1_TIM2RST,    /* STM32WB_SYSTEM_PERIPH_TIM2 */
    RCC_APB2RSTR_TIM16RST,    /* STM32WB_SYSTEM_PERIPH_TIM16 */
    RCC_APB2RSTR_TIM17RST,    /* STM32WB_SYSTEM_PERIPH_TIM17 */
    RCC_APB1RSTR1_LPTIM1RST,  /* STM32WB_SYSTEM_PERIPH_LPTIM1 */
    RCC_APB1RSTR2_LPTIM2RST,  /* STM32WB_SYSTEM_PERIPH_LPTIM2 */
    RCC_AHB1RSTR_TSCRST,      /* STM32WB_SYSTEM_PERIPH_TSC */
    RCC_APB1RSTR1_LCDRST,     /* STM32WB_SYSTEM_PERIPH_LCD */
    RCC_AHB3RSTR_HSEMRST,     /* STM32WB_SYSTEM_PERIPH_HSEM */
    RCC_AHB3RSTR_IPCCRST,     /* STM32WB_SYSTEM_PERIPH_IPCC */
    RCC_AHB1RSTR_CRCRST,      /* STM32WB_SYSTEM_PERIPH_CRC */
    RCC_AHB3RSTR_RNGRST,      /* STM32WB_SYSTEM_PERIPH_RNG */
    RCC_AHB2RSTR_AES1RST,     /* STM32WB_SYSTEM_PERIPH_AES1 */
    RCC_AHB3RSTR_AES2RST,     /* STM32WB_SYSTEM_PERIPH_AES2 */
    RCC_AHB3RSTR_PKARST,      /* STM32WB_SYSTEM_PERIPH_PKA */
};

static volatile uint32_t * const stm32wb_system_xlate_ENR[STM32WB_SYSTEM_PERIPH_COUNT] = {
    &RCC->AHB2ENR,            /* STM32WB_SYSTEM_PERIPH_ADC */
    &RCC->APB1ENR1,           /* STM32WB_SYSTEM_PERIPH_USB */
    &RCC->APB2ENR,            /* STM32WB_SYSTEM_PERIPH_USART1 */
    &RCC->APB1ENR2,           /* STM32WB_SYSTEM_PERIPH_LPUART1 */
    &RCC->APB1ENR1,           /* STM32WB_SYSTEM_PERIPH_I2C1 */
    &RCC->APB1ENR1,           /* STM32WB_SYSTEM_PERIPH_I2C3 */
    &RCC->APB2ENR,            /* STM32WB_SYSTEM_PERIPH_SPI1 */
    &RCC->APB1ENR1,           /* STM32WB_SYSTEM_PERIPH_SPI2 */
    &RCC->AHB3ENR,            /* STM32WB_SYSTEM_PERIPH_QSPI */
    &RCC->APB2ENR,            /* STM32WB_SYSTEM_PERIPH_SAI1 */
    &RCC->APB2ENR,            /* STM32WB_SYSTEM_PERIPH_TIM1 */
    &RCC->APB1ENR1,           /* STM32WB_SYSTEM_PERIPH_TIM2 */
    &RCC->APB2ENR,            /* STM32WB_SYSTEM_PERIPH_TIM16 */
    &RCC->APB2ENR,            /* STM32WB_SYSTEM_PERIPH_TIM17 */
    &RCC->APB1ENR1,           /* STM32WB_SYSTEM_PERIPH_LPTIM1 */
    &RCC->APB1ENR2,           /* STM32WB_SYSTEM_PERIPH_LPTIM2 */
    &RCC->AHB1ENR,            /* STM32WB_SYSTEM_PERIPH_TSC */
    &RCC->APB1ENR1,           /* STM32WB_SYSTEM_PERIPH_LCD */
    &RCC->AHB3ENR,            /* STM32WB_SYSTEM_PERIPH_HSEM */
    &RCC->AHB3ENR,            /* STM32WB_SYSTEM_PERIPH_IPCC */
    &RCC->AHB1ENR,            /* STM32WB_SYSTEM_PERIPH_CRC */
    &RCC->AHB3ENR,            /* STM32WB_SYSTEM_PERIPH_RNG */
    &RCC->AHB2ENR,            /* STM32WB_SYSTEM_PERIPH_AES1 */
    &RCC->AHB3ENR,            /* STM32WB_SYSTEM_PERIPH_AES2 */
    &RCC->AHB3ENR,            /* STM32WB_SYSTEM_PERIPH_PKA */
};

static uint32_t const stm32wb_system_xlate_ENMSK[STM32WB_SYSTEM_PERIPH_COUNT] = {
    RCC_AHB2ENR_ADCEN,        /* STM32WB_SYSTEM_PERIPH_ADC */
    RCC_APB1ENR1_USBEN,       /* STM32WB_SYSTEM_PERIPH_USB */
    RCC_APB2ENR_USART1EN,     /* STM32WB_SYSTEM_PERIPH_USART1 */
    RCC_APB1ENR2_LPUART1EN,   /* STM32WB_SYSTEM_PERIPH_LPUART1 */
    RCC_APB1ENR1_I2C1EN,      /* STM32WB_SYSTEM_PERIPH_I2C1 */
    RCC_APB1ENR1_I2C3EN,      /* STM32WB_SYSTEM_PERIPH_I2C3 */
    RCC_APB2ENR_SPI1EN,       /* STM32WB_SYSTEM_PERIPH_SPI1 */
    RCC_APB1ENR1_SPI2EN,      /* STM32WB_SYSTEM_PERIPH_SPI2 */
    RCC_AHB3ENR_QUADSPIEN,    /* STM32WB_SYSTEM_PERIPH_QSPI */
    RCC_APB2ENR_SAI1EN,       /* STM32WB_SYSTEM_PERIPH_SAI1 */
    RCC_APB2ENR_TIM1EN,       /* STM32WB_SYSTEM_PERIPH_TIM1 */
    RCC_APB1ENR1_TIM2EN,      /* STM32WB_SYSTEM_PERIPH_TIM2 */
    RCC_APB2ENR_TIM16EN,      /* STM32WB_SYSTEM_PERIPH_TIM16 */
    RCC_APB2ENR_TIM17EN,      /* STM32WB_SYSTEM_PERIPH_TIM17 */
    RCC_APB1ENR1_LPTIM1EN,    /* STM32WB_SYSTEM_PERIPH_LPTIM1 */
    RCC_APB1ENR2_LPTIM2EN,    /* STM32WB_SYSTEM_PERIPH_LPTIM2 */
    RCC_AHB1ENR_TSCEN,        /* STM32WB_SYSTEM_PERIPH_TSC */
    RCC_APB1ENR1_LCDEN,       /* STM32WB_SYSTEM_PERIPH_LCD */
    RCC_AHB3ENR_HSEMEN,       /* STM32WB_SYSTEM_PERIPH_HSEM */
    RCC_AHB3ENR_IPCCEN,       /* STM32WB_SYSTEM_PERIPH_IPCC */
    RCC_AHB1ENR_CRCEN,        /* STM32WB_SYSTEM_PERIPH_CRC */
    RCC_AHB3ENR_RNGEN,        /* STM32WB_SYSTEM_PERIPH_RNG */
    RCC_AHB2ENR_AES1EN,       /* STM32WB_SYSTEM_PERIPH_AES1 */
    RCC_AHB3ENR_AES2EN,       /* STM32WB_SYSTEM_PERIPH_AES2 */
    RCC_AHB3ENR_PKAEN,        /* STM32WB_SYSTEM_PERIPH_PKA */
};

void SystemInit(void)
{
    uint32_t flash_acr;

    RCC->CIER = 0x00000000;

    RCC->APB1ENR1 |= RCC_APB1ENR1_RTCAPBEN;

    /* Switch to Main Flash @ 0x00000000. Make sure the I/D CACHE is
     * disabled to avoid stale data in the cache.
     */

    flash_acr = FLASH->ACR;

    FLASH->ACR = flash_acr & ~(FLASH_ACR_ICEN | FLASH_ACR_DCEN);
	
    SYSCFG->MEMRMP = 0;

    PWR->CR1 |= PWR_CR1_DBP;
    
    while (!(PWR->CR1 & PWR_CR1_DBP))
    {
    }

    if (RCC->BDCR & RCC_BDCR_RTCEN)
    {
	RTC->WPR = 0xca;
	RTC->WPR = 0x53;
    
	/* If RTC_CR_BCK is set it means the reset was triggered to
	 * branch throu to the STM32 BOOTLOADER.
	 */
	if (RTC->CR & RTC_CR_BKP)
	{
	    RTC->CR &= ~RTC_CR_BKP;

	    RTC->WPR = 0x00;

	    SYSCFG->MEMRMP = SYSCFG_MEMRMP_MEM_MODE_0;

	    FLASH->ACR = (flash_acr & ~(FLASH_ACR_ICEN | FLASH_ACR_DCEN)) | (FLASH_ACR_ICRST | FLASH_ACR_DCRST);
	    FLASH->ACR = flash_acr;

	    RCC->AHB2ENR |= (RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOBEN | RCC_AHB2ENR_GPIOCEN); 

#if 0
	    GPIOA->LCKR = 0x0001e7ff;
	    GPIOA->LCKR = 0x0000e7ff;
	    GPIOA->LCKR = 0x0001e7ff;
	    GPIOA->LCKR;
#endif	    
	    /* Allow only USB/DFU and USART1 (PA9/PA10/PA11/PA12) */
	    GPIOA->LCKR = 0x0001e1ff;
	    GPIOA->LCKR = 0x0000e1ff;
	    GPIOA->LCKR = 0x0001e1ff;
	    GPIOA->LCKR;
	    GPIOB->LCKR = 0x0001ffff;
	    GPIOB->LCKR = 0x0000ffff;
	    GPIOB->LCKR = 0x0001ffff;
	    GPIOB->LCKR;
	    GPIOC->LCKR = 0x00011fff;
	    GPIOC->LCKR = 0x00001fff;
	    GPIOC->LCKR = 0x00011fff;
	    GPIOC->LCKR;

	    RCC->AHB2ENR &= ~(RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOBEN | RCC_AHB2ENR_GPIOCEN); 

	    RCC->APB1ENR1 &= ~RCC_APB1ENR1_RTCAPBEN;

	    /* This needs to be assembly code as GCC catches NULL 
	     * dereferences ...
	     */
	    __asm__ volatile ("   mov     r2, #0                         \n"
			      "   ldr     r0, [r2, #0]                   \n"
			      "   ldr     r1, [r2, #4]                   \n"
			      "   msr     MSP, r0                        \n"
			      "   dsb                                    \n"
			      "   isb                                    \n"
			      "   bx      r1                             \n");
	}
    }

    /* We should be at a 4MHz MSI clock, so switch to HSI16 for the
     * init code to be half way fast.
     */

    FLASH->ACR = (flash_acr & ~(FLASH_ACR_ICEN | FLASH_ACR_DCEN)) | (FLASH_ACR_ICRST | FLASH_ACR_DCRST);
    FLASH->ACR = FLASH_ACR_ICEN | FLASH_ACR_DCEN | FLASH_ACR_LATENCY_0WS;

    if (!(RCC->CR & RCC_CR_MSION))
    {
	RCC->CR = (RCC->CR & ~(RCC_CR_MSIRANGE | RCC_CR_MSIPLLEN)) | RCC_CR_MSIRANGE_6 | RCC_CR_MSION;
	
	while (!(RCC->CR & RCC_CR_MSIRDY))
	{
	}
    }
    
    if (!(RCC->CR & RCC_CR_HSION))
    {
	RCC->CR |= RCC_CR_HSION;
	
	while (!(RCC->CR & RCC_CR_HSIRDY))
	{
	}
    }

    if ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI)
    {
	RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_HSI;
	    
	while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI)
	{
	}
    }
    
    SCB->VTOR = (uint32_t)&__Vectors[0];
    
    /* Enable FPU early on.
     */
    SCB->CPACR |= 0x00f00000;

    /* Force FPU stacking. (FIX ARMV7M_WORK !!!)
     */
    FPU->FPCCR = 0x80000000;
    
    SystemCoreClock = 16000000;
}

void stm32wb_system_initialize(uint32_t hclk, uint32_t pclk1, uint32_t pclk2, uint32_t lseclk, uint32_t hseclk, uint32_t options)
{
    uint32_t count;
    uint32_t *data2a, *data2a_e, *bss2a, *bss2a_e;
    const uint32_t *data2a_f;
    
    __disable_irq();

    if (PWR->EXTSCR & PWR_EXTSCR_C1SBF)
    {
	stm32wb_system_device.reset = STM32WB_SYSTEM_RESET_STANDBY;
	stm32wb_system_device.wakeup = (PWR->SR1 & PWR_SR1_WUF);
	
	if (RCC->BDCR & RCC_BDCR_RTCEN)
	{
	    if (RTC->ISR & (RTC_ISR_ALRAF | RTC_ISR_ALRBF | RTC_ISR_TAMP1F | RTC_ISR_TAMP2F))
	    {
		if (RTC->ISR & RTC_ISR_ALRAF)
		{
		    stm32wb_system_device.wakeup |= STM32WB_SYSTEM_WAKEUP_ALARM;
		}
            
		if (RTC->ISR & RTC_ISR_ALRBF)
		{
		    stm32wb_system_device.wakeup |= STM32WB_SYSTEM_WAKEUP_TIMEOUT;
		}
	    
		if (RTC->ISR & RTC_ISR_TAMP1F)
		{
		    stm32wb_system_device.wakeup |= STM32WB_SYSTEM_WAKEUP_TAMP_1;
		}
	    
		if (RTC->ISR & RTC_ISR_TAMP2F)
		{
		    stm32wb_system_device.wakeup |= STM32WB_SYSTEM_WAKEUP_TAMP_2;
		}

		if (RTC->ISR & RTC_ISR_TAMP3F)
		{
		    stm32wb_system_device.wakeup |= STM32WB_SYSTEM_WAKEUP_TAMP_3;
		}
	    }
	}
	
        if (RCC->CSR & (RCC_CSR_IWDGRSTF | RCC_CSR_WWDGRSTF))
        {
            stm32wb_system_device.wakeup |= STM32WB_SYSTEM_WAKEUP_WATCHDOG;
        }
        
        if (RCC->CSR & (RCC_CSR_SFTRSTF | RCC_CSR_LPWRRSTF | RCC_CSR_OBLRSTF | RCC_CSR_BORRSTF))
        {
            stm32wb_system_device.wakeup |= STM32WB_SYSTEM_WAKEUP_RESET;
        }
    }
    else
    {
	stm32wb_system_device.reset = STM32WB_SYSTEM_RESET_POWERON;
	stm32wb_system_device.wakeup = STM32WB_SYSTEM_WAKEUP_NONE;

        if (RCC->CSR & RCC_CSR_SFTRSTF)
        {
            if (*((volatile uint32_t*)STM32WB_CRASH_SIGNATURE_ADDRESS) == STM32WB_CRASH_SIGNATURE_DATA)
            {
                stm32wb_system_device.reset = STM32WB_SYSTEM_RESET_CRASH;
            }
            else
            {
                stm32wb_system_device.reset = STM32WB_SYSTEM_RESET_SOFTWARE;
            }
        }
        else
        {
            if (RCC->CSR & (RCC_CSR_IWDGRSTF | RCC_CSR_WWDGRSTF))
            {
                stm32wb_system_device.reset = STM32WB_SYSTEM_RESET_WATCHDOG;
            }
            
            else if (RCC->CSR & (RCC_CSR_LPWRRSTF | RCC_CSR_OBLRSTF))
            {
                stm32wb_system_device.reset = STM32WB_SYSTEM_RESET_INTERNAL;
            }
            
            else if (RCC->CSR & RCC_CSR_BORRSTF)
            {
                stm32wb_system_device.reset = STM32WB_SYSTEM_RESET_POWERON;
            }
        }
    }
    
    RCC->CSR |= RCC_CSR_RMVF;
    RCC->CSR &= ~RCC_CSR_RMVF;

    PWR->SCR = (PWR_SCR_CWUF5 | PWR_SCR_CWUF4 | PWR_SCR_CWUF3 | PWR_SCR_CWUF2 | PWR_SCR_CWUF1);
    PWR->EXTSCR = PWR_EXTSCR_C1CSSF;
    

    /* Clear out pending RTC flags from a STANDBY return
     */

    if (RCC->BDCR & RCC_BDCR_RTCEN)
    {
	RTC->CR &= ~(RTC_CR_ALRBIE | RTC_CR_ALRAIE | RTC_CR_ALRBE | RTC_CR_ALRAE);
	RTC->TAMPCR &= ~(RTC_TAMPCR_TAMP3IE | RTC_TAMPCR_TAMP3E | RTC_TAMPCR_TAMP3IE | RTC_TAMPCR_TAMP2E | RTC_TAMPCR_TAMP1IE | RTC_TAMPCR_TAMP1E);
	RTC->ISR = 0;

	/* If RTC was setup wrong here, there is a Firmware mismatch ...
	 */
        if ((RTC->PRER & (RTC_PRER_PREDIV_S_Msk | RTC_PRER_PREDIV_A_Msk)) != (((STM32WB_RTC_PREDIV_S -1) << RTC_PRER_PREDIV_S_Pos) | ((STM32WB_RTC_PREDIV_A -1) << RTC_PRER_PREDIV_A_Pos)))
	{
	    RCC->BDCR &= ~RCC_BDCR_RTCEN;
	    RCC->BDCR |= RCC_BDCR_BDRST;
	}
    }

    RCC->BDCR &= ~RCC_BDCR_BDRST;

    *((volatile uint32_t*)STM32WB_CRASH_SIGNATURE_ADDRESS) = ~STM32WB_CRASH_SIGNATURE_DATA;

    
    if (lseclk)
    {
	if (options & STM32WB_SYSTEM_OPTION_LSE_BYPASS)
	{
	    RCC->BDCR |= RCC_BDCR_LSEBYP;
	}
	else
	{
	    if (!(RCC->BDCR & RCC_BDCR_LSEON))
	    {
		RCC->BDCR |= RCC_BDCR_LSEON;
		
		/* The loop below take about 8 cycles per iteration. The startup time for
		 * LSE is 5000ms. At 16MHz this corresponds to about 10000000 iterations.
		 */
		count = 0;
		
		while (!(RCC->BDCR & RCC_BDCR_LSERDY))
		{
		    if (++count >= 10000000)
		    {
		        lseclk = 0;
			
			RCC->BDCR &= ~RCC_BDCR_LSEON;
			break;
		    }
		}
	    }
	}
    }

    if (lseclk)
    {
	RCC->CSR &= ~RCC_CSR_LSI1ON;
	RCC->CR |= RCC_CR_MSIPLLEN;
    }
    else
    {
	RCC->CSR |= RCC_CSR_LSI1ON;
	
	while (!(RCC->CSR & RCC_CSR_LSI1RDY))
	{
	}

	stm32wb_system_device.lsi = 0x80;
    }

    if (hseclk)
    {
	if (!(options & STM32WB_SYSTEM_OPTION_HSE_BYPASS))
	{
	    RCC->CR |= RCC_CR_HSEON;
	
	    /* The loop below take about 8 cycles per iteration. The startup time for
	     * HSE is 100ms. At 16MHz this corresponds to about 200000 iterations.
	     */
	    count = 0;
	    
	    while (!(RCC->CR & RCC_CR_HSERDY))
	    {
		if (++count >= 200000)
		{
		    options &= ~STM32WB_SYSTEM_OPTION_HSE_SYSCLK;
		    hseclk = 0;
		    break;
		}
	    }

	    RCC->CR &= ~RCC_CR_HSEON;
	}
    }
    
    if (options & STM32WB_SYSTEM_OPTION_VBAT_CHARGING)
    {
	PWR->CR4 |= PWR_CR4_VBE;
    }

    /* Keep SRAM2a alive in STANDBY */
    PWR->CR3 |= PWR_CR3_RRS;

    if (stm32wb_system_device.reset != STM32WB_SYSTEM_RESET_STANDBY)
    {
	if (&__data2a_start__[0] != &__data2a_end__[0])
	{
	    data2a = (uint32_t*)&__data2a_start__[0];
	    data2a_e = (uint32_t*)&__data2a_end__[0];
	    data2a_f = (const uint32_t*)&__data2a_flash__[0];

	    do
	    {
		*data2a++ = *data2a_f++;
	    }
	    while (data2a != data2a_e);
	}

	if (&__bss2a_start__[0] != &__bss2a_end__[0])
	{
	    bss2a = (uint32_t*)&__bss2a_start__[0];
	    bss2a_e = (uint32_t*)&__bss2a_end__[0];

	    do
	    {
		*bss2a++ = 0x00000000;
	    }
	    while (bss2a != bss2a_e);
	}
    }

    /* Write protect .text2a/.rodata2a in SRAM2a and .text2b/.rodata2b in SRAM2b */
    SYSCFG->SWPR1 = (0xffffffff >> (32 - (((uint32_t)__rodata2a_end__ - (uint32_t)__text2a_start__ + 1023) / 1024))) << (((uint32_t)__text2a_start__ - SRAM2A_BASE + 1023) / 1024);
    SYSCFG->SWPR2 = (0xffffffff >> (32 - (((uint32_t)__rodata2b_end__ - (uint32_t)__text2b_start__ + 1023) / 1024))) << (((uint32_t)__text2b_start__ - SRAM2B_BASE + 1023) / 1024);

    /* HACKY ... */
    PWR->C2CR1 = (PWR->C2CR1 & ~PWR_C2CR1_LPMS) | PWR_C2CR1_LPMS_SHUTDOWN | PWR_C2CR1_FPDS;

    /* Disable SMPS for now ... */
    PWR->CR5 &= ~(PWR_CR5_SMPSEN | PWR_CR5_BORHC);
    RCC->SMPSCR = (RCC->SMPSCR & ~RCC_SMPSCR_SMPSSEL) | RCC_SMPSCR_SMPSSEL_HSI;
    
    if (options & (STM32WB_SYSTEM_OPTION_SMPS_INDUCTOR_10uH | STM32WB_SYSTEM_OPTION_SMPS_INDUCTOR_2_2uH))
    {
	RCC->SMPSCR = (RCC->SMPSCR & ~RCC_SMPSCR_SMPSDIV) | ((options & STM32WB_SYSTEM_OPTION_SMPS_INDUCTOR_10uH) ? RCC_SMPSCR_SMPSDIV_0 : 0);

	PWR->CR5 = (PWR->CR5 & ~PWR_CR5_SMPSSC) | PWR_CR5_BORHC | (((options & STM32WB_SYSTEM_OPTION_SMPS_CURRENT_MASK) >> STM32WB_SYSTEM_OPTION_SMPS_CURRENT_SHIFT) << PWR_CR5_SMPSSC_Pos);
    }
    
    /* Setup DBGMCU so that debugging (other than SLEEP/STOP/STANDBY) works like expected.
     */
    DBGMCU->CR       = DBGMCU_CR_DBG_SLEEP;
    DBGMCU->APB1FZR1 = (DBGMCU_APB1FZR1_DBG_TIM2_STOP |
			DBGMCU_APB1FZR1_DBG_RTC_STOP |
			DBGMCU_APB1FZR1_DBG_IWDG_STOP |
			DBGMCU_APB1FZR1_DBG_I2C1_STOP |
			DBGMCU_APB1FZR1_DBG_I2C3_STOP |
			DBGMCU_APB1FZR1_DBG_LPTIM1_STOP);
    DBGMCU->APB1FZR2 = (DBGMCU_APB1FZR2_DBG_LPTIM2_STOP);
    DBGMCU->APB2FZR  = 0;

    /* ERRATA 2.2.8: Incomplete Stop 2 mode entry after a wakeup from debug upon EXTI line 48 event */
    EXTI->IMR2 &= ~EXTI_IMR2_IM48;
    EXTI->C2IMR2 &= ~EXTI_C2IMR2_IM48;
    
    /* Setup default SLEEP mode settings */
    RCC->AHB1SMENR  = (RCC_AHB1SMENR_DMA1SMEN |
		       RCC_AHB1SMENR_DMA2SMEN |
		       RCC_AHB1SMENR_DMAMUX1SMEN |
		       RCC_AHB1SMENR_CRCSMEN |
		       RCC_AHB1SMENR_TSCSMEN);

    RCC->AHB2SMENR  = (RCC_AHB2SMENR_ADCSMEN |
		       RCC_AHB2SMENR_AES1SMEN);

    RCC->AHB3SMENR  = (RCC_AHB3SMENR_QUADSPISMEN |
		       RCC_AHB3SMENR_PKASMEN |
		       RCC_AHB3SMENR_AES2SMEN |
		       RCC_AHB3SMENR_RNGSMEN);
    
    RCC->APB1SMENR1 = (RCC_APB1SMENR1_TIM2SMEN |
		       RCC_APB1SMENR1_LCDSMEN |
		       RCC_APB1SMENR1_SPI2SMEN |
		       RCC_APB1SMENR1_I2C1SMEN |
		       RCC_APB1SMENR1_I2C3SMEN |
		       RCC_APB1SMENR1_CRSSMEN |
		       RCC_APB1SMENR1_USBSMEN |
		       RCC_APB1SMENR1_LPTIM1SMEN);
		       
    RCC->APB1SMENR2 = (RCC_APB1SMENR2_LPUART1SMEN |
		       RCC_APB1SMENR1_LPTIM1SMEN);

    RCC->APB2SMENR  = (RCC_APB2SMENR_TIM1SMEN |
		       RCC_APB2SMENR_SPI1SMEN |
		       RCC_APB2SMENR_USART1SMEN |
		       RCC_APB2SMENR_TIM16SMEN |
		       RCC_APB2SMENR_TIM17SMEN |
		       RCC_APB2SMENR_SAI1SMEN);

    /* Setup the independent clocks for the peripherals to HSI16, except
     * LUPART which is LSE. CLK48 is driven by HSI48 with CRS.
     */
    RCC->CCIPR = (0 |                                               /* RNG is CLK48/LSE/LSI   */
		  RCC_CCIPR_ADCSEL_1 | RCC_CCIPR_ADCSEL_0 |         /* ADC is SYSCLK          */
		  0 |                                               /* CLK48 is HSI48         */
		  0 |                                               /* SAI1SEL is PLLSAI1 "P" */
		  RCC_CCIPR_LPTIM2SEL_1 |                           /* LPTIM2 is HSI16        */
		  RCC_CCIPR_LPTIM1SEL_1 | RCC_CCIPR_LPTIM1SEL_0 |   /* LPTIM1 is LSE          */
		  RCC_CCIPR_I2C3SEL_1 |                             /* I2C3 is HSI16          */
		  RCC_CCIPR_I2C1SEL_1 |                             /* I2C1 is HSI16          */
		  RCC_CCIPR_LPUART1SEL_1 |                          /* LPUART1 is HSI16       */
		  RCC_CCIPR_USART1SEL_1);                           /* USART1 is HSI16        */

    stm32wb_system_device.options = options;
    stm32wb_system_device.lseclk = lseclk;
    stm32wb_system_device.hseclk = hseclk;
    
    __armv7m_core_initialize();
    
    __stm32wb_gpio_initialize();
    __stm32wb_exti_initialize();
    __stm32wb_dma_initialize();
    __stm32wb_rtc_initialize();
    __stm32wb_lptim_initialize();

    /* Force full update path for stm32wb_system_sysclk_configure().
     */

    stm32wb_system_device.sysclk = 0;
    stm32wb_system_device.pllsys = false;
    stm32wb_system_device.smps = false;
    stm32wb_system_device.palevel = 0x00;
    
    stm32wb_system_sysclk_configure(hclk, pclk1, pclk2);
    
    __enable_irq();
}

bool stm32wb_system_sysclk_configure(uint32_t hclk, uint32_t pclk1, uint32_t pclk2)
{
    uint32_t primask, sysclk, fclk, hclk2, pllcfg, pllmsi, msirange, hpre, ppre1, ppre2, c2hpre, c1spre[2], latency, smpsvos;
    bool pllsys, smps;

    msirange = RCC_CR_MSIRANGE_6;

    pllsys = false;
    pllmsi = 0;

    smps = false;
    smpsvos = 8;
    
    if (stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_CPU2)
    {
	/* SHCI_C2_SetFlashActivityControl(FLASH_ACTIVITY_CONTROL_SEM7); */
    
	hclk2 = 32000000;

        sysclk = (hclk > hclk2) ? hclk : hclk2;
    }
    else
    {
	hclk2 = 0;

        sysclk = hclk;
    }

    if ((stm32wb_system_device.options & STM32WB_SYSTEM_OPTION_HSE_SYSCLK) && (sysclk >= 32000000))
    {

	if (sysclk < 64000000)
	{
	    sysclk = 32000000;

	    pllcfg = (((8-1) << RCC_PLLCFGR_PLLM_Pos) | RCC_PLLCFGR_PLLSRC_HSE);
	}
	else
	{
	    sysclk = 64000000;

	    pllcfg = ((1 << RCC_PLLCFGR_PLLR_Pos) | (sysclk / (4000000 / 2)) << RCC_PLLCFGR_PLLN_Pos) | (((8-1) << RCC_PLLCFGR_PLLM_Pos) | RCC_PLLCFGR_PLLSRC_HSE);
	
	    pllsys = true;
	}
    }
    else
    {
	if (sysclk < 64000000)
	{
	    /* Use MSI */

	    if      (sysclk >= 32000000) { sysclk = 32000000; msirange = RCC_CR_MSIRANGE_10; pllcfg = (((8-1) << RCC_PLLCFGR_PLLM_Pos) | RCC_PLLCFGR_PLLSRC_MSI); pllmsi = 977; } /*  977 * 32768 */
	    else if (sysclk >= 16000000) { sysclk = 16000000; msirange = RCC_CR_MSIRANGE_8;  pllcfg = (((4-1) << RCC_PLLCFGR_PLLM_Pos) | RCC_PLLCFGR_PLLSRC_MSI); pllmsi = 488; } /*  488 * 32768 */
	    else                         { sysclk =  2000000; msirange = RCC_CR_MSIRANGE_5;  pllcfg = RCC_PLLCFGR_PLLSRC_NONE;                                    pllmsi =  61; } /*   61 * 32768 */
	}
	else
	{
	    sysclk = 64000000;

	    pllcfg = ((1 << RCC_PLLCFGR_PLLR_Pos) | (sysclk / (4000000 / 2)) << RCC_PLLCFGR_PLLN_Pos) | (((1-1) << RCC_PLLCFGR_PLLM_Pos) | RCC_PLLCFGR_PLLSRC_MSI);
	    pllmsi = 122 * 16;

	    pllsys = true;
	}
    }
    
    if ((sysclk > 16000000) && (stm32wb_system_device.options & (STM32WB_SYSTEM_OPTION_SMPS_INDUCTOR_10uH | STM32WB_SYSTEM_OPTION_SMPS_INDUCTOR_2_2uH)))
    {
	smps = true;
	
	smpsvos = ((*((const uint32_t*)0x1fff7558) >> 8) & 15);

	if      (stm32wb_system_device.palevel == 0x1f) { smpsvos += 5; } /* 1750mV */
	else if (stm32wb_system_device.palevel == 0x1e) { smpsvos += 2; } /* 1600mV */
	else                                            { smpsvos -= 1; } /* 1450mV */
    }
    
    if      (hclk >= (sysclk /   1) ) { hclk = (sysclk /   1); hpre = RCC_CFGR_HPRE_DIV1;   fclk = (pllmsi * 32768); }
    else if (hclk >= (sysclk /   2) ) { hclk = (sysclk /   2); hpre = RCC_CFGR_HPRE_DIV2;   fclk = (pllmsi * 16384); }
    else if (hclk >= (sysclk /   4) ) { hclk = (sysclk /   4); hpre = RCC_CFGR_HPRE_DIV4;   fclk = (pllmsi *  8192); }
    else if (hclk >= (sysclk /   8) ) { hclk = (sysclk /   8); hpre = RCC_CFGR_HPRE_DIV8;   fclk = (pllmsi *  4096); }
    else if (hclk >= (sysclk /  16) ) { hclk = (sysclk /  16); hpre = RCC_CFGR_HPRE_DIV16;  fclk = (pllmsi *  2048); }
    else if (hclk >= (sysclk /  32) ) { hclk = (sysclk /  32); hpre = RCC_CFGR_HPRE_DIV32;  fclk = (pllmsi *  1024); }
    else if (hclk >= (sysclk /  64) ) { hclk = (sysclk /  64); hpre = RCC_CFGR_HPRE_DIV64;  fclk = (pllmsi *   512); }
    else if (hclk >= (sysclk / 128) ) { hclk = (sysclk / 128); hpre = RCC_CFGR_HPRE_DIV128; fclk = (pllmsi *   256); }
    else if (hclk >= (sysclk / 256) ) { hclk = (sysclk / 256); hpre = RCC_CFGR_HPRE_DIV256; fclk = (pllmsi *   128); }
    else                              { hclk = (sysclk / 512); hpre = RCC_CFGR_HPRE_DIV512; fclk = (pllmsi *    64); }

    if (fclk == 0)
    {
	fclk = hclk;
    }
    
    if      (hclk2 >= (sysclk /   1) ) { hclk2 = (sysclk /   1); c2hpre = RCC_EXTCFGR_C2HPRE_DIV1;   }
    else if (hclk2 >= (sysclk /   2) ) { hclk2 = (sysclk /   2); c2hpre = RCC_EXTCFGR_C2HPRE_DIV2;   }
    else if (hclk2 >= (sysclk /   4) ) { hclk2 = (sysclk /   4); c2hpre = RCC_EXTCFGR_C2HPRE_DIV4;   }
    else if (hclk2 >= (sysclk /   8) ) { hclk2 = (sysclk /   8); c2hpre = RCC_EXTCFGR_C2HPRE_DIV8;   }
    else if (hclk2 >= (sysclk /  16) ) { hclk2 = (sysclk /  16); c2hpre = RCC_EXTCFGR_C2HPRE_DIV16;  }
    else if (hclk2 >= (sysclk /  32) ) { hclk2 = (sysclk /  32); c2hpre = RCC_EXTCFGR_C2HPRE_DIV32;  }
    else if (hclk2 >= (sysclk /  64) ) { hclk2 = (sysclk /  64); c2hpre = RCC_EXTCFGR_C2HPRE_DIV64;  }
    else if (hclk2 >= (sysclk / 128) ) { hclk2 = (sysclk / 128); c2hpre = RCC_EXTCFGR_C2HPRE_DIV128; }
    else if (hclk2 >= (sysclk / 256) ) { hclk2 = (sysclk / 256); c2hpre = RCC_EXTCFGR_C2HPRE_DIV256; }
    else                               { hclk2 = (sysclk / 512); c2hpre = RCC_EXTCFGR_C2HPRE_DIV512; }
    
    if (pclk1)
    {
	if      (pclk1 >= (hclk / 1))  { pclk1 = hclk / 1;  ppre1 = RCC_CFGR_PPRE1_DIV1;  }
	else if (pclk1 >= (hclk / 2))  { pclk1 = hclk / 2;  ppre1 = RCC_CFGR_PPRE1_DIV2;  }
	else if (pclk1 >= (hclk / 4))  { pclk1 = hclk / 4;  ppre1 = RCC_CFGR_PPRE1_DIV4;  }
	else if (pclk1 >= (hclk / 8))  { pclk1 = hclk / 8;  ppre1 = RCC_CFGR_PPRE1_DIV8;  }
	else                           { pclk1 = hclk / 16; ppre1 = RCC_CFGR_PPRE1_DIV16; }
    }
    else
    {
	if      (hclk <= 2000000)   { pclk1 = hclk / 1; ppre1 = RCC_CFGR_PPRE1_DIV1; }
	else if (hclk <= 32000000)  { pclk1 = hclk / 2; ppre1 = RCC_CFGR_PPRE1_DIV2; }
	else                        { pclk1 = hclk / 4; ppre1 = RCC_CFGR_PPRE1_DIV4; }
    }

    if (pclk2)
    {
	if      (pclk2 >= (hclk / 1))  { pclk2 = hclk / 1;  ppre2 = RCC_CFGR_PPRE2_DIV1;  }
	else if (pclk2 >= (hclk / 2))  { pclk2 = hclk / 2;  ppre2 = RCC_CFGR_PPRE2_DIV2;  }
	else if (pclk2 >= (hclk / 4))  { pclk2 = hclk / 4;  ppre2 = RCC_CFGR_PPRE2_DIV4;  }
	else if (pclk2 >= (hclk / 8))  { pclk2 = hclk / 8;  ppre2 = RCC_CFGR_PPRE2_DIV8;  }
	else                           { pclk2 = hclk / 16; ppre2 = RCC_CFGR_PPRE2_DIV16; }
    }
    else
    {
	if   (hclk <= 2000000) { pclk2 = hclk / 1; ppre2 = RCC_CFGR_PPRE2_DIV1; }
	else                   { pclk2 = hclk / 2; ppre2 = RCC_CFGR_PPRE2_DIV2; }
    }

    if (hclk <= 16000000)
    {
	if      (sysclk <=  60000000) { latency = FLASH_ACR_LATENCY_0WS; }
	else if (sysclk <= 120000000) { latency = FLASH_ACR_LATENCY_1WS; }
	else                          { latency = FLASH_ACR_LATENCY_2WS; }
    } 
    else
    {
	if      (sysclk <=  16000000) { latency = FLASH_ACR_LATENCY_0WS; }
	else if (sysclk <=  32000000) { latency = FLASH_ACR_LATENCY_1WS; }
	else if (sysclk <=  48000000) { latency = FLASH_ACR_LATENCY_2WS; }
	else                          { latency = FLASH_ACR_LATENCY_3WS; }
    }

    c1spre[0] = hpre | ppre1 | ppre2;

    if (hclk > 2000000)
    {
	if (hclk >= 32000000)
	{
	    /* HCLK2 is max 32Mhz, so SYSCLK is always HCLK */
	    c1spre[1] = (RCC_CFGR_HPRE_DIV8 | RCC_CFGR_PPRE1_DIV1 | RCC_CFGR_PPRE2_DIV1);
	}
	else
	{
	    if (sysclk >= 32000000) { c1spre[1] = (RCC_CFGR_HPRE_DIV16 | RCC_CFGR_PPRE1_DIV1 | RCC_CFGR_PPRE2_DIV1); }
	    else                    { c1spre[1] = (RCC_CFGR_HPRE_DIV8  | RCC_CFGR_PPRE1_DIV1 | RCC_CFGR_PPRE2_DIV1); }
	}
    }
    else
    {
	c1spre[1] = c1spre[0];
    }

    c2hpre = RCC_EXTCFGR_C2HPRE_DIV512;

    primask = __get_PRIMASK();
    
    __disable_irq();
    
    if (stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_CLOCKS] ||
	stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_RUN] ||
        ((stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_USB) && (pclk1 < 16000000)))
    {
	__set_PRIMASK(primask);
	
	return false;
    }

    if (sysclk <= STM32WB_SYSTEM_FREQUENCY_RANGE_2)
    {
	if (sysclk <= STM32WB_SYSTEM_FREQUENCY_LPRUN)
	{
	    stm32wb_system_device.reference = stm32wb_system_device.reference & ~(STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_1 | STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_2);
	}
	else
	{
	    stm32wb_system_device.reference = (stm32wb_system_device.reference & ~STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_1) | STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_2;
	}
    }
    else
    {
	stm32wb_system_device.reference = (stm32wb_system_device.reference & ~STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_2) | STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_1;
    }

    if (stm32wb_system_device.sysclk < sysclk)
    {
	/* Leave LPrun */
	if (PWR->CR1 & PWR_CR1_LPR)
	{
	    PWR->CR1 &= ~PWR_CR1_LPR;
	    
	    while (PWR->SR2 & PWR_SR2_REGLPF)
	    {
	    }
	}
	
	/* Leave to Range 2 */
	if ((PWR->CR1 & PWR_CR1_VOS) != PWR_CR1_VOS_RANGE_1)
	{
	    PWR->CR1 = (PWR->CR1 & ~PWR_CR1_VOS) | PWR_CR1_VOS_RANGE_1;
	    
	    while (PWR->SR2 & PWR_SR2_VOSF)
	    {
	    }
	}
	
	/* FLASH LOCK (SEM2) */

	FLASH->ACR = FLASH_ACR_ICEN | FLASH_ACR_DCEN | FLASH_ACR_LATENCY_3WS;

	/* FLASH UNLOCK (SEM2) */
    }

    if (stm32wb_system_device.smps && !smps)
    {
	PWR->CR5 &= ~PWR_CR5_SMPSEN;
    }
    
    armv7m_systick_disable();
    
    /* RCC LOCK (SEM3) */

    if (stm32wb_system_device.sysclk != sysclk)
    {
	if ((stm32wb_system_device.options & STM32WB_SYSTEM_OPTION_HSE_SYSCLK) && (sysclk >= 32000000))
	{
	    if (!stm32wb_system_device.hse)
	    {
		RCC->CR |= RCC_CR_HSEON;
		
		while (!(RCC->CR & RCC_CR_HSERDY))
		{
		}
	    }
	    
	    stm32wb_system_device.hse |= 0x80;
	    stm32wb_system_device.msi &= ~0x80;
	}
	else
	{
	    if (!stm32wb_system_device.msi)
	    {
		RCC->CR = (RCC->CR & ~(RCC_CR_MSIRANGE | RCC_CR_MSIPLLEN)) | msirange | RCC_CR_MSION;
		
		while (!(RCC->CR & RCC_CR_MSIRDY))
		{
		}
		
		if (stm32wb_system_device.lseclk)
		{
		    RCC->CR |= RCC_CR_MSIPLLEN;
		}
	    }
	    
	    stm32wb_system_device.hse &= ~0x80;
	    stm32wb_system_device.msi |= 0x80;
	}

	if (smps)
	{
	    if (!stm32wb_system_device.hsi16)
	    {
		RCC->CR |= RCC_CR_HSION;
		
		while (!(RCC->CR & RCC_CR_HSIRDY))
		{
		}
	    }
	    
	    stm32wb_system_device.hsi16 |= 0x80;
	    
	    /* HSI16 is wakeup clock */
	    RCC->CFGR |= RCC_CFGR_STOPWUCK;
	}
	else
	{
	    stm32wb_system_device.hsi16 &= ~0x80;
	    
	    /* MSI is wakeup clock */
	    RCC->CFGR &= ~RCC_CFGR_STOPWUCK;
	}

	RCC->CFGR = (RCC->CFGR & ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2 | RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F)) | (RCC_CFGR_HPRE_DIV1 | RCC_CFGR_PPRE1_DIV1 | RCC_CFGR_PPRE2_DIV1);

	while ((RCC->CFGR & (RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F)) != (RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F))
	{
	}

	RCC->EXTCFGR = (RCC->EXTCFGR & ~(RCC_EXTCFGR_C2HPRE | RCC_EXTCFGR_C2HPREF)) | RCC_EXTCFGR_C2HPRE_DIV2;

	while ((RCC->EXTCFGR & RCC_EXTCFGR_C2HPREF) != RCC_EXTCFGR_C2HPREF)
	{
	}
	
	if (stm32wb_system_device.pllsys)
	{
	    if (stm32wb_system_device.hse)
	    {
		RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_HSE;
		
		while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSE)
		{
		}
	    }
	    else
	    {
		RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_MSI;
		
		while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_MSI)
		{
		}
	    }
	    
	    RCC->PLLCFGR &= ~RCC_PLLCFGR_PLLREN;
	    
	    RCC->CR &= ~RCC_CR_PLLON;
	    
	    while (RCC->CR & RCC_CR_PLLRDY)
	    {
	    }
	}

	if (stm32wb_system_device.msi)
	{
	    if ((RCC->CR & RCC_CR_MSIRANGE) != msirange)
	    {
		RCC->CR = (RCC->CR & ~(RCC_CR_MSIRANGE | RCC_CR_MSIPLLEN)) | msirange;
		__DSB();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
		__NOP();
	    
		while (!(RCC->CR & RCC_CR_MSIRDY))
		{
		}
	    
		if (stm32wb_system_device.lseclk)
		{
		    RCC->CR |= RCC_CR_MSIPLLEN;
		}
	    }
	}
	
	if (pllsys)
	{
	    /* Use PLL via HSE/MSI */
	    
	    RCC->PLLCFGR = pllcfg | RCC_PLLCFGR_PLLREN;
	    
	    RCC->CR |= RCC_CR_PLLON;
	    
	    while (!(RCC->CR & RCC_CR_PLLRDY))
	    {
	    }
	    
	    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_PLL;
	    
	    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL)
	    {
	    }
	}
	else
	{
	    /* Use HSE/MSI */

	    RCC->PLLCFGR = pllcfg;

	    if (stm32wb_system_device.hse)
	    {
		RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_HSE;
		
		while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSE)
		{
		}
	    }
	    else
	    {
		RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_MSI;
		
		while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_MSI)
		{
		}
	    }
	}
    }
    
    RCC->CFGR = (RCC->CFGR & ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2 | RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F)) | (hpre | ppre1 | ppre2);
    
    while ((RCC->CFGR & (RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F)) != (RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F))
    {
    }
    
    RCC->EXTCFGR = (RCC->EXTCFGR & ~(RCC_EXTCFGR_C2HPRE | RCC_EXTCFGR_C2HPREF)) | c2hpre;
    
    while ((RCC->EXTCFGR & RCC_EXTCFGR_C2HPREF) != RCC_EXTCFGR_C2HPREF)
    {
    }
    
    if (!stm32wb_system_device.hsi16)
    {
	RCC->CR &= ~RCC_CR_HSION;
    }

    if (!stm32wb_system_device.msi)
    {
	RCC->CR &= ~RCC_CR_MSION;
    }

    if (!stm32wb_system_device.hse)
    {
	RCC->CR &= ~RCC_CR_HSEON;
    }
    
    /* RCC UNLOCK (SEM3) */

    /* FLASH LOCK (SEM2) */

    FLASH->ACR = FLASH_ACR_ICEN | FLASH_ACR_DCEN | latency;

    /* FLASH LOCK (SEM3) */

    if (smps)
    {
	do
	{
	    PWR->CR5 = (PWR->CR5 & ~PWR_CR5_SMPSVOS) | (smpsvos << PWR_CR5_SMPSVOS_Pos);
	}
	while ((PWR->CR5 & PWR_CR5_SMPSVOS) != (smpsvos << PWR_CR5_SMPSVOS_Pos));

	PWR->CR5 |= PWR_CR5_SMPSEN;
    }

    /* Enter Range 2 */
    if (!(stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_RANGE_1))
    {
	if ((PWR->CR1 & PWR_CR1_VOS) != PWR_CR1_VOS_RANGE_2)
	{
	    PWR->CR1 = (PWR->CR1 & ~PWR_CR1_VOS) | PWR_CR1_VOS_RANGE_2;
	    
	    while (PWR->SR2 & PWR_SR2_VOSF)
	    {
	    }
	}
    }
    
    /* Enter LPrun */
    if (!(stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_RANGE_1_2))
    {
	if (!(PWR->CR1 & PWR_CR1_LPR))
	{
	    PWR->CR1 |= PWR_CR1_LPR;
	    
	    while (!(PWR->SR2 & PWR_SR2_REGLPF))
	    {
	    }
	}
    }

    SystemCoreClock = hclk;

    stm32wb_system_device.sysclk = sysclk;
    stm32wb_system_device.hclk   = hclk;
    stm32wb_system_device.pclk1  = pclk1;
    stm32wb_system_device.pclk2  = pclk2;

    stm32wb_system_device.pllsys    = pllsys;
    stm32wb_system_device.smps      = smps;
    stm32wb_system_device.c1spre[0] = c1spre[0];
    stm32wb_system_device.c1spre[1] = c1spre[1];
    stm32wb_system_device.c2hpre    = c2hpre;

    armv7m_systick_configure(fclk);
    
    armv7m_systick_enable();
    
    stm32wb_system_notify(STM32WB_SYSTEM_NOTIFY_CLOCKS);

    __set_PRIMASK(primask);
    
    return true;
}

static void stm32wb_system_voltage_increase(void)
{
    /* CALLED WITH RCC LOCK (SEM3) */

    /* Leave LPrun */
    if (stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_RANGE_1_2)
    {
	if (PWR->CR1 & PWR_CR1_LPR)
	{
	    armv7m_atomic_and(&PWR->CR1, ~PWR_CR1_LPR);
	
	    while (PWR->SR2 & PWR_SR2_REGLPF)
	    {
	    }
	}
    }
    
    /* Leave Range 2 */
    if (stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_RANGE_1)
    {
	if ((PWR->CR1 & PWR_CR1_VOS) != PWR_CR1_VOS_RANGE_1)
	{
	    armv7m_atomic_modify(&PWR->CR1, PWR_CR1_VOS, PWR_CR1_VOS_RANGE_1);
	    
	    while (PWR->SR2 & PWR_SR2_VOSF)
	    {
	    }
	}
    }
}

static void stm32wb_system_voltage_decrease(void)
{
    /* CALLED WITH RCC LOCK (SEM3) */

    /* Enter Range 2 */
    if (!(stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_RANGE_1))
    {
	if ((PWR->CR1 & PWR_CR1_VOS) != PWR_CR1_VOS_RANGE_2)
	{
	    armv7m_atomic_modifyz(&PWR->CR1, PWR_CR1_VOS, PWR_CR1_VOS_RANGE_2, &stm32wb_system_device.reference, STM32WB_SYSTEM_REFERENCE_RANGE_1);
	    
	    while (PWR->SR2 & PWR_SR2_VOSF)
	    {
		if (stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_RANGE_1)
		{
		    break;
		}
	    }
	}
    }
    
    /* Enter LPrun */
    if (!(stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_RANGE_1_2))
    {
	if (!(PWR->CR1 & PWR_CR1_LPR))
	{
	    armv7m_atomic_orz(&PWR->CR1, PWR_CR1_LPR, &stm32wb_system_device.reference, STM32WB_SYSTEM_REFERENCE_RANGE_1_2);
	    
	    while (!(PWR->SR2 & PWR_SR2_REGLPF))
	    {
		if (stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_RANGE_1_2)
		{
		    break;
		}
	    }
	}
    }
}

bool stm32wb_system_saiclk_configure(uint32_t saiclk)
{
    uint32_t reference, pllcfg;

    if (stm32wb_system_device.saiclk != saiclk)
    {
	stm32wb_system_unreference(STM32WB_SYSTEM_REFERENCE_SAICLK_RANGE_1 | STM32WB_SYSTEM_REFERENCE_SAICLK_RANGE_2);

	if (saiclk != STM32WB_SYSTEM_SAICLK_NONE)
	{
	    /* 4MHz PLL input */
	    switch (saiclk) {
	    case STM32WB_SYSTEM_SAICLK_11289600:
	      reference = STM32WB_SYSTEM_REFERENCE_SAICLK_RANGE_1;
	      pllcfg = (((28 -1) << RCC_PLLSAI1CFGR_PLLP_Pos) | (79 << RCC_PLLSAI1CFGR_PLLN_Pos) | RCC_PLLSAI1CFGR_PLLPEN);
	      break;

	    case STM32WB_SYSTEM_SAICLK_24576000:
	      reference = STM32WB_SYSTEM_REFERENCE_SAICLK_RANGE_1;
	      pllcfg = ((( 7 -1) << RCC_PLLSAI1CFGR_PLLP_Pos) | (43 << RCC_PLLSAI1CFGR_PLLN_Pos) | RCC_PLLSAI1CFGR_PLLPEN);
	      break;
	      
	    case STM32WB_SYSTEM_SAICLK_49152000:
	      reference = STM32WB_SYSTEM_REFERENCE_SAICLK_RANGE_1;
	      pllcfg = ((( 7 -1) << RCC_PLLSAI1CFGR_PLLP_Pos) | (86 << RCC_PLLSAI1CFGR_PLLN_Pos) | RCC_PLLSAI1CFGR_PLLPEN);
	      break;

	    default:
		return false;
	    }

	    stm32wb_system_reference(reference);

	    /* RCC LOCK (SEM3) */
	    
	    if (stm32wb_system_device.saiclk < saiclk)
	    {
		stm32wb_system_voltage_increase();
	    }

	    armv7m_atomic_and(&RCC->CR, ~RCC_CR_PLLSAI1ON);

	    while (RCC->CR & RCC_CR_PLLSAI1RDY)
	    {
	    }

	    RCC->PLLSAI1CFGR = pllcfg;

	    armv7m_atomic_or(&RCC->CR, RCC_CR_PLLSAI1ON);
	    
	    while (!(RCC->CR & RCC_CR_PLLSAI1RDY))
	    {
	    }

	    if (stm32wb_system_device.saiclk > saiclk)
	    {
		stm32wb_system_voltage_decrease();
	    }

	    /* RCC UNLOCK (SEM3) */
	}
	else
	{
	    /* RCC LOCK (SEM3) */

	    armv7m_atomic_and(&RCC->CR, ~RCC_CR_PLLSAI1ON);

	    while (RCC->CR & RCC_CR_PLLSAI1RDY)
	    {
	    }

	    stm32wb_system_voltage_decrease();

	    /* RCC UNLOCK (SEM3) */
	}
	
	stm32wb_system_device.saiclk = saiclk;
    }

    return true;
}

void stm32wb_system_mco_configure(uint32_t mco)
{
    uint32_t mcosel, mcopre;

    /* RCC LOCK (SEM3) */

    armv7m_atomic_and(&RCC->CFGR, ~(RCC_CFGR_MCOSEL | RCC_CFGR_MCOPRE));

    /* RCC UNLOCK (SEM3) */
    
    switch (stm32wb_system_device.mco & STM32WB_SYSTEM_MCO_SOURCE_MASK) {
    case STM32WB_SYSTEM_MCO_SOURCE_NONE:
    case STM32WB_SYSTEM_MCO_SOURCE_SYSCLK:
    case STM32WB_SYSTEM_MCO_SOURCE_MSI:
    case STM32WB_SYSTEM_MCO_SOURCE_HSE:
    case STM32WB_SYSTEM_MCO_SOURCE_PLL:
    case STM32WB_SYSTEM_MCO_SOURCE_LSE:
	break;
	
    case STM32WB_SYSTEM_MCO_SOURCE_LSI:
	stm32wb_system_lsi_disable();
	break;
	
    case STM32WB_SYSTEM_MCO_SOURCE_HSI16:
	stm32wb_system_hsi16_disable();
	break;
	
    case STM32WB_SYSTEM_MCO_SOURCE_HSI48:
	stm32wb_system_hsi48_disable(0);
	break;
    }
    
    stm32wb_system_device.mco = mco;
    
    switch (mco & STM32WB_SYSTEM_MCO_SOURCE_MASK) {
    case STM32WB_SYSTEM_MCO_SOURCE_NONE:
    case STM32WB_SYSTEM_MCO_SOURCE_SYSCLK:
    case STM32WB_SYSTEM_MCO_SOURCE_MSI:
    case STM32WB_SYSTEM_MCO_SOURCE_HSE:
    case STM32WB_SYSTEM_MCO_SOURCE_PLL:
    case STM32WB_SYSTEM_MCO_SOURCE_LSE:
	break;
	
    case STM32WB_SYSTEM_MCO_SOURCE_LSI:
	stm32wb_system_lsi_enable();
	break;
	
    case STM32WB_SYSTEM_MCO_SOURCE_HSI16:
	stm32wb_system_hsi16_enable();
	break;
	
    case STM32WB_SYSTEM_MCO_SOURCE_HSI48:
	stm32wb_system_hsi48_enable(0);
	break;
    }

    mcosel = (mco & STM32WB_SYSTEM_MCO_SOURCE_MASK) >> STM32WB_SYSTEM_MCO_SOURCE_SHIFT;
    mcopre = (mco & STM32WB_SYSTEM_MCO_DIVIDE_MASK) >> STM32WB_SYSTEM_MCO_DIVIDE_SHIFT;

    /* RCC LOCK (SEM3) */

    armv7m_atomic_or(&RCC->CFGR, ((mcosel << RCC_CFGR_MCOSEL_Pos) | (mcopre << RCC_CFGR_MCOPRE_Pos)));

    /* RCC UNLOCK (SEM3) */
}

void stm32wb_system_lsco_configure(uint32_t lsco)
{
    armv7m_atomic_and(&RCC->BDCR, ~(RCC_BDCR_LSCOEN | RCC_BDCR_LSCOSEL));

    if (stm32wb_system_device.lsco == STM32WB_SYSTEM_LSCO_SOURCE_LSI)
    {
	stm32wb_system_lsi_disable();
    }

    stm32wb_system_device.lsco = lsco;

    if (stm32wb_system_device.lsco == STM32WB_SYSTEM_LSCO_SOURCE_LSI)
    {
	stm32wb_system_lsi_enable();
	
	armv7m_atomic_or(&RCC->BDCR, RCC_BDCR_LSCOSEL);
    }
    
    if (stm32wb_system_device.lsco != STM32WB_SYSTEM_LSCO_SOURCE_NONE)
    {
	armv7m_atomic_or(&RCC->BDCR, RCC_BDCR_LSCOEN);
    }
}

void stm32wb_system_lsi_enable(void)
{
    armv7m_atomic_incb(&stm32wb_system_device.lsi);

    if (!(stm32wb_system_device.lsi & 0x80))
    {
	armv7m_atomic_or(&RCC->CSR, RCC_CSR_LSI1ON);
    
	while (!(RCC->CSR & RCC_CSR_LSI1RDY))
	{
	}
    }
}

void stm32wb_system_lsi_disable(void)
{
    armv7m_atomic_decb(&stm32wb_system_device.lsi);

    if (!(stm32wb_system_device.lsi & 0x80))
    {
	armv7m_atomic_andzb(&RCC->CSR, ~RCC_CSR_LSI1ON, &stm32wb_system_device.lsi);
    }
}

void stm32wb_system_hsi16_enable(void)
{
    armv7m_atomic_incb(&stm32wb_system_device.hsi16);

    if (!(stm32wb_system_device.hsi16 & 0x80))
    {
	armv7m_atomic_or(&RCC->CR, RCC_CR_HSION);
	
	while (!(RCC->CR & RCC_CR_HSIRDY))
	{
	}
    }
}

void stm32wb_system_hsi16_disable(void)
{
    armv7m_atomic_decb(&stm32wb_system_device.hsi16);

    if (!(stm32wb_system_device.hsi16 & 0x80))
    {
	armv7m_atomic_andzb(&RCC->CR, ~RCC_CR_HSION, &stm32wb_system_device.hsi16);
    }
}

void stm32wb_system_hsi48_enable(uint32_t reference)
{
    if (reference & STM32WB_SYSTEM_REFERENCE_USB)
    {
	/* CLK48 LOCK (SEM5) */
    }

    armv7m_atomic_incb(&stm32wb_system_device.hsi48);

    armv7m_atomic_or(&stm32wb_system_device.reference, (reference | STM32WB_SYSTEM_REFERENCE_HSI48));

    /* RCC LOCK (SEM3) */
    
    stm32wb_system_voltage_increase();

    armv7m_atomic_or(&RCC->CRRCR, RCC_CRRCR_HSI48ON);
    
    while(!(RCC->CRRCR & RCC_CRRCR_HSI48RDY))
    {
    }

    /* RCC UNLOCK (SEM3) */
    
    armv7m_atomic_or(&RCC->APB1ENR1, RCC_APB1ENR1_CRSEN);
    armv7m_atomic_or(&CRS->CR, (CRS_CR_AUTOTRIMEN | CRS_CR_CEN));
}

void stm32wb_system_hsi48_disable(uint32_t reference)
{
    armv7m_atomic_decb(&stm32wb_system_device.hsi48);

    armv7m_atomic_andzb(&CRS->CR, ~(CRS_CR_AUTOTRIMEN | CRS_CR_CEN), &stm32wb_system_device.hsi48);
    armv7m_atomic_andzb(&RCC->APB1ENR1, ~RCC_APB1ENR1_CRSEN, &stm32wb_system_device.hsi48);
    
    armv7m_atomic_andzb(&stm32wb_system_device.reference, ~STM32WB_SYSTEM_REFERENCE_HSI48, &stm32wb_system_device.hsi48);
    armv7m_atomic_and(&stm32wb_system_device.reference, ~reference);

    /* RCC LOCK (SEM3) */

    armv7m_atomic_andzb(&RCC->CRRCR, ~RCC_CRRCR_HSI48ON, &stm32wb_system_device.hsi48);

    stm32wb_system_voltage_decrease();

    /* RCC UNLOCK (SEM3) */
    
    if (reference & STM32WB_SYSTEM_REFERENCE_USB)
    {
	/* CLK48 UNLOCK (SEM5) */
    }
}

uint32_t stm32wb_system_reset_cause(void)
{
    return stm32wb_system_device.reset;
}

uint32_t stm32wb_system_wakeup_reason(void)
{
    return stm32wb_system_device.wakeup;
}

uint32_t stm32wb_system_lseclk(void)
{
    return stm32wb_system_device.lseclk;
}

uint32_t stm32wb_system_hseclk(void)
{
    return stm32wb_system_device.hseclk;
}

uint32_t stm32wb_system_sysclk(void)
{
    return stm32wb_system_device.sysclk;
}

uint32_t stm32wb_system_hclk(void)
{
    return stm32wb_system_device.hclk;
}

uint32_t stm32wb_system_pclk1(void)
{
    return stm32wb_system_device.pclk1;
}

uint32_t stm32wb_system_pclk2(void)
{
    return stm32wb_system_device.pclk2;
}

uint32_t stm32wb_system_saiclk(void)
{
    return stm32wb_system_device.saiclk;
}

uint64_t stm32wb_system_serial(void)
{
    uint32_t uid[3];
    
    uid[0] = *((const uint32_t*)(UID_BASE + 0x00));
    uid[1] = *((const uint32_t*)(UID_BASE + 0x04));
    uid[2] = *((const uint32_t*)(UID_BASE + 0x08));

    /* This crummy value is what the USB/DFU bootloader uses.
     */
    return (((uint64_t)(uid[0] + uid[2]) << 16) | (uint64_t)(uid[1] >> 16));
}

void stm32wb_system_uid(uint32_t *uid)
{
    uid[0] = *((const uint32_t*)(UID_BASE + 0x00));
    uid[1] = *((const uint32_t*)(UID_BASE + 0x04));
    uid[2] = *((const uint32_t*)(UID_BASE + 0x14));
}

void stm32wb_system_periph_reset(uint32_t periph)
{
    __armv7m_atomic_or(stm32wb_system_xlate_RSTR[periph], stm32wb_system_xlate_RSTMSK[periph]);
    __armv7m_atomic_and(stm32wb_system_xlate_RSTR[periph], ~stm32wb_system_xlate_RSTMSK[periph]);
}

void stm32wb_system_periph_enable(uint32_t periph)
{
    __armv7m_atomic_or(stm32wb_system_xlate_ENR[periph], stm32wb_system_xlate_ENMSK[periph]);
}

void stm32wb_system_periph_disable(uint32_t periph)
{
    __armv7m_atomic_and(stm32wb_system_xlate_ENR[periph], ~stm32wb_system_xlate_ENMSK[periph]);
}

void stm32wb_system_swd_enable(void)
{
    DBGMCU->CR       = DBGMCU_CR_DBG_SLEEP | DBGMCU_CR_DBG_STOP | DBGMCU_CR_DBG_STANDBY;
    DBGMCU->APB1FZR1 = (DBGMCU_APB1FZR1_DBG_TIM2_STOP |
			DBGMCU_APB1FZR1_DBG_RTC_STOP |
			DBGMCU_APB1FZR1_DBG_IWDG_STOP |
			DBGMCU_APB1FZR1_DBG_I2C1_STOP |
			DBGMCU_APB1FZR1_DBG_I2C3_STOP |
			DBGMCU_APB1FZR1_DBG_LPTIM1_STOP);
    DBGMCU->APB1FZR2 = (DBGMCU_APB1FZR2_DBG_LPTIM2_STOP);
    DBGMCU->APB2FZR  = 0;

    __stm32wb_gpio_swd_enable();

    stm32wb_system_reference(STM32WB_SYSTEM_REFERENCE_SWD);
}

void stm32wb_system_swd_disable(void)
{
    stm32wb_system_unreference(STM32WB_SYSTEM_REFERENCE_SWD);

    __stm32wb_gpio_swd_disable();

    DBGMCU->CR       = 0;
    DBGMCU->APB1FZR1 = 0;
    DBGMCU->APB1FZR2 = 0;
    DBGMCU->APB2FZR  = 0;
}

void stm32wb_system_register(stm32wb_system_notify_t *notify, stm32wb_system_callback_t callback, void *context, uint32_t mask)
{
    stm32wb_system_notify_t **pp_entry, *entry;

    for (pp_entry = &stm32wb_system_device.notify, entry = *pp_entry; entry; pp_entry = &entry->next, entry = *pp_entry)
    {
    }

    *pp_entry = notify;

    notify->next = NULL;
    notify->callback = callback;
    notify->context = context;
    notify->mask = mask;
}

void stm32wb_system_unregister(stm32wb_system_notify_t *notify)
{
    stm32wb_system_notify_t **pp_entry, *entry;

    notify->mask = 0;
    notify->callback = NULL;

    for (pp_entry = &stm32wb_system_device.notify, entry = *pp_entry; entry; pp_entry = &entry->next, entry = *pp_entry)
    {
        if (entry == notify)
        {
            *pp_entry = notify->next;
            
            notify->next = NULL;

            break;
        }
    }
}

void stm32wb_system_notify(uint32_t notify)
{
    stm32wb_system_notify_t *entry;

    for (entry = stm32wb_system_device.notify; entry; entry = entry->next)
    {
        if (entry->mask & notify)
        {
            (*entry->callback)(entry->context, entry->mask & notify);
        }
    }
}

void stm32wb_system_lock(uint32_t lock)
{
  //if (lock == STM32WB_SYSTEM_LOCK_RUN) { __BKPT(); }
    
    __armv7m_atomic_incb(&stm32wb_system_device.lock[lock]);
}

void stm32wb_system_unlock(uint32_t lock)
{
  // if (lock == STM32WB_SYSTEM_LOCK_RUN) { __BKPT(); }

    __armv7m_atomic_decb(&stm32wb_system_device.lock[lock]);
}

void stm32wb_system_reference(uint32_t reference)
{
    __armv7m_atomic_or(&stm32wb_system_device.reference, reference);
}

void stm32wb_system_unreference(uint32_t reference)
{
    __armv7m_atomic_and(&stm32wb_system_device.reference, ~reference);
}

static void stm32wb_system_timeout(void)
{
    stm32wb_system_wakeup(STM32WB_SYSTEM_EVENT_TIMEOUT);
}

void stm32wb_system_sleep(uint32_t policy, uint32_t events, uint32_t timeout)
{
    uint32_t primask;

    if (timeout != STM32WB_SYSTEM_TIMEOUT_NONE)
    {
        if (!(stm32wb_system_device.events & events))
        {
            if (timeout != STM32WB_SYSTEM_TIMEOUT_FOREVER)
            {
		events |= STM32WB_SYSTEM_EVENT_TIMEOUT;
		
                stm32wb_rtc_timer_start(&stm32wb_system_device.timeout, stm32wb_rtc_clock_read() + stm32wb_rtc_millis_to_clock(timeout), (stm32wb_rtc_timer_callback_t)stm32wb_system_timeout);
            }

            if (!(stm32wb_system_device.events & events))
            {
                if (policy >= STM32WB_SYSTEM_POLICY_SLEEP)
                {
                    stm32wb_system_notify(STM32WB_SYSTEM_NOTIFY_SLEEP);
                }

                while (!(stm32wb_system_device.events & events))
                {
                    if ((policy <= STM32WB_SYSTEM_POLICY_RUN) || stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_RUN])
                    {
                        __WFE();
                    }
                    else
                    {
                        primask = __get_PRIMASK();

                        __disable_irq();

                        if (!stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_RUN])
                        {
                            if ((policy <= STM32WB_SYSTEM_POLICY_SLEEP) || stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_SLEEP])
                            {
				if (!(stm32wb_system_device.reference & (STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_1 | STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_2 | STM32WB_SYSTEM_REFERENCE_SWD)))
				{
				    __stm32wb_dma_sleep_enter();
				}
				
				if (stm32wb_system_device.c1spre[0] == stm32wb_system_device.c1spre[1])
				{
				    __WFI();
				    __NOP();
				    __NOP();
				    __NOP();
				    __NOP();
				}
				else
				{
				    /* RCC LOCK (SEM3) */

				    RCC->CFGR = (RCC->CFGR & ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2 | RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F)) | stm32wb_system_device.c1spre[1];
				
				    while ((RCC->CFGR & (RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F)) != (RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F))
				    {
				    }

				    SysTick->CTRL |= SysTick_CTRL_CLKSOURCE_Msk;
				    
				    __WFI();
				    __NOP();
				    __NOP();
				    __NOP();
				    __NOP();

				    SysTick->CTRL &= ~SysTick_CTRL_CLKSOURCE_Msk;
				    
				    RCC->CFGR = (RCC->CFGR & ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2 | RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F)) | stm32wb_system_device.c1spre[0];
				
				    while ((RCC->CFGR & (RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F)) != (RCC_CFGR_HPREF | RCC_CFGR_PPRE1F | RCC_CFGR_PPRE2F))
				    {
				    }

				    /* RCC UNLOCK (SEM3) */
				}

				if (!(stm32wb_system_device.reference & (STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_1 | STM32WB_SYSTEM_REFERENCE_SYSCLK_RANGE_2 | STM32WB_SYSTEM_REFERENCE_SWD)))
				{
				    __stm32wb_dma_sleep_leave();
				}
                            }
                            else
                            {
				PWR->CR1 = ((PWR->CR1 & ~PWR_CR1_LPMS) |
					    (stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_STOP_0]
					     ? PWR_CR1_LPMS_STOP0
					     : (stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_STOP_1]
						? PWR_CR1_LPMS_STOP1
						: PWR_CR1_LPMS_STOP2)));

				if (!(SCB->ICSR & SCB_ICSR_ISRPENDING_Msk))
                                {
				    stm32wb_gpio_pin_write(STM32WB_GPIO_PIN_PB1, 1);
				
				    stm32wb_system_notify(STM32WB_SYSTEM_NOTIFY_STOP_ENTER);
  
                                    if (!(SCB->ICSR & SCB_ICSR_ISRPENDING_Msk))
				    {
					__stm32wb_exti_stop_enter();
                                        __stm32wb_gpio_stop_enter();

					if (stm32wb_system_device.hsi48)
					{
					    CRS->CR &= ~(CRS_CR_AUTOTRIMEN | CRS_CR_CEN);
					}

					if (!(stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_RANGE_1_2))
					{
					    if (!stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_STOP_0] && !stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_STOP_1])
					    {
						PWR->CR1 &= ~PWR_CR1_LPR;
						
						while (PWR->SR2 & PWR_SR2_REGLPF)
						{
						}
					    }
					}
					
                                        if (!(SCB->ICSR & SCB_ICSR_ISRPENDING_Msk))
                                        {
					    armv7m_systick_disable();

					    /* RCC LOCK (SEM3) */

					    RCC->CR &= ~RCC_CR_MSIPLLEN;
					    
					    if (stm32wb_system_device.smps && stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_STOP_0])
					    {
						RCC->CR = (RCC->CR & ~RCC_CR_HSIASFS) | RCC_CR_HSIKERON;

						while (!(RCC->CR & RCC_CR_HSIKERDY))
						{
						}
					    }
					    else
					    {
						if (stm32wb_system_device.hse)
						{
						    RCC->CR = (RCC->CR & ~RCC_CR_HSIASFS) | RCC_CR_HSIKERON;
						}
						else
						{
						    RCC->CR = (RCC->CR & ~RCC_CR_HSIASFS) | (stm32wb_system_device.hsi16 ? RCC_CR_HSIASFS : 0);
						}
					    }
					    
					    if (stm32wb_system_device.smps)
					    {
						RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_HSI;
	    
						while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI)
						{
						}
					    }

					    /* RCC UNLOCK (SEM3) */

					    SCB->SCR |= SCB_SCR_SLEEPDEEP_Msk;
					    
					    __WFI();
					    __NOP();
					    __NOP();
					    __NOP();
					    __NOP();
					    
					    SCB->SCR &= ~SCB_SCR_SLEEPDEEP_Msk;
						
					    /* RCC LOCK (SEM3) */

					    if (stm32wb_system_device.hse)
					    {
						if (!(RCC->CR & RCC_CR_HSEON))
						{
						    RCC->CR |= RCC_CR_HSEON;
						    
						    while (!(RCC->CR & RCC_CR_HSERDY))
						    {
						    }
						}
					    }
					    
					    if (stm32wb_system_device.msi)
					    {
						if (!(RCC->CR & RCC_CR_MSION))
						{
						    RCC->CR |= RCC_CR_MSION;
						    
						    while (!(RCC->CR & RCC_CR_MSIRDY))
						    {
						    }
						}

						if (stm32wb_system_device.lseclk)
						{
						    RCC->CR |= RCC_CR_MSIPLLEN;
						}
					    }
					    
					    if ((RCC->EXTCFGR & RCC_EXTCFGR_C2HPRE) != stm32wb_system_device.c2hpre)
					    {
						RCC->EXTCFGR = (RCC->EXTCFGR & ~RCC_EXTCFGR_C2HPRE) | stm32wb_system_device.c2hpre;
					    
						while (!(RCC->EXTCFGR & RCC_EXTCFGR_C2HPREF))
						{
						}
						
					    }
					    
					    if (stm32wb_system_device.pllsys)
					    {
						if (!(RCC->CR & RCC_CR_PLLON))
						{
						    RCC->CR |= RCC_CR_PLLON;
						    
						    while(!(RCC->CR & RCC_CR_PLLRDY))
						    {
						    }
						}

						if ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL)
						{
						    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_PLL;
						    
						    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL)
						    {
						    }
						}
					    }
					    else
					    {
						if (stm32wb_system_device.hse)
						{
						    if ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSE)
						    {
							RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_HSE;
							
							while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSE)
							{
							}
						    }
						}
						else
						{
						    if ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_MSI)
						    {
							RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_MSI;
							
							while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_MSI)
							{
							}
						    }
						}
					    }

					    RCC->CR &= ~RCC_CR_HSIKERON;
					
					    if (!stm32wb_system_device.hsi16)
					    {
						RCC->CR &= ~RCC_CR_HSION;
					    }

					    if (!stm32wb_system_device.msi)
					    {
						RCC->CR &= ~RCC_CR_MSION;
					    }

					    if (!stm32wb_system_device.hse)
					    {
						RCC->CR &= ~RCC_CR_HSEON;
					    }
					    
					    /* RCC UNLOCK (SEM3) */

					    armv7m_systick_enable();
					    
					    if (stm32wb_system_device.hsi48)
					    {
						if (!(RCC->CRRCR & RCC_CRRCR_HSI48ON))
						{
						    RCC->CRRCR |= RCC_CRRCR_HSI48ON;
						    
						    while(!(RCC->CRRCR & RCC_CRRCR_HSI48RDY))
						    {
						    }
						}
					    }
					}

					if (!(stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_RANGE_1_2))
					{
					    if (!stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_STOP_0] && !stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_STOP_1])
					    {
						PWR->CR1 |= PWR_CR1_LPR;
						
						while (!(PWR->SR2 & PWR_SR2_REGLPF))
						{
						}
					    }
					}
					
					if (stm32wb_system_device.hsi48)
					{
					    CRS->CR |= (CRS_CR_AUTOTRIMEN | CRS_CR_CEN);
					}
					
                                        __stm32wb_gpio_stop_leave();
                                        __stm32wb_exti_stop_leave();
                                    }
                                    
                                    stm32wb_system_notify(STM32WB_SYSTEM_NOTIFY_STOP_LEAVE);

				    stm32wb_gpio_pin_write(STM32WB_GPIO_PIN_PB1, 0);
                                }
                            }
                        }
                        
                        __set_PRIMASK(primask);
                    }
                }
            }
            
            if (timeout != STM32WB_SYSTEM_TIMEOUT_FOREVER)
            {
                stm32wb_rtc_timer_stop(&stm32wb_system_device.timeout);
            }
        }
    }
    
    armv7m_atomic_and(&stm32wb_system_device.events, ~events);
}

void stm32wb_system_wakeup(uint32_t events)
{
    armv7m_atomic_or(&stm32wb_system_device.events, events);
}

void stm32wb_system_deepsleep(uint32_t control, uint32_t timeout)
{
    uint32_t primask;

    if (timeout == STM32WB_SYSTEM_TIMEOUT_NONE)
    {
        return;
    }
    
    primask = __get_PRIMASK();
    
    __disable_irq();
    
    if (stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_RUN] ||
        stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_SLEEP] ||
        stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_STOP_0] ||
        stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_STOP_1] ||
        stm32wb_system_device.lock[STM32WB_SYSTEM_LOCK_STOP_2])
    {
        __set_PRIMASK(primask);
                        
        return;
    }
    
    stm32wb_system_notify((control & STM32WB_SYSTEM_DEEPSLEEP_SHUTDOWN) ? STM32WB_SYSTEM_NOTIFY_SHUTDOWN : STM32WB_SYSTEM_NOTIFY_STANDBY);

    stm32wb_rtc_deepsleep(control, timeout);

    if (stm32wb_system_device.smps)
    {
	/* RCC LOCK (SEM3) */

	if (control & STM32WB_SYSTEM_DEEPSLEEP_SHUTDOWN)
	{
	    PWR->CR5 &= ~(PWR_CR5_SMPSEN | PWR_CR5_BORHC);

	    RCC->SMPSCR = (RCC->SMPSCR & ~RCC_SMPSCR_SMPSSEL) | RCC_SMPSCR_SMPSSEL_MSI;
	}
	else
	{
	    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_HSI;
	    
	    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI)
	    {
	    }
	}
	
	/* RCC UNLOCK (SEM3) */
    }

    PWR->CR1 = (PWR->CR1 & ~PWR_CR1_LPMS) | ((control & STM32WB_SYSTEM_DEEPSLEEP_SHUTDOWN) ? PWR_CR1_LPMS_SHUTDOWN : PWR_CR1_LPMS_STANDBY);
    PWR->CR3 = (PWR->CR3 & ~PWR_CR3_EWUP) | (((control >> 0) | (control >> 8)) & PWR_CR3_EWUP) | PWR_CR3_EIWUL;
    PWR->CR4 = (PWR->CR4 & ~(PWR_CR4_WP1 | PWR_CR4_WP2 | PWR_CR4_WP3 | PWR_CR4_WP4 | PWR_CR4_WP5)) | ((control >> 8) & (PWR_CR4_WP1 | PWR_CR4_WP2 | PWR_CR4_WP3 | PWR_CR4_WP4 | PWR_CR4_WP5));
    
    SCB->SCR |= SCB_SCR_SLEEPDEEP_Msk;
    
    __DSB();
    __SEV();
    __WFE();
    
    while (1)
    {
        __WFE();
    }
}

void stm32wb_system_hook(stm32wb_system_fatal_callback_t callback)
{
    stm32wb_system_device.callback = callback;
}

void stm32wb_system_fatal(void)
{
    __disable_irq();

    if (stm32wb_system_device.reference & STM32WB_SYSTEM_REFERENCE_SWD)
    {
	__BKPT();
    }

    __set_MSP( (uint32_t)&__StackTop );
    __set_PSP( (uint32_t)&__StackTop );

    while (stm32wb_system_device.callback)
    {
	(*stm32wb_system_device.callback)();
    }
    
    *((volatile uint32_t*)STM32WB_CRASH_SIGNATURE_ADDRESS) = STM32WB_CRASH_SIGNATURE_DATA;

    stm32wb_rtc_reset();

    NVIC_SystemReset();
    
    while (1)
    {
    }
}

void stm32wb_system_reset(void)
{
    __disable_irq();

    stm32wb_system_notify(STM32WB_SYSTEM_NOTIFY_RESET);

    NVIC_SystemReset();
    
    while (1)
    {
    }
}

void stm32wb_system_dfu(void)
{
    __disable_irq();

    /* Set the BCK bit to flag a reboot into the booloader */
    RTC->CR |= RTC_CR_BKP;
    RTC->WPR = 0x00;
    
    stm32wb_system_notify(STM32WB_SYSTEM_NOTIFY_DFU);

    NVIC_SystemReset();
    
    while (1)
    {
    }
}

static void __empty() { }

void __stm32wb_lptim_initialize(void) __attribute__ ((weak, alias("__empty")));

void NMI_Handler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void HardFault_Handler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void MemManage_Handler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void BusFault_Handler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void UsageFault_Handler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DebugMon_Handler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void WWDG_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void PVD_PVM_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void TAMP_STAMP_LSECSS_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void RTC_WKUP_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void FLASH_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void RCC_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void EXTI0_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void EXTI1_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void EXTI2_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void EXTI3_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void EXTI4_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA1_Channel1_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA1_Channel2_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA1_Channel3_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA1_Channel4_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA1_Channel5_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA1_Channel6_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA1_Channel7_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void ADC1_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void USB_HP_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void USB_LP_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void C2SEV_PWR_C2H_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void COMP_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void EXTI9_5_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void TIM1_BRK_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void TIM1_UP_TIM16_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void TIM1_TRG_COM_TIM17_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void TIM1_CC_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void TIM2_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void PKA_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void I2C1_EV_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void I2C1_ER_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void I2C3_EV_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void I2C3_ER_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void SPI1_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void SPI2_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void USART1_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void LPUART1_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void SAI1_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void TSC_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void EXTI15_10_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void RTC_Alarm_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void CRS_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void PWR_SOTF_BLEACT_802ACT_RFPHASE_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void IPCC_C1_RX_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void IPCC_C1_TX_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void HSEM_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void LPTIM1_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void LPTIM2_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void LCD_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void QUADSPI_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void AES1_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void AES2_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void RNG_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void FPU_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA2_Channel1_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA2_Channel2_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA2_Channel3_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA2_Channel4_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA2_Channel5_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA2_Channel6_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMA2_Channel7_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
void DMAMUX1_OVR_IRQHandler(void) __attribute__ ((weak, alias("stm32wb_system_fatal")));
