/*
 * Copyright (c) 2016-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include <stdio.h>

#include "stm32wbxx.h"

#include "armv7m.h"

#include "stm32wb_gpio.h"
#include "stm32wb_spi.h"
#include "stm32wb_dma.h"
#include "stm32wb_exti.h"
#include "stm32wb_system.h"

typedef struct _stm32wb_spi_device_t {
    stm32wb_spi_t           *instances[STM32WB_SPI_INSTANCE_COUNT];
    stm32wb_system_notify_t notify;
} stm32wb_spi_device_t;

static stm32wb_spi_device_t stm32wb_spi_device;

static __attribute__((section(".dma"))) uint16_t stm32wb_spi_rx_none;
static __attribute__((section(".dma"))) uint16_t stm32wb_spi_tx_default;

#define SPI_CR1_BR_DIV2   (0)
#define SPI_CR1_BR_DIV4   (SPI_CR1_BR_0)
#define SPI_CR1_BR_DIV8   (SPI_CR1_BR_1)
#define SPI_CR1_BR_DIV16  (SPI_CR1_BR_0 | SPI_CR1_BR_1)
#define SPI_CR1_BR_DIV32  (SPI_CR1_BR_2)
#define SPI_CR1_BR_DIV64  (SPI_CR1_BR_0 | SPI_CR1_BR_2)
#define SPI_CR1_BR_DIV128 (SPI_CR1_BR_1 | SPI_CR1_BR_2)
#define SPI_CR1_BR_DIV256 (SPI_CR1_BR_0 | SPI_CR1_BR_1 | SPI_CR1_BR_2)

#define SPI_CR2_DS_8BIT   (SPI_CR2_DS_0 | SPI_CR2_DS_1 | SPI_CR2_DS_2)
#define SPI_CR2_DS_16BIT  (SPI_CR2_DS_0 | SPI_CR2_DS_1 | SPI_CR2_DS_2 | SPI_CR2_DS_3)

#define STM32WB_SPI_OPTION_RX_DMA 0x40000000
#define STM32WB_SPI_OPTION_TX_DMA 0x80000000

#define STM32WB_SPI_RX_DMA_OPTION_RECEIVE_8	  \
    (STM32WB_DMA_OPTION_PERIPHERAL_TO_MEMORY |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_8 |  \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_8 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_RX_DMA_OPTION_TRANSMIT_8	  \
    (STM32WB_DMA_OPTION_PERIPHERAL_TO_MEMORY |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_8 |  \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_8 |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_RX_DMA_OPTION_TRANSFER_8	  \
    (STM32WB_DMA_OPTION_PERIPHERAL_TO_MEMORY |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_8 |  \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_8 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_RX_DMA_OPTION_RECEIVE_16	  \
    (STM32WB_DMA_OPTION_PERIPHERAL_TO_MEMORY |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_16 | \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_16 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_RX_DMA_OPTION_TRANSMIT_16	  \
    (STM32WB_DMA_OPTION_PERIPHERAL_TO_MEMORY |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_16 | \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_16 |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_RX_DMA_OPTION_TRANSFER_16	  \
    (STM32WB_DMA_OPTION_PERIPHERAL_TO_MEMORY |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_16 | \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_16 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_TX_DMA_OPTION_RECEIVE_8	  \
    (STM32WB_DMA_OPTION_MEMORY_TO_PERIPHERAL |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_8 |  \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_8 |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_TX_DMA_OPTION_TRANSMIT_8	  \
    (STM32WB_DMA_OPTION_MEMORY_TO_PERIPHERAL |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_8 |  \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_8 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_TX_DMA_OPTION_TRANSFER_8	  \
    (STM32WB_DMA_OPTION_MEMORY_TO_PERIPHERAL |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_8 |  \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_8 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_TX_DMA_OPTION_RECEIVE_16	  \
    (STM32WB_DMA_OPTION_MEMORY_TO_PERIPHERAL |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_16 | \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_16 |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_TX_DMA_OPTION_TRANSMIT_16	  \
    (STM32WB_DMA_OPTION_MEMORY_TO_PERIPHERAL |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_16 | \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_16 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_SPI_TX_DMA_OPTION_TRANSFER_16	  \
    (STM32WB_DMA_OPTION_MEMORY_TO_PERIPHERAL |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_16 | \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_16 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

static SPI_TypeDef * const stm32wb_i2c_xlate_SPI[STM32WB_SPI_INSTANCE_COUNT] = {
    SPI1,
    SPI2,
};

static void stm32wb_spi_notify_callback(void *context, uint32_t notify)
{
    if (stm32wb_spi_device.instances[STM32WB_SPI_INSTANCE_SPI1])
    {
	stm32wb_spi_device.instances[STM32WB_SPI_INSTANCE_SPI1]->clock = 0;
    }

    if (stm32wb_spi_device.instances[STM32WB_SPI_INSTANCE_SPI2])
    {
	stm32wb_spi_device.instances[STM32WB_SPI_INSTANCE_SPI2]->clock = 0;
    }
}

static void stm32wb_spi_dma_callback(stm32wb_spi_t *spi, uint32_t events)
{
    SPI_TypeDef *SPI = spi->SPI;

    if (armv7m_atomic_casb(&spi->state, STM32WB_SPI_STATE_DMA, STM32WB_SPI_STATE_DATA) != STM32WB_SPI_STATE_DMA)
    {
        return;
    }

    stm32wb_dma_stop(spi->tx_dma);
    stm32wb_dma_stop(spi->rx_dma);

    while (SPI->SR & SPI_SR_BSY)
    {
    }
    
    SPI->CR1 = spi->cr1;
    SPI->CR2 = spi->cr2;
    SPI->CR1 = spi->cr1 | SPI_CR1_SPE;
    
    if (spi->xf_callback)
    {
        (*spi->xf_callback)(spi->xf_context);
    }
}

bool stm32wb_spi_create(stm32wb_spi_t *spi, const stm32wb_spi_params_t *params)
{
    if (spi->state != STM32WB_SPI_STATE_NONE)
    {
        return false;
    }

    spi->SPI = stm32wb_i2c_xlate_SPI[params->instance];
    spi->instance = params->instance;
    spi->priority = params->priority;
    spi->rx_dma = params->rx_dma;
    spi->tx_dma = params->tx_dma;
    spi->pins = params->pins;

    stm32wb_spi_tx_default = 0xffff;
	
    spi->rx_none = &stm32wb_spi_rx_none;
    spi->tx_default = &stm32wb_spi_tx_default;

    spi->state = STM32WB_SPI_STATE_INIT;

    if (!stm32wb_spi_device.notify.callback)
    {
	stm32wb_system_register(&stm32wb_spi_device.notify, stm32wb_spi_notify_callback, NULL, (STM32WB_SYSTEM_NOTIFY_CLOCKS));
    }
    
    return true;
}

bool stm32wb_spi_destroy(stm32wb_spi_t *spi)
{
    if (spi->state != STM32WB_SPI_STATE_INIT)
    {
        return false;
    }

    spi->state = STM32WB_SPI_STATE_NONE;

    return true;
}

bool stm32wb_spi_enable(stm32wb_spi_t *spi)
{
    if (spi->state != STM32WB_SPI_STATE_INIT)
    {
        if (spi->state == STM32WB_SPI_STATE_READY)
        {
            spi->nesting++;

            return true;
        }
        else
        {
	    return false;
        }
    }
    else
    {
	if (armv7m_atomic_cas((volatile uint32_t*)&stm32wb_spi_device.instances[spi->instance], (uint32_t)NULL, (uint32_t)spi) != (uint32_t)NULL)
	{
	    return false;
	}

	spi->nesting = 1;
    }
    
    spi->clock = ~0;
    spi->option = 0;
    spi->cr1 = 0;
    spi->cr2 = 0;
    spi->mask = 0;
    spi->lock_callback = NULL;
    spi->lock_cookie = NULL;
    
    stm32wb_gpio_pin_configure(spi->pins.mosi, (STM32WB_GPIO_PARK_HIZ | STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_OSPEED_VERY_HIGH | STM32WB_GPIO_OTYPE_PUSHPULL | STM32WB_GPIO_MODE_ALTERNATE));
    stm32wb_gpio_pin_configure(spi->pins.miso, (STM32WB_GPIO_PARK_HIZ | STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_OSPEED_VERY_HIGH | STM32WB_GPIO_OTYPE_PUSHPULL | STM32WB_GPIO_MODE_ALTERNATE));
    stm32wb_gpio_pin_configure(spi->pins.sck,  (STM32WB_GPIO_PARK_HIZ | STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_OSPEED_VERY_HIGH | STM32WB_GPIO_OTYPE_PUSHPULL | STM32WB_GPIO_MODE_ALTERNATE));

    spi->state = STM32WB_SPI_STATE_READY;

    return true;
}

bool stm32wb_spi_disable(stm32wb_spi_t *spi)
{
    if (spi->state != STM32WB_SPI_STATE_READY)
    {
        return false;
    }

    if (spi->nesting != 1)
    {
        spi->nesting--;
    }
    else
    {
        spi->nesting = 0;

        stm32wb_gpio_pin_configure(spi->pins.mosi, (STM32WB_GPIO_PARK_HIZ | STM32WB_GPIO_MODE_ANALOG));
        stm32wb_gpio_pin_configure(spi->pins.miso, (STM32WB_GPIO_PARK_HIZ | STM32WB_GPIO_MODE_ANALOG));
        stm32wb_gpio_pin_configure(spi->pins.sck,  (STM32WB_GPIO_PARK_HIZ | STM32WB_GPIO_MODE_ANALOG));
        
        stm32wb_spi_device.instances[spi->instance] = NULL;
        
        spi->state = STM32WB_SPI_STATE_INIT;
    }

    return true;
}

bool stm32wb_spi_hook(stm32wb_spi_t *spi, stm32wb_spi_lock_callback_t callback, void *cookie)
{
    if (spi->state != STM32WB_SPI_STATE_READY)
    {
        return false;
    }

    spi->lock_callback = callback;
    spi->lock_cookie = cookie;

    return true;
}

bool stm32wb_spi_block(stm32wb_spi_t *spi, uint16_t pin)
{
    if (spi->state != STM32WB_SPI_STATE_READY)
    {
        return false;
    }

    spi->mask |= (1ul << ((pin & STM32WB_GPIO_PIN_INDEX_MASK) >> STM32WB_GPIO_PIN_INDEX_SHIFT));

    return true;
}

bool stm32wb_spi_unblock(stm32wb_spi_t *spi, uint16_t pin)
{
    if (spi->state != STM32WB_SPI_STATE_READY)
    {
        return false;
    }

    spi->mask &= ~(1ul << ((pin & STM32WB_GPIO_PIN_INDEX_MASK) >> STM32WB_GPIO_PIN_INDEX_SHIFT));

    return true;
}

__attribute__((optimize("O3"))) bool stm32wb_spi_acquire(stm32wb_spi_t *spi, uint32_t clock, uint32_t option)
{
    SPI_TypeDef *SPI = spi->SPI;
    uint32_t spiclk, div;

    if (spi->state != STM32WB_SPI_STATE_READY)
    {
        return false;
    }

    if (spi->lock_callback)
    {
        (*spi->lock_callback)(spi->lock_cookie, true);
    }

    if (spi->mask)
    {
        stm32wb_exti_block(spi->mask);
    }

    stm32wb_system_lock(STM32WB_SYSTEM_LOCK_RUN);

    stm32wb_system_periph_enable(STM32WB_SYSTEM_PERIPH_SPI1 + spi->instance);

    if ((spi->clock != clock) || (spi->option != option))
    {
	if (spi->instance == STM32WB_SPI_INSTANCE_SPI1)
	{
	    spiclk = stm32wb_system_pclk2() / 2;
	}
	else
	{
	    spiclk = stm32wb_system_pclk1() / 2;
	}

        div = 0;

        while ((spiclk > clock) && (div < 7))
        {
            spiclk >>= 1;
            div++;
        }

        spi->cr1 = SPI_CR1_MSTR | SPI_CR1_SSM | SPI_CR1_SSI | (option & (STM32WB_SPI_OPTION_MODE_MASK | STM32WB_SPI_OPTION_LSB_FIRST)) | (div << SPI_CR1_BR_Pos);
        spi->cr2 = SPI_CR2_DS_8BIT | SPI_CR2_FRXTH;

        SPI->SR = 0;
        SPI->CR1 = spi->cr1;
        SPI->CR2 = spi->cr2;

        spi->clock = clock;
	spi->option = option;
    }

    SPI->CR1 = spi->cr1 | SPI_CR1_SPE;

    spi->state = STM32WB_SPI_STATE_DATA;

    return true;
}

__attribute__((optimize("O3"))) bool stm32wb_spi_release(stm32wb_spi_t *spi)
{
    SPI_TypeDef *SPI = spi->SPI;

    if (spi->state != STM32WB_SPI_STATE_DATA)
    {
        return false;
    }

    while (SPI->SR & SPI_SR_BSY)
    {
    }

    SPI->CR1 = spi->cr1;

    if (spi->option & (STM32WB_SPI_OPTION_RX_DMA | STM32WB_SPI_OPTION_TX_DMA))
    {
	if (spi->option & STM32WB_SPI_OPTION_RX_DMA)
	{
	    stm32wb_dma_disable(spi->rx_dma);
	}

	if (spi->option & STM32WB_SPI_OPTION_TX_DMA)
	{
	    stm32wb_dma_disable(spi->tx_dma);
	}
	
	spi->option &= ~(STM32WB_SPI_OPTION_RX_DMA | STM32WB_SPI_OPTION_TX_DMA);
    }

    stm32wb_system_periph_disable(STM32WB_SYSTEM_PERIPH_SPI1 + spi->instance);

    stm32wb_system_unlock(STM32WB_SYSTEM_LOCK_RUN);

    spi->state = STM32WB_SPI_STATE_READY;

    if (spi->mask)
    {
	stm32wb_exti_unblock(spi->mask, false);
    }

    if (spi->lock_callback)
    {
        (*spi->lock_callback)(spi->lock_cookie, false);
    }

    return true;
}

__attribute__((optimize("O3"))) uint8_t stm32wb_spi_data(stm32wb_spi_t *spi, uint8_t data)
{
    SPI_TypeDef *SPI = spi->SPI;

    STM32WB_SPI_WRITE_8(SPI, data);

    while (!(SPI->SR & SPI_SR_RXNE))
    {
    }

    return STM32WB_SPI_READ_8(SPI);
}

__attribute__((optimize("O3"))) void stm32wb_spi_data_receive(stm32wb_spi_t *spi, uint8_t *rx_data, uint32_t rx_count)
{
    SPI_TypeDef *SPI = spi->SPI;
    uint8_t *rx_data_e;
    const uint8_t tx_default = 0xff;
    
    if (rx_count < 3)
    {
	if (rx_count == 2)
	{
	    STM32WB_SPI_WRITE_8(SPI, tx_default);
	    STM32WB_SPI_WRITE_8(SPI, tx_default);
	    
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }
	    
	    rx_data[0] = STM32WB_SPI_READ_8(SPI);
	    
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }
	    
	    rx_data[1] = STM32WB_SPI_READ_8(SPI);
	}
	else
	{
	    STM32WB_SPI_WRITE_8(SPI, tx_default);
	    
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }
	    
	    rx_data[0] = STM32WB_SPI_READ_8(SPI);
	}
    }
    else
    {
	rx_data_e = rx_data + rx_count - 3;
	
	STM32WB_SPI_WRITE_8(SPI, tx_default);
	STM32WB_SPI_WRITE_8(SPI, tx_default);
	STM32WB_SPI_WRITE_8(SPI, tx_default);
	
	while (rx_data != rx_data_e)
	{
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }
	    
	    *rx_data++ = STM32WB_SPI_READ_8(SPI);
	    
	    STM32WB_SPI_WRITE_8(SPI, tx_default);
	}
	
	while (!(SPI->SR & SPI_SR_RXNE))
	{
	}
	
	rx_data[0] = STM32WB_SPI_READ_8(SPI);
	
	while (!(SPI->SR & SPI_SR_RXNE))
	{
	}
	
	rx_data[1] = STM32WB_SPI_READ_8(SPI);
	
	while (!(SPI->SR & SPI_SR_RXNE))
	{
	}
	
	rx_data[2] = STM32WB_SPI_READ_8(SPI);
    }
}

__attribute__((optimize("O3"))) void stm32wb_spi_data_transmit(stm32wb_spi_t *spi, const uint8_t *tx_data, uint32_t tx_count)
{
    SPI_TypeDef *SPI = spi->SPI;
    const uint8_t *tx_data_e;

    if (tx_count < 3)
    {
	if (tx_count == 2)
	{
	    STM32WB_SPI_WRITE_8(SPI, tx_data[0]);
	    STM32WB_SPI_WRITE_8(SPI, tx_data[1]);
		    
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }

	    STM32WB_SPI_READ_8(SPI);
		    
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }

	    STM32WB_SPI_READ_8(SPI);
	}
	else
	{
	    STM32WB_SPI_WRITE_8(SPI, tx_data[0]);
		    
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }

	    STM32WB_SPI_READ_8(SPI);
	}
    }
    else
    {
	tx_data_e = tx_data + tx_count;
	
	STM32WB_SPI_WRITE_8(SPI, tx_data[0]);
	STM32WB_SPI_WRITE_8(SPI, tx_data[1]);
	STM32WB_SPI_WRITE_8(SPI, tx_data[2]);
	tx_data += 3;
		
	while (tx_data != tx_data_e)
	{
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }

	    STM32WB_SPI_READ_8(SPI);
	    STM32WB_SPI_WRITE_8(SPI, *tx_data++);
	}
		
	while (!(SPI->SR & SPI_SR_RXNE))
	{
	}

	STM32WB_SPI_READ_8(SPI);
		
	while (!(SPI->SR & SPI_SR_RXNE))
	{
	}

	STM32WB_SPI_READ_8(SPI);
		
	while (!(SPI->SR & SPI_SR_RXNE))
	{
	}

	STM32WB_SPI_READ_8(SPI);
    }
}

__attribute__((optimize("O3"))) void stm32wb_spi_data_transfer(stm32wb_spi_t *spi, const uint8_t *tx_data, uint8_t *rx_data, uint32_t xf_count)
{
    SPI_TypeDef *SPI = spi->SPI;
    const uint8_t *tx_data_e;

    if (xf_count < 3)
    {
	if (xf_count == 2)
	{
	    STM32WB_SPI_WRITE_8(SPI, tx_data[0]);
	    STM32WB_SPI_WRITE_8(SPI, tx_data[1]);
		    
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }

	    rx_data[0] = STM32WB_SPI_READ_8(SPI);
		    
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }

	    rx_data[1] = STM32WB_SPI_READ_8(SPI);
	}
	else
	{
	    STM32WB_SPI_WRITE_8(SPI, tx_data[0]);
		    
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }

	    rx_data[0] = STM32WB_SPI_READ_8(SPI);
	}
    }
    else
    {
	tx_data_e = tx_data + xf_count;
	
	STM32WB_SPI_WRITE_8(SPI, tx_data[0]);
	STM32WB_SPI_WRITE_8(SPI, tx_data[1]);
	STM32WB_SPI_WRITE_8(SPI, tx_data[2]);
	tx_data += 3;

	while (tx_data != tx_data_e)
	{
	    while (!(SPI->SR & SPI_SR_RXNE))
	    {
	    }

	    *rx_data++ = STM32WB_SPI_READ_8(SPI);
	    STM32WB_SPI_WRITE_8(SPI, *tx_data++);
	}
		
	while (!(SPI->SR & SPI_SR_RXNE))
	{
	}

	rx_data[0] = STM32WB_SPI_READ_8(SPI);
		
	while (!(SPI->SR & SPI_SR_RXNE))
	{
	}

	rx_data[1] = STM32WB_SPI_READ_8(SPI);
		
	while (!(SPI->SR & SPI_SR_RXNE))
	{
	}

	rx_data[2] = STM32WB_SPI_READ_8(SPI);
    }
}

__attribute__((optimize("O3"))) bool stm32wb_spi_receive(stm32wb_spi_t *spi, uint8_t *rx_data, uint32_t rx_count, stm32wb_spi_done_callback_t callback, void *context)
{
    SPI_TypeDef *SPI = spi->SPI;
    uint32_t spi_cr2, rx_option, tx_option;
    
    if (armv7m_atomic_casb(&spi->state, STM32WB_SPI_STATE_DATA, STM32WB_SPI_STATE_DMA) != STM32WB_SPI_STATE_DATA)
    {
        return false;
    }

    if (!(spi->option & STM32WB_SPI_OPTION_RX_DMA))
    {
	if (!stm32wb_dma_enable(spi->rx_dma, spi->priority, (stm32wb_dma_callback_t)stm32wb_spi_dma_callback, spi))
	{
	    spi->state = STM32WB_SPI_STATE_DATA;
	    
	    return false;
	}
	
	spi->option |= STM32WB_SPI_OPTION_RX_DMA;
    }
    
    if (!(spi->option & STM32WB_SPI_OPTION_TX_DMA))
    {
	if (!stm32wb_dma_enable(spi->tx_dma, spi->priority, NULL, NULL))
	{
	    spi->state = STM32WB_SPI_STATE_DATA;
	    
	    return false;
	}
	
	spi->option |= STM32WB_SPI_OPTION_TX_DMA;
    }

    spi->xf_callback = callback;
    spi->xf_context = context;
    spi->rx_data = rx_data;

    if ((rx_count & 1) || ((uint32_t)rx_data & 1))
    {
	spi_cr2 = spi->cr2 | (SPI_CR2_RXDMAEN | SPI_CR2_TXDMAEN);
		
	rx_option = STM32WB_SPI_RX_DMA_OPTION_RECEIVE_8;
	tx_option = STM32WB_SPI_TX_DMA_OPTION_RECEIVE_8;
    }
    else
    {
	spi_cr2 = (spi->cr2 & ~SPI_CR2_FRXTH) | (SPI_CR2_RXDMAEN | SPI_CR2_TXDMAEN);

	rx_option = STM32WB_SPI_RX_DMA_OPTION_RECEIVE_16;
	tx_option = STM32WB_SPI_TX_DMA_OPTION_RECEIVE_16;

	rx_count = rx_count / 2;
    }

    while (SPI->SR & (SPI_SR_FTLVL | SPI_SR_FRLVL | SPI_SR_BSY))
    {
    }
    
    SPI->CR1 = spi->cr1;
    SPI->CR2 = spi_cr2;
    SPI->CR1 = spi->cr1 | SPI_CR1_SPE;

    stm32wb_dma_start(spi->rx_dma, (uint32_t)rx_data, (uint32_t)&SPI->DR, rx_count, rx_option | STM32WB_DMA_OPTION_EVENT_TRANSFER_DONE);
    stm32wb_dma_start(spi->tx_dma, (uint32_t)&SPI->DR, (uint32_t)spi->tx_default, rx_count, tx_option);
	
    return true;
}

__attribute__((optimize("O3"))) bool stm32wb_spi_transmit(stm32wb_spi_t *spi, const uint8_t *tx_data, uint32_t tx_count, stm32wb_spi_done_callback_t callback, void *context)
{
    SPI_TypeDef *SPI = spi->SPI;
    uint32_t spi_cr2, rx_option, tx_option;
    
    if (armv7m_atomic_casb(&spi->state, STM32WB_SPI_STATE_DATA, STM32WB_SPI_STATE_DMA) != STM32WB_SPI_STATE_DATA)
    {
        return false;
    }

    if (!(spi->option & STM32WB_SPI_OPTION_RX_DMA))
    {
	if (!stm32wb_dma_enable(spi->rx_dma, spi->priority, (stm32wb_dma_callback_t)stm32wb_spi_dma_callback, spi))
	{
	    spi->state = STM32WB_SPI_STATE_DATA;
	    
	    return false;
	}
	
	spi->option |= STM32WB_SPI_OPTION_RX_DMA;
    }
    
    if (!(spi->option & STM32WB_SPI_OPTION_TX_DMA))
    {
	if (!stm32wb_dma_enable(spi->tx_dma, spi->priority, NULL, NULL))
	{
	    spi->state = STM32WB_SPI_STATE_DATA;
	    
	    return false;
	}
	
	spi->option |= STM32WB_SPI_OPTION_TX_DMA;
    }

    spi->xf_callback = callback;
    spi->xf_context = context;
    spi->rx_data = NULL;

    if ((tx_count & 1) || ((uint32_t)tx_data & 1))
    {
	spi_cr2 = spi->cr2 | (SPI_CR2_RXDMAEN | SPI_CR2_TXDMAEN);
		
	rx_option = STM32WB_SPI_RX_DMA_OPTION_TRANSMIT_8;
	tx_option = STM32WB_SPI_TX_DMA_OPTION_TRANSMIT_8;
    }
    else
    {
	spi_cr2 = (spi->cr2 & ~SPI_CR2_FRXTH) | (SPI_CR2_RXDMAEN | SPI_CR2_TXDMAEN);

	rx_option = STM32WB_SPI_RX_DMA_OPTION_TRANSMIT_16;
	tx_option = STM32WB_SPI_TX_DMA_OPTION_TRANSMIT_16;

	tx_count = tx_count / 2;
    }
    
    while (SPI->SR & (SPI_SR_FTLVL | SPI_SR_FRLVL | SPI_SR_BSY))
    {
    }

    SPI->CR1 = spi->cr1;
    SPI->CR2 = spi_cr2;
    SPI->CR1 = spi->cr1 | SPI_CR1_SPE;
		
    stm32wb_dma_start(spi->rx_dma, (uint32_t)spi->rx_none, (uint32_t)&SPI->DR, tx_count, rx_option | STM32WB_DMA_OPTION_EVENT_TRANSFER_DONE);
    stm32wb_dma_start(spi->tx_dma, (uint32_t)&SPI->DR, (uint32_t)tx_data, tx_count, tx_option);

    return true;
}

__attribute__((optimize("O3"))) bool stm32wb_spi_transfer(stm32wb_spi_t *spi, const uint8_t *tx_data, uint8_t *rx_data, uint32_t xf_count, stm32wb_spi_done_callback_t callback, void *context)
{
    SPI_TypeDef *SPI = spi->SPI;
    uint32_t spi_cr2, rx_option, tx_option;
    
    if (armv7m_atomic_casb(&spi->state, STM32WB_SPI_STATE_DATA, STM32WB_SPI_STATE_DMA) != STM32WB_SPI_STATE_DATA)
    {
        return false;
    }

    if (!(spi->option & STM32WB_SPI_OPTION_RX_DMA))
    {
	if (!stm32wb_dma_enable(spi->rx_dma, spi->priority, (stm32wb_dma_callback_t)stm32wb_spi_dma_callback, spi))
	{
	    spi->state = STM32WB_SPI_STATE_DATA;
	    
	    return false;
	}
	
	spi->option |= STM32WB_SPI_OPTION_RX_DMA;
    }
    
    if (!(spi->option & STM32WB_SPI_OPTION_TX_DMA))
    {
	if (!stm32wb_dma_enable(spi->tx_dma, spi->priority, NULL, NULL))
	{
	    spi->state = STM32WB_SPI_STATE_DATA;
	    
	    return false;
	}
	
	spi->option |= STM32WB_SPI_OPTION_TX_DMA;
    }

    spi->xf_callback = callback;
    spi->xf_context = context;
    spi->rx_data = rx_data;

    if ((xf_count & 1) || ((uint32_t)tx_data & 1) || ((uint32_t)rx_data & 1))
    {
	spi_cr2 = spi->cr2 | (SPI_CR2_RXDMAEN | SPI_CR2_TXDMAEN);
		
	rx_option = STM32WB_SPI_RX_DMA_OPTION_TRANSFER_8;
	tx_option = STM32WB_SPI_TX_DMA_OPTION_TRANSFER_8;
    }
    else
    {
	spi_cr2 = (spi->cr2 & ~SPI_CR2_FRXTH) | (SPI_CR2_RXDMAEN | SPI_CR2_TXDMAEN);

	rx_option = STM32WB_SPI_RX_DMA_OPTION_TRANSFER_16;
	tx_option = STM32WB_SPI_TX_DMA_OPTION_TRANSFER_16;

	xf_count = xf_count / 2;
    }

    while (SPI->SR & (SPI_SR_FTLVL | SPI_SR_FRLVL | SPI_SR_BSY))
    {
    }
    
    SPI->CR1 = spi->cr1;
    SPI->CR2 = spi_cr2;
    SPI->CR1 = spi->cr1 | SPI_CR1_SPE;

    stm32wb_dma_start(spi->rx_dma, (uint32_t)rx_data, (uint32_t)&SPI->DR, xf_count, rx_option | STM32WB_DMA_OPTION_EVENT_TRANSFER_DONE);
    stm32wb_dma_start(spi->tx_dma, (uint32_t)&SPI->DR, (uint32_t)tx_data, xf_count, tx_option);

    return true;
}

uint32_t stm32wb_spi_cancel(stm32wb_spi_t *spi)
{
    SPI_TypeDef *SPI = spi->SPI;
    uint32_t xf_count, xf_16bit;
    uint8_t rx_data;
    
    if (armv7m_atomic_casb(&spi->state, STM32WB_SPI_STATE_DMA, STM32WB_SPI_STATE_DATA) != STM32WB_SPI_STATE_DMA)
    {
        return 0;
    }

    xf_16bit = (SPI->CR2 & SPI_CR2_FRXTH) ? 0 : 1;

    stm32wb_dma_stop(spi->tx_dma);
	
    while (SPI->SR & (SPI_SR_FTLVL | SPI_SR_BSY))
    {
    }

    SPI->CR1 = spi->cr1;
    SPI->CR2 = spi->cr2;
    
    xf_count = stm32wb_dma_stop(spi->rx_dma) << xf_16bit;
    
    while (SPI->SR & SPI_SR_FRLVL)
    {
	rx_data = STM32WB_SPI_READ_8(SPI);
	
	if (spi->rx_data)
	{
	    spi->rx_data[xf_count] = rx_data;
	}
	
	xf_count++;
    }
	
    SPI->CR1 = spi->cr1 | SPI_CR1_SPE;

    return xf_count;
}

bool stm32wb_spi_done(stm32wb_spi_t *spi)
{
    return (spi->state != STM32WB_SPI_STATE_DMA);
}
