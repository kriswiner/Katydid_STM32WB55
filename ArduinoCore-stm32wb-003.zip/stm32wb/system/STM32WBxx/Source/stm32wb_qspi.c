/*
 * Copyright (c) 2016 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include <stdio.h>

#include "stm32wbxx.h"

#include "armv7m.h"

#include "stm32wb_gpio.h"
#include "stm32wb_qspi.h"
#include "stm32wb_dma.h"
#include "stm32wb_system.h"

typedef struct _stm32wb_qspi_driver_t {
    stm32wb_qspi_t     *instances[STM32WB_QSPI_INSTANCE_COUNT];
} stm32wb_qspi_driver_t;

static stm32wb_qspi_driver_t stm32wb_qspi_driver;

#define STM32WB_QSPI_RX_DMA_OPTION_RECEIVE_8	  \
    (STM32WB_DMA_OPTION_EVENT_TRANSFER_DONE |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_TO_MEMORY |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_8 |  \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_8 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_QSPI_RX_DMA_OPTION_RECEIVE_16	  \
    (STM32WB_DMA_OPTION_EVENT_TRANSFER_DONE |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_TO_MEMORY |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_16 | \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_16 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_QSPI_RX_DMA_OPTION_RECEIVE_32	  \
    (STM32WB_DMA_OPTION_EVENT_TRANSFER_DONE |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_TO_MEMORY |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_32 | \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_32 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_QSPI_TX_DMA_OPTION_TRANSMIT_8	  \
    (STM32WB_DMA_OPTION_MEMORY_TO_PERIPHERAL |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_8 |  \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_8 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_QSPI_TX_DMA_OPTION_TRANSMIT_16	  \
    (STM32WB_DMA_OPTION_MEMORY_TO_PERIPHERAL |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_16 | \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_16 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)

#define STM32WB_QSPI_TX_DMA_OPTION_TRANSMIT_32	  \
    (STM32WB_DMA_OPTION_MEMORY_TO_PERIPHERAL |	  \
     STM32WB_DMA_OPTION_PERIPHERAL_DATA_SIZE_32 | \
     STM32WB_DMA_OPTION_MEMORY_DATA_SIZE_32 |	  \
     STM32WB_DMA_OPTION_MEMORY_DATA_INCREMENT |	  \
     STM32WB_DMA_OPTION_PRIORITY_MEDIUM)



#define QUADSPI_CCR_FMODE_INDIRECT_WRITE    0
#define QUADSPI_CCR_FMODE_INDIRECT_READ     QUADSPI_CCR_FMODE_0
#define QUADSPI_CCR_FMODE_AUTOMATIC_POLLING QUADSPI_CCR_FMODE_1
#define QUADSPI_CCR_FMODE_MEMORY_MAPPED     (QUADSPI_CCR_FMODE_0 | QUADSPI_CCR_FMODE_1)

#define QUADSPI_CR_FTHRES_1                 0x00000000
#define QUADSPI_CR_FTHRES_2                 0x00000100
#define QUADSPI_CR_FTHRES_3                 0x00000200
#define QUADSPI_CR_FTHRES_4                 0x00000300
#define QUADSPI_CR_FTHRES_8                 0x00000700
#define QUADSPI_CR_FTHRES_16                0x00000F00

static void stm32wb_qspi_dma_callback(stm32wb_qspi_t *qspi, uint32_t events);

static inline __attribute__((optimize("O3"),always_inline)) void stm32wb_qspi_rd8(void *rx_data)
{
    *((uint8_t*)rx_data) = *((volatile uint8_t*)(&QUADSPI->DR));
}

static inline __attribute__((optimize("O3"),always_inline)) void stm32wb_qspi_rd32(void *rx_data)
{
    *((uint32_t*)rx_data) = QUADSPI->DR;
}

static inline __attribute__((optimize("O3"),always_inline)) void stm32wb_qspi_wr8(const void *tx_data)
{
    *((volatile uint8_t*)(&QUADSPI->DR)) = *((const uint8_t*)tx_data);
}

static inline __attribute__((optimize("O3"),always_inline)) void stm32wb_qspi_wr32(const void *tx_data)
{
    QUADSPI->DR = *((const uint32_t*)tx_data);
}

static void stm32wb_qspi_start(stm32wb_qspi_t *qspi)
{
    stm32wb_system_periph_enable(STM32WB_SYSTEM_PERIPH_QSPI);

    if (qspi->state != STM32WB_QSPI_STATE_BUSY)
    {
	if (qspi->xf_dma != STM32WB_DMA_CHANNEL_NONE)
	{
	    stm32wb_dma_enable(qspi->xf_dma, qspi->priority, (stm32wb_dma_callback_t)stm32wb_qspi_dma_callback, (void*)qspi);
	}
    }
}

static void stm32wb_qspi_stop(stm32wb_qspi_t *qspi)
{
    if (qspi->state != STM32WB_QSPI_STATE_BUSY)
    {
	if (stm32wb_dma_channel(qspi->xf_dma))
	{
	    stm32wb_dma_disable(qspi->xf_dma);
	}
    }

    stm32wb_system_periph_disable(STM32WB_SYSTEM_PERIPH_QSPI);
}

static void stm32wb_qspi_dma_callback(stm32wb_qspi_t *qspi, uint32_t events)
{
    QUADSPI->FCR = QUADSPI_FCR_CTCF;

    QUADSPI->CR |= QUADSPI_CR_ABORT;

    qspi->state = STM32WB_QSPI_STATE_SELECTED;

    if (qspi->events & STM32WB_QSPI_EVENT_RECEIVE_DONE)
    {
	(*qspi->callback)(qspi->context, STM32WB_QSPI_EVENT_RECEIVE_DONE);
    }
}

static void stm32wb_qspi_interrupt(stm32wb_qspi_t *qspi)
{
    uint8_t *rx_data, *rx_data_e;

      
    switch (qspi->state) {
    case STM32WB_QSPI_STATE_NONE:
    case STM32WB_QSPI_STATE_BUSY:
    case STM32WB_QSPI_STATE_READY:
    case STM32WB_QSPI_STATE_SELECTED:
    case STM32WB_QSPI_STATE_RECEIVE:
	break;

    case STM32WB_QSPI_STATE_TRANSMIT:
	if (QUADSPI->SR & QUADSPI_SR_TCF)
	{
	    NVIC_DisableIRQ(qspi->interrupt);

	    QUADSPI->FCR = QUADSPI_FCR_CTCF;
	    QUADSPI->CR = (QUADSPI->CR & ~QUADSPI_CR_TCIE);

	    qspi->state = STM32WB_QSPI_STATE_SELECTED;

	    if (qspi->events & STM32WB_QSPI_EVENT_TRANSMIT_DONE)
	    {
		(*qspi->callback)(qspi->context, STM32WB_QSPI_EVENT_TRANSMIT_DONE);
	    }
	}
	break;

    case STM32WB_QSPI_STATE_WAIT:
	if (QUADSPI->SR & QUADSPI_SR_SMF)
	{
	    NVIC_DisableIRQ(qspi->interrupt);

	    QUADSPI->FCR = QUADSPI_FCR_CSMF | QUADSPI_FCR_CTCF;
	    QUADSPI->CR = (QUADSPI->CR & ~QUADSPI_CR_SMIE);

	    rx_data = qspi->rx_data;
	    rx_data_e = rx_data + qspi->rx_count;
	    
	    while (rx_data != rx_data_e)
	    {
		stm32wb_qspi_rd8(rx_data);
		rx_data++;
	    }

	    qspi->state = STM32WB_QSPI_STATE_SELECTED;

	    if (qspi->events & STM32WB_QSPI_EVENT_WAIT_DONE)
	    {
		(*qspi->callback)(qspi->context, STM32WB_QSPI_EVENT_WAIT_DONE);
	    }
	}
	break;
    }
}

bool stm32wb_qspi_create(stm32wb_qspi_t *qspi, unsigned int instance, const stm32wb_qspi_pins_t *pins, unsigned int priority, uint16_t xf_dma)
{
    qspi->state = STM32WB_QSPI_STATE_NONE;
    qspi->instance = instance;
    qspi->pins = *pins;

    if (instance == STM32WB_QSPI_INSTANCE_QUADSPI)
    {
	qspi->interrupt = QUADSPI_IRQn;
    }
    else
    {
	return false;
    }

    qspi->priority = priority;
    qspi->xf_dma = xf_dma;

    stm32wb_qspi_driver.instances[instance] = qspi;

    return true;
}

bool stm32wb_qspi_destroy(stm32wb_qspi_t *qspi)
{
    if ((qspi->state != STM32WB_QSPI_STATE_NONE) && (qspi->state != STM32WB_QSPI_STATE_BUSY))
    {
	return false;
    }

    stm32wb_qspi_driver.instances[qspi->instance] = NULL;

    return true;
}

bool stm32wb_qspi_enable(stm32wb_qspi_t *qspi, uint32_t clock, uint32_t option, stm32wb_qspi_callback_t callback, void *context, uint32_t events)
{
    if (qspi->state != STM32WB_QSPI_STATE_NONE)
    {
	return false;
    }

    qspi->callback = NULL;
    qspi->context = NULL;
    qspi->events = 0;

    NVIC_SetPriority(qspi->interrupt, qspi->priority);

    qspi->state = STM32WB_QSPI_STATE_BUSY;

    if (!stm32wb_qspi_configure(qspi, clock, option))
    {
	qspi->state = STM32WB_QSPI_STATE_NONE;

	return false;
    }

    stm32wb_qspi_notify(qspi, callback, context, events);

    qspi->state = STM32WB_QSPI_STATE_READY;

    return true;
}

bool stm32wb_qspi_disable(stm32wb_qspi_t *qspi)
{
    if (qspi->state != STM32WB_QSPI_STATE_READY)
    {
	return false;
    }

    stm32wb_gpio_pin_configure(qspi->pins.clk, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_MODE_ANALOG));
    stm32wb_gpio_pin_configure(qspi->pins.ncs, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_MODE_ANALOG));
    stm32wb_gpio_pin_configure(qspi->pins.io0, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_MODE_ANALOG));
    stm32wb_gpio_pin_configure(qspi->pins.io1, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_MODE_ANALOG));
    stm32wb_gpio_pin_configure(qspi->pins.io2, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_MODE_ANALOG));
    stm32wb_gpio_pin_configure(qspi->pins.io3, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_MODE_ANALOG));

    qspi->state = STM32WB_QSPI_STATE_NONE;

    return true;
}

bool stm32wb_qspi_configure(stm32wb_qspi_t *qspi, uint32_t clock, uint32_t option)
{
    uint32_t hclk;

    if ((qspi->state != STM32WB_QSPI_STATE_READY) && (qspi->state != STM32WB_QSPI_STATE_BUSY))
    {
	return false;
    }

    if (clock > 48000000)
    {
	return false;
    }

    hclk = stm32wb_system_hclk();

    if (clock > hclk)
    {
	clock = hclk;
    }

    qspi->clock = clock;
    qspi->option = option;

    stm32wb_qspi_start(qspi);

    QUADSPI->CR &= ~QUADSPI_CR_EN;
    
    QUADSPI->CR = (((hclk / clock) -1) << 24) | QUADSPI_CR_APMS | QUADSPI_CR_FTHRES_1;
    // QUADSPI->CR = QUADSPI_CR_APMS | QUADSPI_CR_FTHRES_1;

    QUADSPI->DCR = QUADSPI_DCR_FSIZE | ((qspi->option & STM32WB_QSPI_OPTION_MODE_MASK) >> STM32WB_QSPI_OPTION_MODE_SHIFT);
    
    stm32wb_gpio_pin_configure(qspi->pins.clk, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_OSPEED_VERY_HIGH | STM32WB_GPIO_OTYPE_PUSHPULL | STM32WB_GPIO_MODE_ALTERNATE));
    stm32wb_gpio_pin_configure(qspi->pins.ncs, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_OSPEED_VERY_HIGH | STM32WB_GPIO_OTYPE_PUSHPULL | STM32WB_GPIO_MODE_ALTERNATE));
    stm32wb_gpio_pin_configure(qspi->pins.io0, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_OSPEED_VERY_HIGH | STM32WB_GPIO_OTYPE_PUSHPULL | STM32WB_GPIO_MODE_ALTERNATE));
    stm32wb_gpio_pin_configure(qspi->pins.io1, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_OSPEED_VERY_HIGH | STM32WB_GPIO_OTYPE_PUSHPULL | STM32WB_GPIO_MODE_ALTERNATE));
    stm32wb_gpio_pin_configure(qspi->pins.io2, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_OSPEED_VERY_HIGH | STM32WB_GPIO_OTYPE_PUSHPULL | STM32WB_GPIO_MODE_ALTERNATE));
    stm32wb_gpio_pin_configure(qspi->pins.io3, (STM32WB_GPIO_PUPD_NONE | STM32WB_GPIO_OSPEED_VERY_HIGH | STM32WB_GPIO_OTYPE_PUSHPULL | STM32WB_GPIO_MODE_ALTERNATE));
	
    stm32wb_qspi_stop(qspi);

    return true;
}

bool stm32wb_qspi_notify(stm32wb_qspi_t *qspi, stm32wb_qspi_callback_t callback, void *context, uint32_t events)
{
    if ((qspi->state != STM32WB_QSPI_STATE_READY) && (qspi->state != STM32WB_QSPI_STATE_BUSY))
    {
	return false;
    }

    qspi->callback = callback;
    qspi->context = context;
    qspi->events = callback ? events : 0x00000000;

    return true;
}

bool stm32wb_qspi_select(stm32wb_qspi_t *qspi) 
{
    if ((qspi->state != STM32WB_QSPI_STATE_READY) && (qspi->state != STM32WB_QSPI_STATE_SELECTED))
    {
	return false;
    }

    qspi->select++;

    if (qspi->select == 1)
    {
	stm32wb_qspi_start(qspi);

	QUADSPI->CR |= QUADSPI_CR_EN;

	qspi->state = STM32WB_QSPI_STATE_SELECTED;
    }

    return true;
}

bool stm32wb_qspi_unselect(stm32wb_qspi_t *qspi)
{
    if (qspi->state != STM32WB_QSPI_STATE_SELECTED)
    {
	return false;
    }

    qspi->select--;

    if (qspi->select == 0)
    {
	QUADSPI->CR &= ~QUADSPI_CR_EN;

	stm32wb_qspi_stop(qspi);

	qspi->state = STM32WB_QSPI_STATE_READY;
    }

    return true;
}

bool stm32wb_qspi_mode(stm32wb_qspi_t *qspi, uint32_t mode)
{
    if (qspi->state != STM32WB_QSPI_STATE_SELECTED)
    {
	return false;
    }

    while (QUADSPI->SR & QUADSPI_SR_BUSY) { }

    QUADSPI->ABR = mode;

    return true;
}

bool stm32wb_qspi_command(stm32wb_qspi_t *qspi, uint32_t command, uint32_t address)
{
    if (qspi->state != STM32WB_QSPI_STATE_SELECTED)
    {
	return false;
    }
    
    while (QUADSPI->SR & QUADSPI_SR_BUSY) { }

    QUADSPI->CCR = command | QUADSPI_CCR_FMODE_INDIRECT_READ;

    if ((command & STM32WB_QSPI_COMMAND_ADDRESS_MASK) != STM32WB_QSPI_COMMAND_ADDRESS_NONE)
    {
	QUADSPI->AR = address;
    }

    return true;
}

bool stm32wb_qspi_receive(stm32wb_qspi_t *qspi, uint32_t command, uint32_t address, uint8_t *rx_data, unsigned int rx_count, uint32_t control)
{
    uint32_t quadspi_cr, quadspi_sr, dma_count, dma_option;
    uint8_t *rx_data_e;

    if (qspi->state != STM32WB_QSPI_STATE_SELECTED)
    {
	return false;
    }

    if (!(control & STM32WB_QSPI_CONTROL_ASYNC))
    {
	while (QUADSPI->SR & QUADSPI_SR_BUSY) { }

	if (!(rx_count & 3))
	{
	    QUADSPI->CR = (QUADSPI->CR & ~QUADSPI_CR_FTHRES) | QUADSPI_CR_FTHRES_4;
	}
	else
	{
	    QUADSPI->CR = (QUADSPI->CR & ~QUADSPI_CR_FTHRES) | QUADSPI_CR_FTHRES_1;
	}

	QUADSPI->DLR = rx_count -1;
	QUADSPI->CCR = command | QUADSPI_CCR_FMODE_INDIRECT_READ;

	if ((command & STM32WB_QSPI_COMMAND_ADDRESS_MASK) != STM32WB_QSPI_COMMAND_ADDRESS_NONE)
	{
	    QUADSPI->AR = address;
	}

	rx_data_e = rx_data + rx_count;

	if (!(rx_count & 3))
	{
	    while (rx_data != rx_data_e)
	    {
		quadspi_sr = QUADSPI->SR;

		if (quadspi_sr & QUADSPI_SR_TCF)
		{
		    while (rx_data != rx_data_e)
		    {
			stm32wb_qspi_rd32(rx_data);
			rx_data += 4;
		    }

		    break;
		}

		if (quadspi_sr & QUADSPI_SR_FTF)
		{
		    stm32wb_qspi_rd32(rx_data);
		    rx_data += 4;
		}
	    }
	}
	else
	{
	    while (rx_data != rx_data_e)
	    {
		quadspi_sr = QUADSPI->SR;

		if (quadspi_sr & QUADSPI_SR_TCF)
		{
		    while (rx_data != rx_data_e)
		    {
			stm32wb_qspi_rd8(rx_data);
			rx_data += 1;
		    }

		    break;
		}

		if (quadspi_sr & QUADSPI_SR_FTF)
		{
		    stm32wb_qspi_rd8(rx_data);
		    rx_data += 1;
		}
	    }
	}

	QUADSPI->FCR = QUADSPI_FCR_CTCF;

	QUADSPI->CR |= QUADSPI_CR_ABORT;
    }
    else
    {
	if (!stm32wb_dma_channel(qspi->xf_dma))
	{
	    return false;
	}

	while (QUADSPI->SR & QUADSPI_SR_BUSY) { }

	quadspi_cr = QUADSPI->CR & ~QUADSPI_CR_FTHRES;

	if (!(((uint32_t)rx_data | rx_count) & 3))
	{
	    quadspi_cr |= QUADSPI_CR_FTHRES_4;

	    dma_option = STM32WB_QSPI_RX_DMA_OPTION_RECEIVE_32;
	    dma_count = rx_count / 4;
	}
	else if (!(((uint32_t)rx_data | rx_count) & 1))
	{
	    quadspi_cr |= QUADSPI_CR_FTHRES_2;

	    dma_option = STM32WB_QSPI_RX_DMA_OPTION_RECEIVE_16;
	    dma_count = rx_count / 2;
	}
	else
	{
	    quadspi_cr |= QUADSPI_CR_FTHRES_1;

	    dma_option = STM32WB_QSPI_RX_DMA_OPTION_RECEIVE_8;
	    dma_count = rx_count;
	}

	qspi->state = STM32WB_QSPI_STATE_RECEIVE;

	QUADSPI->CR = quadspi_cr | QUADSPI_CR_DMAEN;

	QUADSPI->DLR = rx_count -1;
	QUADSPI->CCR = command | QUADSPI_CCR_FMODE_INDIRECT_READ;
	
	if ((command & STM32WB_QSPI_COMMAND_ADDRESS_MASK) != STM32WB_QSPI_COMMAND_ADDRESS_NONE)
	{
	    QUADSPI->AR = address;
	}
	
	stm32wb_dma_start(qspi->xf_dma, (uint32_t)rx_data, (uint32_t)&QUADSPI->DR, dma_count, dma_option);
    }

    return true;
}

bool stm32wb_qspi_transmit(stm32wb_qspi_t *qspi, uint32_t command, uint32_t address, const uint8_t *tx_data, unsigned int tx_count, uint32_t control)
{
    const uint8_t *tx_data_e;
    uint32_t quadspi_cr, dma_count, dma_option;

    if (qspi->state != STM32WB_QSPI_STATE_SELECTED)
    {
	return false;
    }
    
    if (!(control & STM32WB_QSPI_CONTROL_ASYNC))
    {
	while (QUADSPI->SR & QUADSPI_SR_BUSY) { }

	if (!(tx_count & 3))
	{
	    QUADSPI->CR = (QUADSPI->CR & ~QUADSPI_CR_FTHRES) | QUADSPI_CR_FTHRES_4;
	}
	else
	{
	    QUADSPI->CR = (QUADSPI->CR & ~QUADSPI_CR_FTHRES) | QUADSPI_CR_FTHRES_1;
	}

	QUADSPI->DLR = tx_count -1;
	QUADSPI->CCR = command | QUADSPI_CCR_FMODE_INDIRECT_WRITE;

	if ((command & STM32WB_QSPI_COMMAND_ADDRESS_MASK) != STM32WB_QSPI_COMMAND_ADDRESS_NONE)
	{
	    QUADSPI->AR = address;
	}

	tx_data_e = tx_data + tx_count;

	if (!(tx_count & 3))
	{
	    while (tx_data != tx_data_e)
	    {
		while (!(QUADSPI->SR & QUADSPI_SR_FTF)) { };
		
		stm32wb_qspi_wr32(tx_data);
		tx_data += 4;
	    }
	}
	else
	{
	    while (tx_data != tx_data_e)
	    {
		while (!(QUADSPI->SR & QUADSPI_SR_FTF)) { };
		
		stm32wb_qspi_wr8(tx_data);
		tx_data += 1;
	    }
	}

	while (!(QUADSPI->SR & QUADSPI_SR_TCF)) { };
	
	QUADSPI->FCR = QUADSPI_FCR_CTCF;
    }
    else
    {
	if (!stm32wb_dma_channel(qspi->xf_dma))
	{
	    return false;
	}

	while (QUADSPI->SR & QUADSPI_SR_BUSY) { }

	quadspi_cr = QUADSPI->CR & ~QUADSPI_CR_FTHRES;
	
	if (!(((uint32_t)tx_data | tx_count) & 3))
	{
	    quadspi_cr |= QUADSPI_CR_FTHRES_4;

	    dma_option = STM32WB_QSPI_TX_DMA_OPTION_TRANSMIT_32;
	    dma_count = tx_count / 4;
	}
	else if (!(((uint32_t)tx_data | tx_count) & 1))
	{
	    quadspi_cr |= QUADSPI_CR_FTHRES_2;

	    dma_option = STM32WB_QSPI_TX_DMA_OPTION_TRANSMIT_16;
	    dma_count = tx_count / 2;
	}
	else
	{
	    quadspi_cr |= QUADSPI_CR_FTHRES_1;
	    
	    dma_option = STM32WB_QSPI_TX_DMA_OPTION_TRANSMIT_8;
	    dma_count = tx_count;
	}

	qspi->state = STM32WB_QSPI_STATE_TRANSMIT;

	NVIC_EnableIRQ(qspi->interrupt);
	    
	QUADSPI->CR = quadspi_cr | QUADSPI_CR_TCIE | QUADSPI_CR_DMAEN;
	    
	QUADSPI->DLR = tx_count -1;
	QUADSPI->CCR = command | QUADSPI_CCR_FMODE_INDIRECT_WRITE;
	
	if ((command & STM32WB_QSPI_COMMAND_ADDRESS_MASK) != STM32WB_QSPI_COMMAND_ADDRESS_NONE)
	{
	    QUADSPI->AR = address;
	}
	
	stm32wb_dma_start(qspi->xf_dma, (uint32_t)&QUADSPI->DR, (uint32_t)tx_data, dma_count, dma_option);
    }

    return true;
}

bool stm32wb_qspi_wait(stm32wb_qspi_t *qspi, uint32_t command, uint32_t address, uint8_t *rx_data, unsigned int rx_count, uint32_t mask, uint32_t match, uint32_t control)
{
    uint8_t *rx_data_e;

    if (qspi->state != STM32WB_QSPI_STATE_SELECTED)
    {
	return false;
    }
    
    while (QUADSPI->SR & QUADSPI_SR_BUSY) { }

    QUADSPI->PSMKR = mask;
    QUADSPI->PSMAR = match;
    QUADSPI->PIR   = 0;
    
    QUADSPI->DLR = rx_count -1;
    
    if (!(control & STM32WB_QSPI_CONTROL_ASYNC))
    {
	QUADSPI->CCR = command | QUADSPI_CCR_FMODE_AUTOMATIC_POLLING;

	if ((command & STM32WB_QSPI_COMMAND_ADDRESS_MASK) != STM32WB_QSPI_COMMAND_ADDRESS_NONE)
	{
	    QUADSPI->AR = address;
	}

	while (!(QUADSPI->SR & QUADSPI_SR_SMF)) { }

	QUADSPI->FCR = QUADSPI_FCR_CSMF | QUADSPI_FCR_CTCF;

	rx_data_e = rx_data + rx_count;

	while (rx_data != rx_data_e)
	{
	    stm32wb_qspi_rd8(rx_data);
	    rx_data++;
	}
    }
    else
    {
	qspi->rx_data = rx_data;
	qspi->rx_count = rx_count;

	qspi->state = STM32WB_QSPI_STATE_WAIT;

	QUADSPI->CR |= QUADSPI_CR_SMIE;

	NVIC_EnableIRQ(qspi->interrupt);

	QUADSPI->CCR = command | QUADSPI_CCR_FMODE_AUTOMATIC_POLLING;

	if ((command & STM32WB_QSPI_COMMAND_ADDRESS_MASK) != STM32WB_QSPI_COMMAND_ADDRESS_NONE)
	{
	    QUADSPI->AR = address;
	}
    }

    return true;
}

bool stm32wb_qspi_done(stm32wb_qspi_t *qspi)
{
    return ((qspi->state == STM32WB_QSPI_STATE_READY) || (qspi->state == STM32WB_QSPI_STATE_SELECTED));
}

void QUADSPI_IRQHandler(void)
{
    stm32wb_qspi_interrupt(stm32wb_qspi_driver.instances[STM32WB_QSPI_INSTANCE_QUADSPI]);
}
