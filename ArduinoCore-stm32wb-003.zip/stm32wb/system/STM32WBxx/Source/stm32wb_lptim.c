/*
 * Copyright (c) 2017-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include "armv7m.h"
#include "stm32wbxx.h"

#include "stm32wb_lptim.h"
#include "stm32wb_system.h"

#define STM32WB_LPTIM_STATE_NONE    0
#define STM32WB_LPTIM_STATE_READY   1

typedef struct _stm32wb_lptim_device_t {
    volatile uint8_t                   state;
    volatile uint8_t                   busy;
    volatile uint8_t                   next;
    volatile uint32_t                  clock;
    volatile uint32_t                  compare[2];
    volatile uint32_t                  reference[2];
    volatile uint32_t                  timeout_clock;
    stm32wb_lptim_timeout_t            *timeout_queue;
    stm32wb_lptim_timeout_t * volatile timeout_modify;
} stm32wb_lptim_device_t;

static stm32wb_lptim_device_t stm32wb_lptim_device;

#define STM32WB_LPTIM_TIMEOUT_SENTINEL   ((stm32wb_lptim_timeout_t*)0xffffffff)
#define STM32WB_LPTIM_TIMEOUT_INVALID    (0x80000000)

void __stm32wb_lptim_initialize(void)
{
    NVIC_SetPriority(LPTIM1_IRQn, STM32WB_LPTIM_IRQ_PRIORITY);

    stm32wb_lptim_device.timeout_queue = NULL;
    stm32wb_lptim_device.timeout_modify = STM32WB_LPTIM_TIMEOUT_SENTINEL;
}

static void stm32wb_lptim_clock_start(uint32_t compare)
{
    stm32wb_system_periph_enable(STM32WB_SYSTEM_PERIPH_LPTIM1);

    LPTIM1->IER = LPTIM_IER_CMPOKIE | LPTIM_IER_ARRMIE | LPTIM_IER_CMPMIE;
    LPTIM1->CFGR = 0;

    LPTIM1->CR = LPTIM_CR_ENABLE;
    LPTIM1->CMP = compare & 0xffff;
    LPTIM1->ARR = 0xffff;
    LPTIM1->CR = LPTIM_CR_CNTSTRT | LPTIM_CR_ENABLE;

    stm32wb_lptim_device.state = STM32WB_LPTIM_STATE_READY;
    stm32wb_lptim_device.busy = 1;
    stm32wb_lptim_device.next = 0;
    stm32wb_lptim_device.clock = 0;

    stm32wb_system_lock(STM32WB_SYSTEM_LOCK_RUN);
    stm32wb_system_lock(STM32WB_SYSTEM_LOCK_STOP_2);

    NVIC_EnableIRQ(LPTIM1_IRQn);
}

static void stm32wb_lptim_clock_stop()
{
    NVIC_DisableIRQ(LPTIM1_IRQn);

    stm32wb_system_unlock(STM32WB_SYSTEM_LOCK_STOP_2);

    if (stm32wb_lptim_device.busy)
    {
	stm32wb_system_unlock(STM32WB_SYSTEM_LOCK_RUN);
    }
    
    stm32wb_lptim_device.state = STM32WB_LPTIM_STATE_NONE;

    /* ERRATA: MCU may remain stuck in LPTIM interrupt when entering Stop mode
     */
    stm32wb_system_periph_reset(STM32WB_SYSTEM_PERIPH_LPTIM1);
}

static inline __attribute__((optimize("O3"),always_inline)) uint32_t stm32wb_lptim_clock_read()
{
    uint32_t clock, clock_previous;

    if (stm32wb_lptim_device.state == STM32WB_LPTIM_STATE_READY)
    {
	clock = (LPTIM1->CNT & 0xffff) + stm32wb_lptim_device.clock;

	do
	{
	    clock_previous = clock;
	    
	    clock = (LPTIM1->CNT & 0xffff) + stm32wb_lptim_device.clock;
	}
	while (clock != clock_previous);
    }
    else
    {
	clock = 0;
    }

    return clock;
}

static void stm32wb_lptim_timeout_remove(stm32wb_lptim_timeout_t *timeout)
{
    if (timeout->next == timeout)
    {
	stm32wb_lptim_device.timeout_queue = NULL;
    }
    else
    {
	if (timeout == stm32wb_lptim_device.timeout_queue)
	{
	    stm32wb_lptim_device.timeout_queue = timeout->next;
	}
	
	timeout->next->previous = timeout->previous;
	timeout->previous->next = timeout->next;
    }
    
    timeout->next = NULL;
    timeout->previous = NULL;
}

static void stm32wb_lptim_timeout_insert(stm32wb_lptim_timeout_t *timeout, uint32_t reference, uint32_t ticks)
{
    stm32wb_lptim_timeout_t *timeout_element, *timeout_next;
    uint32_t clock, elapsed;

    elapsed = (reference - stm32wb_lptim_device.timeout_clock);

    if (stm32wb_lptim_device.timeout_queue == NULL)
    {
	timeout->next = timeout;
	timeout->previous = timeout;

	stm32wb_lptim_device.timeout_queue = timeout;
    }
    else
    {
	timeout_element = stm32wb_lptim_device.timeout_queue;

	do
	{
	    timeout_next = timeout_element->next;

	    clock = timeout_element->clock;

	    if (timeout_element->modify != NULL)
	    {
		stm32wb_lptim_timeout_remove(timeout_element);
	    }
	    else
	    {
		if ((elapsed + ticks) < (clock - stm32wb_lptim_device.timeout_clock))
		{
		    if (timeout_element == stm32wb_lptim_device.timeout_queue)
		    {
			stm32wb_lptim_device.timeout_queue = timeout;
		    }
		    break;
		}
	    }

	    timeout_element = timeout_next;
	}
	while (timeout_element != stm32wb_lptim_device.timeout_queue);

	if (stm32wb_lptim_device.timeout_queue == NULL)
	{
	    timeout->next = timeout;
	    timeout->previous = timeout;
	    
	    stm32wb_lptim_device.timeout_queue = timeout;
	}
	else
	{
	    timeout->previous = timeout_element->previous;
	    timeout->next = timeout_element;
	    
	    timeout->previous->next = timeout;
	    timeout->next->previous = timeout;
	}
    }
    
    __armv7m_atomic_cas(&timeout->clock, ticks, (stm32wb_lptim_device.timeout_clock + elapsed + ticks));
}

static __attribute__((optimize("O3"))) void stm32wb_lptim_timeout_routine(void)
{
    stm32wb_lptim_timeout_t *timeout, *timeout_next, *timeout_previous;
    stm32wb_lptim_callback_t callback;
    uint32_t reference, ticks, ticks_next, elapsed, clock;
	
    timeout = (stm32wb_lptim_timeout_t*)__armv7m_atomic_swap((volatile uint32_t*)&stm32wb_lptim_device.timeout_modify, (uint32_t)STM32WB_LPTIM_TIMEOUT_SENTINEL);

    do
    {
	reference = stm32wb_lptim_clock_read();

	if (timeout != STM32WB_LPTIM_TIMEOUT_SENTINEL)
	{
	    /* Revert the modify queue, and process it.
	     */
	    for (timeout_previous = STM32WB_LPTIM_TIMEOUT_SENTINEL; timeout != STM32WB_LPTIM_TIMEOUT_SENTINEL; timeout = timeout_next)
	    {
		timeout_next = timeout->modify;
		
		timeout->modify = timeout_previous;
		
		timeout_previous = timeout;
	    }

	    timeout = timeout_previous;
	    
	    while (timeout != STM32WB_LPTIM_TIMEOUT_SENTINEL)
	    {
		timeout_next = timeout->modify;
		
		/* Here tick need to be loaded atomically, while cleaning out the
		 * STM32WB_LPTIM_TIMEOUT_INVALID bit. After the timeout is released from 
		 * the modify queue, anther ticks is needed to make sure no other code
		 ( updated timeout->clock between the last read and the setting of
		 * timeout->modify to NULL (otherwise we'd lose an update). 
		 * If however in the meantime timeout->modify indicates that the timeout
		 * is again in the modify queue, defer the update to the next time.
		 */
		
		ticks = __armv7m_atomic_and(&timeout->clock, ~STM32WB_LPTIM_TIMEOUT_INVALID) & ~STM32WB_LPTIM_TIMEOUT_INVALID;
		
		timeout->modify = NULL;
		
		if ((timeout->modify == NULL) && (timeout->clock & STM32WB_LPTIM_TIMEOUT_INVALID))
		{
		    ticks_next = __armv7m_atomic_and(&timeout->clock, ~STM32WB_LPTIM_TIMEOUT_INVALID) & ~STM32WB_LPTIM_TIMEOUT_INVALID;
		    
		    if (timeout->modify != NULL)
		    {
			__armv7m_atomic_or(&timeout->clock, STM32WB_LPTIM_TIMEOUT_INVALID);
		    }
		    else
		    {
			ticks = ticks_next;
		    }
		}
		
		if (timeout->next)
		{
		    stm32wb_lptim_timeout_remove(timeout);
		}
		
		if (ticks)
		{
		    stm32wb_lptim_timeout_insert(timeout, reference, ticks);
		}
		
		timeout = timeout_next;
	    }
	}
	
	if (stm32wb_lptim_device.timeout_queue != NULL)
	{
	    elapsed = reference - stm32wb_lptim_device.timeout_clock;
	    
	    do
	    {
		timeout = stm32wb_lptim_device.timeout_queue;
		
		clock = timeout->clock;
		callback = timeout->callback;
		
		if (timeout->modify != NULL)
		{
		    stm32wb_lptim_timeout_remove(timeout);
		}
		else
		{
		    if ((clock - stm32wb_lptim_device.timeout_clock) > elapsed)
		    {
			break;
		    }

		    stm32wb_lptim_timeout_remove(timeout);
			
		    if (callback)
		    {
			(*callback)(timeout);
		    }
		}
	    }
	    while (stm32wb_lptim_device.timeout_queue != NULL);
	}
	
	stm32wb_lptim_device.timeout_clock = reference;

	timeout = (stm32wb_lptim_timeout_t*)__armv7m_atomic_swap((volatile uint32_t*)&stm32wb_lptim_device.timeout_modify, (uint32_t)STM32WB_LPTIM_TIMEOUT_SENTINEL);
    }
    while (timeout != STM32WB_LPTIM_TIMEOUT_SENTINEL);
    
    if (stm32wb_lptim_device.timeout_queue != NULL)
    {
	timeout = stm32wb_lptim_device.timeout_queue;

	clock = timeout->clock;
	
	if (timeout->modify == NULL)
	{
	    if (stm32wb_lptim_device.state != STM32WB_LPTIM_STATE_NONE)
	    {
		if (stm32wb_lptim_device.compare[1] != clock)
		{
		    NVIC_DisableIRQ(LPTIM1_IRQn);
		    
		    stm32wb_lptim_device.compare[1] = clock;
		    stm32wb_lptim_device.reference[1] = reference;
		    stm32wb_lptim_device.next = 1;
		    
		    NVIC_EnableIRQ(LPTIM1_IRQn);
		    
		    if (!stm32wb_lptim_device.busy)
		    {
			if (stm32wb_lptim_device.next)
			{
			    stm32wb_lptim_device.next = 0;
			    
			    stm32wb_lptim_device.compare[0] = clock;
			    stm32wb_lptim_device.reference[0] = reference;
			    
			    stm32wb_system_lock(STM32WB_SYSTEM_LOCK_RUN);
			    
			    stm32wb_lptim_device.busy = 1;
			    
			    LPTIM1->CMP = clock & 0xffff;
			}
		    }
		}
	    }
	    else
	    {
		stm32wb_lptim_device.compare[0] = clock;
		stm32wb_lptim_device.reference[0] = reference;
		stm32wb_lptim_device.compare[1] = clock;
		stm32wb_lptim_device.reference[1] = reference;
		
		stm32wb_lptim_clock_start(clock);
	    }
	}
    }
    else
    {
	if (stm32wb_lptim_device.state != STM32WB_LPTIM_STATE_NONE)
	{
	    stm32wb_lptim_clock_stop();
	    
	    stm32wb_lptim_device.timeout_clock = 0;
	}
    }
}

static void stm32wb_lptim_timeout_modify(stm32wb_lptim_timeout_t *timeout, uint32_t ticks, stm32wb_lptim_callback_t callback)
{
    armv7m_core_store_2((volatile uint32_t*)&timeout->clock, (uint32_t)(ticks | STM32WB_LPTIM_TIMEOUT_INVALID), (uint32_t)callback);

    if (__armv7m_atomic_cas((volatile uint32_t*)&timeout->modify, (uint32_t)NULL, (uint32_t)STM32WB_LPTIM_TIMEOUT_SENTINEL) == (uint32_t)NULL)
    {
        timeout->modify = (stm32wb_lptim_timeout_t*)__armv7m_atomic_swap((volatile uint32_t*)&stm32wb_lptim_device.timeout_modify, (uint32_t)timeout);

	armv7m_pendsv_raise(ARMV7M_PENDSV_SWI_LPTIM);
    }
}

void stm32wb_lptim_timeout_create(stm32wb_lptim_timeout_t *timeout)
{
    timeout->next = NULL;
    timeout->previous = NULL;
    timeout->modify = NULL;
    timeout->clock = 0;
    timeout->callback = NULL;
}

void stm32wb_lptim_timeout_destroy(stm32wb_lptim_timeout_t *timeout)
{
}

bool stm32wb_lptim_timeout_start(stm32wb_lptim_timeout_t *timeout, uint32_t ticks, stm32wb_lptim_callback_t callback)
{
    if ((ticks == 0) || (ticks & STM32WB_LPTIM_TIMEOUT_INVALID))
    {
	return false;
    }
    
    if (!armv7m_interrupt_is_in_progress())
    {
        armv7m_svcall_3((uint32_t)&stm32wb_lptim_timeout_modify, (uint32_t)timeout, (uint32_t)ticks, (uint32_t)callback);
    }
    else
    {
	stm32wb_lptim_timeout_modify(timeout, ticks, callback);
    }

    return true;
}

void stm32wb_lptim_timeout_stop(stm32wb_lptim_timeout_t *timeout)
{
    if (!armv7m_interrupt_is_in_progress())
    {
	armv7m_svcall_3((uint32_t)&stm32wb_lptim_timeout_modify, (uint32_t)timeout, (uint32_t)0, (uint32_t)NULL);
    }
    else
    {
	stm32wb_lptim_timeout_modify(timeout, 0, NULL);
    }
}

bool stm32wb_lptim_timeout_done(stm32wb_lptim_timeout_t *timeout)
{
    return (timeout->next == NULL) && (timeout->modify == NULL);
}

void LPTIM1_IRQHandler(void)
{
    uint32_t lptim_isr, clock, compare, reference;
    bool events = false;

    lptim_isr = LPTIM1->ISR;

    if (lptim_isr & LPTIM_ISR_ARRM)
    {
        LPTIM1->ICR = LPTIM_ICR_ARRMCF;
        
	if (!stm32wb_lptim_device.busy)
	{
	    if ((stm32wb_lptim_device.compare[0] & 0x0000ffff) == 0x0000ffff)
	    {
		LPTIM1->ICR = LPTIM_ICR_CMPMCF;
		
		if ((stm32wb_lptim_device.compare[0] & 0xffff0000) == stm32wb_lptim_device.clock)
		{
		    events = true;
		}
	    }
	}

        stm32wb_lptim_device.clock += 0x00010000;
    }

    if (lptim_isr & LPTIM_ISR_CMPM)
    {
	LPTIM1->ICR = LPTIM_ICR_CMPMCF;

	if (!stm32wb_lptim_device.busy)
	{
	    if (stm32wb_lptim_device.clock == (stm32wb_lptim_device.compare[0] & 0xffff0000))
	    {
		events = true;
	    }
	}
    }

    if (lptim_isr & LPTIM_ISR_CMPOK)
    {
	LPTIM1->ICR = LPTIM_ICR_CMPOKCF;

	if (stm32wb_lptim_device.busy)
	{
	    compare = stm32wb_lptim_device.compare[0];
	    reference = stm32wb_lptim_device.reference[0];

	    clock = stm32wb_lptim_clock_read();

	    if ((clock - reference) >= (compare - reference))
	    {
		events = true;
	    }

	    if (events)
	    {
		stm32wb_lptim_device.busy = 0;
		stm32wb_lptim_device.next = 0;
		    
		stm32wb_system_unlock(STM32WB_SYSTEM_LOCK_RUN);
	    }
	    else
	    {
		if (stm32wb_lptim_device.next)
		{
		    stm32wb_lptim_device.next = 0;
		    
		    compare = stm32wb_lptim_device.compare[1];
		    reference = stm32wb_lptim_device.reference[1];
		    
		    stm32wb_lptim_device.compare[0] = compare;
		    stm32wb_lptim_device.reference[0] = reference;
		    
		    LPTIM1->CMP = compare & 0xffff;
		}
		else
		{
		    stm32wb_lptim_device.busy = 0;
		    
		    stm32wb_system_unlock(STM32WB_SYSTEM_LOCK_RUN);
		}
	    }
	}
    }

    if (events)
    {
	armv7m_pendsv_raise(ARMV7M_PENDSV_SWI_LPTIM);
    }
}

void SWI_LPTIM_IRQHandler(void)
{
    stm32wb_lptim_timeout_routine();
}
