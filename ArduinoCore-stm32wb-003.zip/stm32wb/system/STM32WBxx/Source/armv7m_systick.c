/*
 * Copyright (c) 2017-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include "armv7m.h"
#include "stm32wb_rtc.h"

typedef struct _armv7m_systick_control_t {
    volatile uint64_t         ticks;
    volatile uint64_t         micros;
    volatile uint64_t         millis;
    uint32_t                  offset;
    uint32_t                  cycle;
    uint32_t                  scale[2];
} armv7m_systick_control_t;

static armv7m_systick_control_t armv7m_systick_control;

void __armv7m_systick_initialize(void)
{
    NVIC_SetPriority(SysTick_IRQn, ARMV7M_IRQ_PRIORITY_SYSTICK);
}

void armv7m_systick_configure(uint32_t clock)
{
    armv7m_systick_control.ticks  = 0;
    armv7m_systick_control.millis = 0;
    armv7m_systick_control.micros = 0;
    armv7m_systick_control.offset = 0;

    if (clock <= 2000000)
    {
	armv7m_systick_control.cycle = clock / 8 -1;
	
	SysTick->CTRL |= SysTick_CTRL_CLKSOURCE_Msk;
    }
    else
    {
	armv7m_systick_control.cycle = clock / 64 -1;
	
	SysTick->CTRL &= ~SysTick_CTRL_CLKSOURCE_Msk;
    }

    /* micros = 125000 * (count / (cycle +1))
     * micros = (125000 / (cycle +1)) * count
     * micros = ((125000 / (cycle +1) * (2 ^ 32)) * count) / (2^32)
     */

    armv7m_systick_control.scale[0] = (uint64_t)(125000ull * 0x100000000ull) / (uint64_t)(armv7m_systick_control.cycle +1);
    armv7m_systick_control.scale[1] = (uint64_t)(   125ull * 0x100000000ull) / (uint64_t)(armv7m_systick_control.cycle +1);
}

__attribute__((optimize("O3"))) void armv7m_systick_enable(void)
{
    uint64_t clock, ticks, count;
    uint32_t offset;

    clock = stm32wb_rtc_clock_read();
    
    ticks = clock * (uint32_t)((armv7m_systick_control.cycle +1) / (STM32WB_RTC_CLOCK_TICKS_PER_SECOND / 8));

    if (armv7m_systick_control.ticks < ticks)
    {
	count = clock / (STM32WB_RTC_CLOCK_TICKS_PER_SECOND / 8);
	offset = clock & ((STM32WB_RTC_CLOCK_TICKS_PER_SECOND / 8) -1);
	
	armv7m_systick_control.offset = offset * (uint32_t)((armv7m_systick_control.cycle +1) / (STM32WB_RTC_CLOCK_TICKS_PER_SECOND / 8));

	armv7m_systick_control.ticks  = ticks;
	armv7m_systick_control.micros = count * 125000;
	armv7m_systick_control.millis = count * 125;
    }
        
    SysTick->VAL = armv7m_systick_control.cycle;
    SysTick->LOAD = armv7m_systick_control.cycle;
    SysTick->CTRL |= (SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk);
}

__attribute__((optimize("O3"))) void armv7m_systick_disable(void)
{
    uint32_t count;

    count = (armv7m_systick_control.cycle - SysTick->VAL);

    armv7m_systick_control.ticks += count;

    SysTick->CTRL &= ~(SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk);
}

__attribute__((optimize("O3"))) uint64_t armv7m_systick_micros(void)
{
    uint32_t count;

    count = (armv7m_systick_control.cycle - SysTick->VAL) + armv7m_systick_control.offset;

    return armv7m_systick_control.micros + (uint32_t)(((uint64_t)count * (uint64_t)armv7m_systick_control.scale[0]) >> 32);
}

__attribute__((optimize("O3"))) uint64_t armv7m_systick_millis(void)
{
    uint32_t count;

    count = (armv7m_systick_control.cycle - SysTick->VAL) + armv7m_systick_control.offset;

    return armv7m_systick_control.millis + (uint32_t)(((uint64_t)count * (uint64_t)armv7m_systick_control.scale[1]) >> 32);
}

__attribute__((optimize("O3"))) uint64_t armv7m_systick_ticks(void)
{
    uint32_t count;

    count = (armv7m_systick_control.cycle - SysTick->VAL);

    return armv7m_systick_control.ticks + count;
}

__attribute__((optimize("O3"))) void SysTick_Handler(void)
{
    if (SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk)
    {
        armv7m_systick_control.ticks  += (armv7m_systick_control.cycle +1);
        armv7m_systick_control.micros += 125000;
        armv7m_systick_control.millis += 125;
    }
}
