/*
 * Copyright (c) 2019-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */


#include "armv7m.h"

struct _armv7m_work_control_t {
    armv7m_work_callback_t          callback;
    void                            *context;
    uint32_t                        data;
    armv7m_work_t *                 head;
    armv7m_work_t *                 tail;
    armv7m_work_t * volatile        submit;
};

armv7m_work_control_t armv7m_work_control;

static __attribute__((naked, used)) void armv7m_work_process(void)
{
    __asm__(
	"   .cfi_def_cfa_offset 8                           \n"
        "   .cfi_offset 7, -8                               \n"
        "   .cfi_offset 14, -4                              \n"
        "1: bl       armv7m_work_dispatch                   \n"
	"   movw     r3, #:lower16:armv7m_work_control      \n"
	"   movt     r3, #:upper16:armv7m_work_control      \n"
        "   ldr      r0, [r3, %[offset_CONTROL_CALLBACK]]   \n"
        "   cbz      r0, 5f                                 \n"
        "   ldr      r1, [r3, %[offset_CONTROL_CONTEXT]]    \n"
        "   ldr      r2, [r3, %[offset_CONTROL_DATA]]       \n"
        "2: sub      r0, r0, #1                             \n"
        "   adr      r3, 3f                                 \n"
        "   add      r3, r3, #1                             \n"
        "   mov      r7, #0xf1000000                        \n"
        "   sub      sp, #0x20                              \n"
        "   str      r1, [sp, #0x00]                        \n"
        "   str      r2, [sp, #0x04]                        \n"
        "   str      r3, [sp, #0x14]                        \n"
        "   str      r0, [sp, #0x18]                        \n"
        "   str      r7, [sp, #0x1c]                        \n"
        "   mov      r0, #0xfffffff9                        \n"
        "   bx       r0                                     \n"
        "   .align 2                                        \n"
        "3: adr      r7, 4f                                 \n"
        "   add      r7, r7, #1                             \n"
#if defined (__VFP_FP__) && !defined(__SOFTFP__)
	"   mrs      r0, CONTROL                            \n"
	"   bic      r0, #0x04                              \n" // clear FPCA (LSPACT is zero)
	"   msr      CONTROL, r0                            \n"
#endif /* __VFP_FP__ && !__SOFTFP__ */
        "   svc      0                                      \n"
        "   .align 2                                        \n"
	"4: add      sp, #0x28                              \n"
	"   movw     r3, #:lower16:armv7m_work_control      \n"
	"   movt     r3, #:upper16:armv7m_work_control      \n"
        "   mov      r0, #0                                 \n"
        "   str      r0, [r3, %[offset_CONTROL_CALLBACK]]   \n"
        "   b.n      1b                                     \n"
        "5: pop      { r7, pc }                             \n"
	:
        : [offset_CONTROL_CALLBACK]    "I" (offsetof(armv7m_work_control_t, callback)),
          [offset_CONTROL_CONTEXT]     "I" (offsetof(armv7m_work_control_t, context)),
          [offset_CONTROL_DATA]        "I" (offsetof(armv7m_work_control_t, data))
        );
}

static __attribute__((optimize("O3"), used)) void armv7m_work_dispatch(void)
{
    armv7m_work_t *work;
    uint32_t data;

    while (armv7m_work_control.head != ARMV7M_WORK_SENTINEL)
    {
	work = armv7m_work_control.head;

	if (armv7m_work_control.head == armv7m_work_control.tail)
	{
	    armv7m_work_control.head = ARMV7M_WORK_SENTINEL;
	    armv7m_work_control.tail = ARMV7M_WORK_SENTINEL;
	}
	else
	{
	    armv7m_work_control.head = work->next;
	}
	
	armv7m_work_control.callback = (armv7m_work_callback_t)((uint32_t)work->callback | 1);
	armv7m_work_control.context = work->context;
	
	/* For event mode the work item gets first released, and then then the data is copied.
	 * If there is no new data (i.e. event bits), the next work item gets processed. For data 
	 * mode, that data gets first copied, and then copied (as it is latched on queue entry.
	 */
	if ((uint32_t)work->callback & ARMV7M_WORK_MODE_EVENT)
	{
	    work->next = NULL;
	    
	    data = __armv7m_atomic_swap(&work->data, 0);
	    
	    if (data)
	    {
		armv7m_work_control.data = data;
		
		break;
	    }
	}
	else
	{
	    armv7m_work_control.data = work->data;
	    
	    work->next = NULL;
	    
	    break;
	}
    }
}

static __attribute__((optimize("O3"), used)) void armv7m_work_schedule(void)
{
    armv7m_work_t *work, *work_next, *work_head, *work_tail;
    
    work = (armv7m_work_t*)__armv7m_atomic_swap((volatile uint32_t*)&armv7m_work_control.submit, (uint32_t)ARMV7M_WORK_SENTINEL);

    if (work != ARMV7M_WORK_SENTINEL)
    {
	/* Revert the submit queue and update head/tail
	 */
        for (work_head = ARMV7M_WORK_SENTINEL, work_tail = work; work != ARMV7M_WORK_SENTINEL; work = work_next)
        {
            work_next = work->next;
            
            work->next = work_head;
            
            work_head = work;
        }

        if (armv7m_work_control.head == ARMV7M_WORK_SENTINEL)
        {
            armv7m_work_control.head = work_head;
        }
        else
        {
            armv7m_work_control.tail->next = work_head;
        }

        armv7m_work_control.tail = work_tail;

	if (armv7m_work_control.callback == NULL)
	{
	    armv7m_pendsv_hook(armv7m_work_process);
	}
    }
}

void __armv7m_work_initialize()
{
    armv7m_work_control.callback = NULL;
    armv7m_work_control.context = NULL;
    armv7m_work_control.data = 0;
    armv7m_work_control.head = ARMV7M_WORK_SENTINEL;
    armv7m_work_control.tail = ARMV7M_WORK_SENTINEL;
    armv7m_work_control.submit = ARMV7M_WORK_SENTINEL;
}

void armv7m_work_create(armv7m_work_t *work, armv7m_work_callback_t callback, void *context, uint32_t mode)
{
    work->next = NULL;
    work->callback = (armv7m_work_callback_t)(((uint32_t)(callback) & ~1) | ((uint32_t)(mode) & 1));
    work->context = context;
    work->data = 0;
}

bool armv7m_work_destroy(armv7m_work_t *work)
{
    return (work->next == NULL);
}

static __attribute__((optimize("O3"))) void __svc_armv7m_work_submit(armv7m_work_t *work, uint32_t data)
{
    armv7m_work_t *work_submit;

    if ((uint32_t)work->callback & ARMV7M_WORK_MODE_EVENT)
    {
	__armv7m_atomic_or(&work->data, data);
    }

    if (__armv7m_atomic_cas((volatile uint32_t*)&work->next, (uint32_t)NULL, (uint32_t)ARMV7M_WORK_SENTINEL) == (uint32_t)NULL)
    {
	if (!((uint32_t)work->callback & ARMV7M_WORK_MODE_EVENT))
	{
	    work->data = data;
	}
	
	work_submit = (armv7m_work_t*)__armv7m_atomic_swap((volatile uint32_t*)&armv7m_work_control.submit, (uint32_t)work);
	
        work->next = work_submit;

	if (work_submit == ARMV7M_WORK_SENTINEL)
	{
	    armv7m_pendsv_raise(ARMV7M_PENDSV_SWI_WORK_SCHEDULE);
	}
    }
}

void armv7m_work_submit(armv7m_work_t *work, uint32_t data)
{
    if (!armv7m_interrupt_is_in_progress())
    {
	armv7m_svcall_2((uint32_t)&__svc_armv7m_work_submit, (uint32_t)work, (uint32_t)data);
    }
    else
    {
	__svc_armv7m_work_submit(work, data);
    }
}

void SWI_WORK_SCHEDULE_IRQHandler(void)
{
    armv7m_work_schedule();
}
