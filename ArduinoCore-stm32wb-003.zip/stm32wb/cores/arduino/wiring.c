/*
 * Copyright (c) 2016-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include "Arduino.h"
#include "wiring_private.h"
#include "dosfs_api.h"

#ifdef __cplusplus
extern "C" {
#endif

#if defined(USBCON)
stm32wb_uart_t g_Serial1;
extern const stm32wb_uart_params_t g_Serial1Params;
#else
stm32wb_uart_t g_Serial;
extern const stm32wb_uart_params_t g_SerialParams;
#endif
  
stm32wb_spi_t g_SPI;
extern const stm32wb_spi_params_t g_SPIParams;

stm32wb_i2c_t g_Wire;
extern const stm32wb_i2c_params_t g_WireParams;

#if 0  
#if (DOSFS_SDCARD >= 1)
extern const stm32wb_sfspi_params_t g_SFSPIParams;
#endif
#endif

#if 0  
#if (DOSFS_SFLASH >= 1)
extern const stm32wb_sdspi_params_t g_SDSPIParams;
#endif
#endif
  
uint8_t g_swdStatus = 0;

volatile uint32_t g_pinButton = 0;
  
int g_defaultPolicy = STM32WB_SYSTEM_POLICY_RUN;
  
uint32_t g_deepSleepControl = 0;

void init( void )
{
    stm32wb_system_initialize(_SYSTEM_CORE_CLOCK_, 0, 0, STM32WB_CONFIG_LSECLK, STM32WB_CONFIG_HSECLK, STM32WB_CONFIG_SYSOPT);

#if defined(STM32WB_CONFIG_PIN_VBUS)
    if (STM32WB_CONFIG_PIN_VBUS != STM32WB_GPIO_PIN_NONE) {
        stm32wb_gpio_pin_configure(STM32WB_CONFIG_PIN_VBUS, (STM32WB_GPIO_PARK_HIZ | STM32WB_GPIO_PUPD_PULLDOWN | STM32WB_GPIO_OSPEED_LOW | STM32WB_GPIO_OTYPE_PUSHPULL | STM32WB_GPIO_MODE_INPUT));
    }
#endif

#if (DOSFS_SDCARD == 1)
    if (g_SPI.state == STM32WB_SPI_STATE_NONE) {
        stm32wb_spi_create(&g_SPI, &g_SPIParams);
    }

#if 0
    stm32wb_sdspi_initialize(&g_SPI, &g_SDSPIParams);
#endif
    stm32wb_sdspi_initialize();
#elif (DOSFS_SDCARD == 2)
    stm32wb_sdmmc_initialize(0);
#elif (DOSFS_SDCARD == 3)
    stm32wb_sdmmc_initialize(STM32WB_SDMMC_OPTION_HIGH_SPEED);
#endif

#if (DOSFS_SFLASH >= 1)
    if (g_SPI.state == STM32WB_SPI_STATE_NONE) {
        stm32wb_spi_create(&g_SPI, &g_SPIParams);
    }

    stm32wb_sfspi_initialize(&g_SPI, &g_SFSPIParams);
  
    dosfs_sflash_init(STM32WB_CONFIG_SFLASH_DATA_START);
#endif

    /* This is here to work around a linker issue in avr/fdevopen.c */
    asm(".global stm32wb_stdio_put");
    asm(".global stm32wb_stdio_get");
}

#ifdef __cplusplus
}
#endif
