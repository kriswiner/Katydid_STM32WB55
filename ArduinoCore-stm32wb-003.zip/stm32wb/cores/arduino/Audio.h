/*
 * Copyright (c) 2016-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#ifndef _AUDIO_H_INCLUDED
#define _AUDIO_H_INCLUDED

#include <Arduino.h>

class AudioIn
{
public:
    virtual bool start() = 0;
    virtual void stop() = 0;
    virtual bool busy() = 0;

    virtual int getChannels() = 0;
    virtual int getBitsPerSample() = 0;
    virtual int getSampleRate() = 0;
    virtual size_t getBufferSize() = 0;
    
    virtual int available() = 0;
    virtual int read(void* buffer, size_t size) = 0;

    virtual void onReceive(void(*callback)(void)) = 0;
    virtual void onReceive(Callback callback) = 0;

    virtual void enableWakeup() = 0;
    virtual void disableWakeup() = 0;
};

class AudioOut
{
public:
    virtual bool start() = 0;
    virtual void stop() = 0;
    virtual bool busy() = 0;

    virtual int getChannels() = 0;
    virtual int getBitsPerSample() = 0;
    virtual int getSampleRate() = 0;
    virtual size_t getBufferSize() = 0;
    
    virtual size_t availableForWrite() = 0;
    virtual size_t write(const void *buffer, size_t size) = 0;

    virtual void onTransmit(void(*callback)(void)) = 0;
    virtual void onTransmit(Callback callback) = 0;

    virtual void enableWakeup() = 0;
    virtual void disableWakeup() = 0;
};

#endif /* _AUDIO_H_INCLUDED */
