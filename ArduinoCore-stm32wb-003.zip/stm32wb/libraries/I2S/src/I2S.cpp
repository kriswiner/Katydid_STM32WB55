/*
 * Copyright (c) 2016-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include "Arduino.h"
#include "I2S.h"
#include "wiring_private.h"

#define I2S_STATE_NONE             0
#define I2S_STATE_IDLE             1
#define I2S_STATE_RECEIVE          2
#define I2S_STATE_TRANSMIT         3

#define I2S_DIRECTION_RECEIVE      0
#define I2S_DIRECTION_TRANSMIT     1

I2SClass::I2SClass(struct _stm32wb_sai_t *sai, const struct _stm32wb_sai_params_t *params, volatile uint8_t *data)
{
    _sai = sai;

    stm32wb_sai_create(sai, params);

    _wakeup = false;

    armv7m_work_create(&_work, (armv7m_work_callback_t)I2SClass::_workCallback, (void*)this, ARMV7M_WORK_MODE_EVENT);
    
    _i2s_state = I2S_STATE_NONE;
    _i2s_data[0] = data;
    _i2s_data[1] = data + I2S_BUFFER_SIZE;
}

bool I2SClass::begin(I2SMode mode, int bitsPerSample, long sampleRate)
{
    uint32_t option;
    uint8_t i2s_head;

    static const uint32_t _i2sModeTable[] = {
	(STM32WB_SAI_OPTION_DIRECTION_RECEIVE | STM32WB_SAI_OPTION_FORMAT_I2S),
	(STM32WB_SAI_OPTION_DIRECTION_RECEIVE | STM32WB_SAI_OPTION_FORMAT_LEFT_JUSTIFIED),
	(STM32WB_SAI_OPTION_DIRECTION_RECEIVE | STM32WB_SAI_OPTION_FORMAT_RIGHT_JUSTIFIED),
	(STM32WB_SAI_OPTION_DIRECTION_TRANSMIT | STM32WB_SAI_OPTION_FORMAT_I2S),
	(STM32WB_SAI_OPTION_DIRECTION_TRANSMIT | STM32WB_SAI_OPTION_FORMAT_LEFT_JUSTIFIED),
	(STM32WB_SAI_OPTION_DIRECTION_TRANSMIT | STM32WB_SAI_OPTION_FORMAT_RIGHT_JUSTIFIED),
    };
    
    if (_i2s_state != I2S_STATE_NONE) {
	return false;
    }

    if (mode > (sizeof(_i2sModeTable) / sizeof(_i2sModeTable[0]))) {
	return false;
    }

    option = _i2sModeTable[mode];
    
    switch (bitsPerSample) {
    case 16:
	option |= STM32WB_SAI_OPTION_SIZE_16;
	break;
    case 24:
	option |= STM32WB_SAI_OPTION_SIZE_32;
	break;
    case 32:
	option |= STM32WB_SAI_OPTION_SIZE_32;
	break;
    default:
	return false;
    }

    switch (sampleRate) {
    case 0:
	break;
    case 44100:
	break;
    case 8000:
    case 16000:
    case 24000:
    case 48000:
	break;
    default:
	return false;
    }

    if (!stm32wb_sai_enable(_sai, sampleRate, bitsPerSample, option, (stm32wb_sai_event_callback_t)I2SClass::_eventCallback, (void*)this)) {
	return false;
    }

    _direction = (option & STM32WB_SAI_OPTION_DIRECTION_TRANSMIT) ? I2S_DIRECTION_TRANSMIT : I2S_DIRECTION_RECEIVE;
    _bitsPerSample = bitsPerSample;
    _sampleRate = sampleRate;
    
    _i2s_state = I2S_STATE_IDLE;
    _i2s_head = 0;
    _i2s_tail = 0;
    _i2s_count = 0;
    _i2s_offset = 0;

    if (_direction == I2S_DIRECTION_RECEIVE) {
	_i2s_state = I2S_STATE_RECEIVE;
	
	i2s_head = _i2s_head;
	_i2s_head = (i2s_head +1) & (I2S_BUFFER_COUNT -1);
	
	stm32wb_sai_receive(_sai, (uint8_t*)_i2s_data[i2s_head], I2S_BUFFER_SIZE);
    } else {
    }
    
    return true;
}

void I2SClass::end()
{
    if (_i2s_state == I2S_STATE_NONE) {
	return;
    }

    stm32wb_sai_stop(_sai);
    stm32wb_sai_disable(_sai);

    _i2s_state = I2S_STATE_NONE;
}

void I2SClass::flush(void)
{
    uint8_t i2s_head;

    if (_i2s_state == I2S_STATE_NONE) {
	return;
    }

    if (_i2s_state != I2S_STATE_IDLE) {
	stm32wb_sai_stop(_sai);

	_i2s_state = I2S_STATE_IDLE;
    }

    _i2s_head = 0;
    _i2s_tail = 0;
    _i2s_count = 0;
    _i2s_offset = 0;
    
    if (_direction == I2S_DIRECTION_RECEIVE) {
	_i2s_state = I2S_STATE_RECEIVE;
	
	i2s_head = _i2s_head;
	_i2s_head = (i2s_head +1) & (I2S_BUFFER_COUNT -1);
	
	stm32wb_sai_receive(_sai, (uint8_t*)_i2s_data[i2s_head], I2S_BUFFER_SIZE);
    }
}

bool I2SClass::busy(void)
{
    return (_i2s_state > I2S_STATE_IDLE);
}

int I2SClass::getChannels(void)
{
    return 2;
}

int I2SClass::getBitsPerSample(void)
{
    return _bitsPerSample;
}

int I2SClass::getSampleRate(void)
{
    return _sampleRate;
}

size_t I2SClass::getBufferSize(void)
{
    return I2S_BUFFER_SIZE;
}

int I2SClass::available()
{
    if ((_i2s_state == I2S_STATE_NONE) || (_direction != I2S_DIRECTION_RECEIVE)) {
	return 0;
    }

    if (_i2s_count == 0) {
	return 0;
    }
    
    return (I2S_BUFFER_SIZE - _i2s_offset);
}

__attribute__((optimize("O3"))) int I2SClass::read(void* buffer, size_t size)
{
    uint32_t i2s_offset;
    uint8_t i2s_tail;
    
    if ((_i2s_state == I2S_STATE_NONE) || (_direction != I2S_DIRECTION_RECEIVE)) {
	return 0;
    }

    if (_i2s_count == 0) {
	return 0;
    }

    if (_bitsPerSample == 16) {	size &= ~1; }
    else                      { size &= ~3; }
    
    i2s_tail   = _i2s_tail;
    i2s_offset = _i2s_offset;

    if (size > (I2S_BUFFER_SIZE - i2s_offset)) {
	size = (I2S_BUFFER_SIZE - i2s_offset);
    }

    if (size) {
	memcpy(buffer, (uint8_t*)_i2s_data[i2s_tail] + i2s_offset, size);
	
	i2s_offset += size;

	if (i2s_offset == I2S_BUFFER_SIZE) {
	    armv7m_atomic_decb(&_i2s_count);
	    
	    _i2s_tail = (i2s_tail +1) & (I2S_BUFFER_COUNT -1);
	    _i2s_offset = 0;
	} else {
	    _i2s_offset = i2s_offset;
	}
    }
    
    return size;
}

size_t I2SClass::availableForWrite()
{
    if ((_i2s_state == I2S_STATE_NONE) || (_direction != I2S_DIRECTION_TRANSMIT)) {
	return 0;
    }

    if (_i2s_count == I2S_BUFFER_COUNT) {
	return 0;
    }
    
    return (I2S_BUFFER_SIZE - _i2s_offset);
}

__attribute__((optimize("O3"))) size_t I2SClass::write(const void *buffer, size_t size)
{
    uint32_t i2s_offset;
    uint8_t i2s_head, i2s_tail;

    if ((_i2s_state == I2S_STATE_NONE) || (_direction != I2S_DIRECTION_TRANSMIT)) {
	return 0;
    }

    if (_i2s_count == I2S_BUFFER_COUNT) {
	return 0;
    }

    if (_bitsPerSample == 16) {	size &= ~1; }
    else                      { size &= ~3; }
    
    i2s_head   = _i2s_head;
    i2s_offset = _i2s_offset;
    
    if (size > (I2S_BUFFER_SIZE - i2s_offset)) {
	size = (I2S_BUFFER_SIZE - i2s_offset);
    }
    
    if (size) {
	memcpy((uint8_t*)_i2s_data[i2s_head] + i2s_offset, buffer, size);
	       
	i2s_offset += size;
	       
	if (i2s_offset == I2S_BUFFER_SIZE) {
	    armv7m_atomic_incb(&_i2s_count);
	    
	    _i2s_head = (i2s_head +1) & (I2S_BUFFER_COUNT -1);
	    _i2s_offset = 0;

	    if (_i2s_state == I2S_STATE_IDLE) {
		_i2s_state = I2S_STATE_TRANSMIT;

		i2s_tail = _i2s_tail;
		_i2s_tail = (i2s_tail +1) & (I2S_BUFFER_COUNT -1);
                
		stm32wb_sai_transmit(_sai, (const uint8_t*)_i2s_data[i2s_tail], I2S_BUFFER_SIZE);
	    }
	} else {
	    _i2s_offset = i2s_offset;
	}
    }
    
    return size;
}

void I2SClass::onReceive(void(*callback)(void))
{
    _receiveCallback = Callback(callback);
}

void I2SClass::onReceive(Callback callback)
{
    _receiveCallback = callback;
}

void I2SClass::onTransmit(void(*callback)(void))
{
    _transmitCallback = Callback(callback);
}

void I2SClass::onTransmit(Callback callback)
{
    _transmitCallback = callback;
}

void I2SClass::enableWakeup(void)
{
    _wakeup = true;
}

void I2SClass::disableWakeup(void)
{
    _wakeup = false;
}

void I2SClass::_workCallback(class I2SClass *self, uint32_t events)
{
    if (events & STM32WB_SAI_EVENT_RECEIVE) {
	self->_receiveCallback.call(self->_wakeup);
    }

    if (events & STM32WB_SAI_EVENT_TRANSMIT) {
	self->_transmitCallback.call(self->_wakeup);
    }
}

void I2SClass::_eventCallback(class I2SClass *self, uint32_t events)
{
    uint8_t i2s_head, i2s_tail;

    if (events & STM32WB_SAI_EVENT_RECEIVE) {
	if (self->_i2s_state == I2S_STATE_RECEIVE) {
	    if (armv7m_atomic_incb(&self->_i2s_count) != (I2S_BUFFER_COUNT -1)) {
		i2s_head = self->_i2s_head;
		self->_i2s_head = (i2s_head +1) & (I2S_BUFFER_COUNT -1);
		
		stm32wb_sai_receive(self->_sai, (uint8_t*)self->_i2s_data[i2s_head], I2S_BUFFER_SIZE);
	    } else {
		self->_i2s_state = I2S_STATE_IDLE;
	    }
	
	    armv7m_work_submit(&self->_work, STM32WB_SAI_EVENT_RECEIVE);
	}
    }
    
    if (events & STM32WB_SAI_EVENT_TRANSMIT) {
	if (self->_i2s_state == I2S_STATE_TRANSMIT) {
	    if (armv7m_atomic_decb(&self->_i2s_count) != 1) {
		i2s_tail = self->_i2s_tail;
		self->_i2s_tail = (i2s_tail +1) & (I2S_BUFFER_COUNT -1);
		
		stm32wb_sai_transmit(self->_sai, (const uint8_t*)self->_i2s_data[i2s_tail], I2S_BUFFER_SIZE);
	    } else {
		self->_i2s_state = I2S_STATE_IDLE;
	    }
	    
	    armv7m_work_submit(&self->_work, STM32WB_SAI_EVENT_TRANSMIT);
	}
    }
}

#if I2S_INTERFACES_COUNT > 0

extern const stm32wb_sai_params_t g_I2SParams;

static __attribute__((aligned(4), section(".dma"))) uint8_t _I2S_Data[I2S_BUFFER_COUNT * I2S_BUFFER_SIZE];

static stm32wb_sai_t _I2S;

I2SClass I2S(&_I2S, &g_I2SParams, &_I2S_Data[0]);

#endif
