/*
 * Copyright (c) 2016-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#ifndef _I2S_H_INCLUDED
#define _I2S_H_INCLUDED

#include <Arduino.h>

#define I2S_BUFFER_COUNT 2
#define I2S_BUFFER_SIZE  512

class I2SClass
{
public:
    typedef enum {
	RECEIVE_PHILIPS = 0,
	RECEIVE_LEFT_JUSTIFIED,
	RECEIVE_RIGHT_JUSTIFIED,
	TRANSMIT_PHILIPS,
	TRANSMIT_LEFT_JUSTIFIED,
	TRANSMIT_RIGHT_JUSTIFIED,
    } I2SMode;
    
    I2SClass(struct _stm32wb_sai_t *sai, const struct _stm32wb_sai_params_t *params, volatile uint8_t *data);

    bool begin(I2SMode mode, int bitsPerSample, long sampleRate = 0);
    void end();

    void flush();
    bool busy();

    int getChannels();
    int getBitsPerSample();
    int getSampleRate();
    size_t getBufferSize();

    int available();
    int read(void* buffer, size_t size);

    size_t availableForWrite();
    size_t write(const void *buffer, size_t size);
    
    void onReceive(void(*callback)(void));
    void onReceive(Callback callback);
    void onTransmit(void(*callback)(void));
    void onTransmit(Callback callback);

    void enableWakeup();
    void disableWakeup();
    
private:
    struct _stm32wb_sai_t *_sai;
    uint8_t _wakeup;
    uint8_t _direction;
    uint8_t _bitsPerSample;
    uint32_t _sampleRate;
    volatile uint8_t _i2s_state;
    volatile uint8_t _i2s_head;
    volatile uint8_t _i2s_tail;
    volatile uint8_t _i2s_count;
    volatile uint32_t _i2s_offset;
    volatile uint8_t *_i2s_data[I2S_BUFFER_COUNT];

    armv7m_work_t _work;
    
    Callback _receiveCallback;
    Callback _transmitCallback;

    static void _workCallback(class I2SClass *self, uint32_t events);
    static void _eventCallback(class I2SClass *self, uint32_t events);
};

#if I2S_INTERFACES_COUNT > 0
extern I2SClass I2S;
#endif

#endif
