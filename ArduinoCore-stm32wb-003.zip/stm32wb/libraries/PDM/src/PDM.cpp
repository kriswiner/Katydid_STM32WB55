/*
 * Copyright (c) 2016-2020 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include "Arduino.h"
#include "PDM.h"
#include "wiring_private.h"

#define PDM_STATE_NONE             0
#define PDM_STATE_IDLE             1
#define PDM_STATE_RECEIVE          2

PDMClass::PDMClass(struct _stm32wb_sai_t *sai, const struct _stm32wb_sai_params_t *params, volatile uint8_t *pdm_data, volatile uint8_t *cic_data, volatile uint8_t *hbf_data, volatile uint8_t *fir_data)
{
    _sai = sai;

    stm32wb_sai_create(sai, params);

    _wakeup = false;

    armv7m_work_create(&_work, (armv7m_work_callback_t)PDMClass::_workCallback, (void*)this, ARMV7M_WORK_MODE_EVENT);
    
    _pdm_state = PDM_STATE_NONE;
    _pdm_data[0] = pdm_data;
    _pdm_data[1] = _pdm_data[0] + PDM_BUFFER_SIZE;

    _cic_data[0] = cic_data;
    _cic_data[1] = _cic_data[0] + CIC_BUFFER_SIZE;
    _cic_data[2] = _cic_data[1] + CIC_BUFFER_SIZE;
    _cic_data[3] = _cic_data[2] + CIC_BUFFER_SIZE;

    _hbf_data = hbf_data;

    _fir_data[0] = fir_data;
    _fir_data[1] = _fir_data[0] + FIR_BUFFER_SIZE;

    _fir_state[0].iir_gain = _fir_state[1].iir_gain = (int32_t)(1.0f * (float)ARMV7M_PDM_GAIN_SCALE);
}

bool PDMClass::begin(int channels, long sampleRate)
{
    uint32_t width, option;
    int32_t a1, b0, b1;

    if (_pdm_state != PDM_STATE_NONE) {
	return false;
    }

    switch (channels) {
    case 1:
	width = 8;
	option = STM32WB_SAI_OPTION_SIZE_8 | STM32WB_SAI_OPTION_DIRECTION_RECEIVE | STM32WB_SAI_OPTION_FORMAT_PDM;
	break;
    case 2:
	width = 16;
	option = STM32WB_SAI_OPTION_SIZE_16 | STM32WB_SAI_OPTION_DIRECTION_RECEIVE | STM32WB_SAI_OPTION_FORMAT_PDM;
	break;
    default:
	return false;
    }

    switch (sampleRate) {
    case 44100:
	a1 = (int32_t)(  0.99644443 * (float)ARMV7M_PDM_IIR_SCALE);
	b0 = (int32_t)(  0.99822222 * (float)ARMV7M_PDM_IIR_SCALE);
	b1 = (int32_t)( -0.99822222 * (float)ARMV7M_PDM_IIR_SCALE);
	break;
    case 8000:
	a1 = (int32_t)(  0.98055532 * (float)ARMV7M_PDM_IIR_SCALE);
	b0 = (int32_t)(  0.99027766 * (float)ARMV7M_PDM_IIR_SCALE);
	b1 = (int32_t)( -0.99027766 * (float)ARMV7M_PDM_IIR_SCALE);
	break;
    case 16000:
	a1 = (int32_t)(  0.99023040 * (float)ARMV7M_PDM_IIR_SCALE);
	b0 = (int32_t)(  0.99511520 * (float)ARMV7M_PDM_IIR_SCALE);
	b1 = (int32_t)( -0.99511520 * (float)ARMV7M_PDM_IIR_SCALE);
	break;
    case 24000:
	a1 = (int32_t)(  0.99347634 * (float)ARMV7M_PDM_IIR_SCALE);
	b0 = (int32_t)(  0.99673817 * (float)ARMV7M_PDM_IIR_SCALE);
	b1 = (int32_t)( -0.99673817 * (float)ARMV7M_PDM_IIR_SCALE);
	break;
    case 48000:
	a1 = (int32_t)(  0.99673285 * (float)ARMV7M_PDM_IIR_SCALE);
	b0 = (int32_t)(  0.99836643 * (float)ARMV7M_PDM_IIR_SCALE);
	b1 = (int32_t)( -0.99836643 * (float)ARMV7M_PDM_IIR_SCALE);
	break;
    default:
	return false;
    }

    if (!stm32wb_sai_enable(_sai, sampleRate, width, option, (stm32wb_sai_event_callback_t)PDMClass::_eventCallback, (void*)this)) {
	return false;
    }

    _channels = channels;
    _sampleRate = sampleRate;
    
    _pdm_state = PDM_STATE_IDLE;
    
    _fir_state[0].iir_a1 = _fir_state[1].iir_a1 = a1;
    _fir_state[0].iir_b0 = _fir_state[1].iir_b0 = b0;
    _fir_state[0].iir_b1 = _fir_state[1].iir_b1 = b1;
    
    flush();
    
    return true;
}

void PDMClass::end()
{
    if (_pdm_state == PDM_STATE_NONE) {
	return;
    }

    stm32wb_sai_stop(_sai);
    stm32wb_sai_disable(_sai);

    _pdm_state = PDM_STATE_NONE;
}

void PDMClass::flush(void)
{
    uint8_t cic_head;

    if (_pdm_state == PDM_STATE_NONE) {
	return;
    }

    if (_pdm_state != PDM_STATE_IDLE) {
	stm32wb_sai_stop(_sai);

	_pdm_state = PDM_STATE_IDLE;
    }
    
    _pdm_state = PDM_STATE_RECEIVE;
    _pdm_head = 0;
    _pdm_tail = 0;
    _pdm_count = 0;
    _pdm_offset = 0;

    _cic_busy = true;
    _cic_head = 0;
    _cic_tail = 0;
    _cic_count = 0;
    _pcm_offset = 0;

    memset((uint8_t*)_fir_data[0], 0, FIR_BUFFER_SIZE);
    memset((uint8_t*)_fir_data[1], 0, FIR_BUFFER_SIZE);

    memset(&_cic_state, 0, sizeof(_cic_state));
    memset(&_hbf_state, 0, sizeof(_hbf_state));

    _fir_state[0].iir_y = _fir_state[1].iir_y = 0;
    _fir_state[0].iir_x = _fir_state[1].iir_x = 0;
    
    cic_head = _cic_head;
    _cic_head = (cic_head +1) & (CIC_BUFFER_COUNT -1);
	
    stm32wb_sai_receive(_sai, (uint8_t*)_cic_data[cic_head], CIC_BUFFER_SIZE);
}

bool PDMClass::busy(void)
{
    return (_pdm_state > PDM_STATE_IDLE);
}

int PDMClass::getChannels(void)
{
    return _channels;
}

int PDMClass::getBitsPerSample(void)
{
    return 16;
}

int PDMClass::getSampleRate(void)
{
    return _sampleRate;
}

size_t PDMClass::getBufferSize(void)
{
    return PDM_BUFFER_SIZE;
}

void PDMClass::setGain(float gain)
{
    float scale;

    scale = powf(10.0f, gain * (1.0f / 20.0f));

    if (scale > 256.0) { scale = 256.0; }

    _fir_state[0].iir_gain = _fir_state[1].iir_gain = (int32_t)(scale * (float)ARMV7M_PDM_GAIN_SCALE);
}

int PDMClass::available()
{
    if (_pdm_state == PDM_STATE_NONE) {
	return 0;
    }

    if (_pdm_count == 0) {
	return 0;
    }
    
    return (PDM_BUFFER_SIZE - _pdm_offset);
}

__attribute__((optimize("O3"))) int PDMClass::read(void* buffer, size_t size)
{
    uint32_t pdm_offset;
    uint8_t pdm_tail;
    
    if (_pdm_state == PDM_STATE_NONE) {
	return 0;
    }

    if (_pdm_count == 0) {
	return 0;
    }

    size &= ~1;
    
    pdm_tail   = _pdm_tail;
    pdm_offset = _pdm_offset;

    if (size > (PDM_BUFFER_SIZE - pdm_offset)) {
	size = (PDM_BUFFER_SIZE - pdm_offset);
    }

    if (size) {
	memcpy(buffer, (uint8_t*)_pdm_data[pdm_tail] + pdm_offset, size);
	
	pdm_offset += size;

	if (pdm_offset == PDM_BUFFER_SIZE) {
	    armv7m_atomic_decb(&_pdm_count);
	    
	    _pdm_tail = (pdm_tail +1) & (PDM_BUFFER_COUNT -1);
	    _pdm_offset = 0;
	} else {
	    _pdm_offset = pdm_offset;
	}
    }
    
    return size;
}

void PDMClass::onReceive(void(*callback)(void))
{
    _receiveCallback = Callback(callback);
}

void PDMClass::onReceive(Callback callback)
{
    _receiveCallback = callback;
}

void PDMClass::enableWakeup(void)
{
    _wakeup = true;
}

void PDMClass::disableWakeup(void)
{
    _wakeup = false;
}

void PDMClass::_workCallback(class PDMClass *self, uint32_t events)
{
    uint32_t pcm_offset;
    uint8_t cic_tail, pdm_head;

    stm32wb_gpio_pin_write(STM32WB_GPIO_PIN_PB4, 1);
    
    if (self->_pdm_state == PDM_STATE_IDLE) {
	self->_cic_busy = false;
    }

    if (self->_cic_count && (self->_pdm_state != PDM_STATE_IDLE)) {
	if (self->_pdm_count == PDM_BUFFER_COUNT) {
	    self->_pdm_state = PDM_STATE_IDLE;
	    self->_cic_busy = false;
	    
	    self->_receiveCallback.call(self->_wakeup);
	} else {
	    pdm_head = self->_pdm_head;
	    pcm_offset = self->_pcm_offset;
	
	    cic_tail = self->_cic_tail;
	    self->_cic_tail = (cic_tail +1) & (CIC_BUFFER_COUNT -1);

	    if (self->_channels == 2) {
		armv7m_pdm_cic4_x16_left((int16_t*)self->_hbf_data, (const uint8_t*)self->_cic_data[cic_tail], CIC_BUFFER_SIZE, &self->_cic_state[0]);
		armv7m_pdm_cic4_x16_right((int16_t*)(self->_hbf_data + (HBF_BUFFER_SIZE / 2)), (const uint8_t*)self->_cic_data[cic_tail], CIC_BUFFER_SIZE, &self->_cic_state[1]);
		armv7m_atomic_decb(&self->_cic_count);

		if (!(cic_tail & 1)) {
		    armv7m_pdm_hbf15_x2((int16_t*)(self->_fir_data[0] + 63 * 2), (const int16_t*)self->_hbf_data, 256, &self->_hbf_state[0]);
		    armv7m_pdm_hbf15_x2((int16_t*)(self->_fir_data[1] + 63 * 2), (const int16_t*)(self->_hbf_data + (HBF_BUFFER_SIZE / 2)), 256, &self->_hbf_state[1]);
		} else {
		    armv7m_pdm_hbf15_x2((int16_t*)(self->_fir_data[0] + 63 * 2 + 128 * 2), (const int16_t*)self->_hbf_data, 256, &self->_hbf_state[0]);
		    armv7m_pdm_hbf15_x2((int16_t*)(self->_fir_data[1] + 63 * 2 + 128 * 2), (const int16_t*)(self->_hbf_data + (HBF_BUFFER_SIZE / 2)), 256, &self->_hbf_state[1]);

		    armv7m_pdm_fir64_x2_stereo((int16_t*)(self->_pdm_data[pdm_head] + pcm_offset), (const int16_t*)self->_fir_data[0], 256, &self->_fir_state[0]);
		    armv7m_pdm_fir64_x2_stereo((int16_t*)(self->_pdm_data[pdm_head] + pcm_offset + 2), (const int16_t*)self->_fir_data[1], 256, &self->_fir_state[1]);

		    pcm_offset += (256 * 2);
		}
	    } else {
		armv7m_pdm_cic4_x16((int16_t*)self->_hbf_data, (const uint8_t*)self->_cic_data[cic_tail], CIC_BUFFER_SIZE, &self->_cic_state[0]);
		armv7m_atomic_decb(&self->_cic_count);
	      
		armv7m_pdm_hbf15_x2((int16_t*)(self->_fir_data[0] + 63 * 2), (const int16_t*)self->_hbf_data, 512, &self->_hbf_state[0]);
		armv7m_pdm_fir64_x2((int16_t*)(self->_pdm_data[pdm_head] + pcm_offset), (const int16_t*)self->_fir_data[0], 256, &self->_fir_state[0]);
		
		pcm_offset += (128 * 2);
	    }
	    
	    if (pcm_offset == PDM_BUFFER_SIZE) {
		self->_pcm_offset = 0;
	    
		armv7m_atomic_incb(&self->_pdm_count);
	    
		self->_pdm_head = (pdm_head +1) & (PDM_BUFFER_COUNT -1);
	    
		if (!self->_cic_busy) {
		    self->_pdm_state = PDM_STATE_IDLE;
		}
	    
		self->_receiveCallback.call(self->_wakeup);
	    } else {
		self->_pcm_offset = pcm_offset;

		if (!self->_cic_busy) {
		    self->_pdm_state = PDM_STATE_IDLE;
		    self->_receiveCallback.call(self->_wakeup);
		}
	    }
	}
    }
    
    if (self->_cic_count && (self->_pdm_state != PDM_STATE_IDLE)) {
	armv7m_work_submit(&self->_work, ARMV7M_WORK_EVENTS_ANY);
    }

    stm32wb_gpio_pin_write(STM32WB_GPIO_PIN_PB4, 0);
}

void PDMClass::_eventCallback(class PDMClass *self, uint32_t events)
{
    uint8_t cic_head;

    if (events & STM32WB_SAI_EVENT_RECEIVE) {
	if (self->_cic_busy) {
	    if (armv7m_atomic_incb(&self->_cic_count) != (CIC_BUFFER_COUNT -1)) {
		cic_head = self->_cic_head;
		self->_cic_head = (cic_head +1) & (CIC_BUFFER_COUNT -1);
		
		stm32wb_sai_receive(self->_sai, (uint8_t*)self->_cic_data[cic_head], CIC_BUFFER_SIZE);
	    } else {
		self->_cic_busy = false;
	    }
	
	    armv7m_work_submit(&self->_work, ARMV7M_WORK_EVENTS_ANY);
	}
    }
}

#if PDM_INTERFACES_COUNT > 0

extern const stm32wb_sai_params_t g_PDMParams;

static __attribute__((aligned(4), section(".noinit"))) uint8_t _PDM_Data[PDM_BUFFER_COUNT * PDM_BUFFER_SIZE];
static __attribute__((aligned(4), section(".dma"))) uint8_t _CIC_Data[CIC_BUFFER_COUNT * CIC_BUFFER_SIZE];
static __attribute__((aligned(4), section(".noinit"))) uint8_t _HBF_Data[HBF_BUFFER_SIZE];
static __attribute__((aligned(4), section(".noinit"))) uint8_t _FIR_Data[FIR_BUFFER_SIZE * 2];

static stm32wb_sai_t _PDM;

PDMClass PDM(&_PDM, &g_PDMParams, &_PDM_Data[0], &_CIC_Data[0], &_HBF_Data[0], &_FIR_Data[0]);

#endif
